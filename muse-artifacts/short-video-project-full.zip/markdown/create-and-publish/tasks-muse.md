# Short-Video Pipeline — Task List (Technical Build)

Companion to `techspec.md`. **Every task here is owned
by Muse Bandhu** — the build work. (Balram Bandhu's decisions, manual
actions, and approval gates live in `tasks-balram.md`.)

Work top-to-bottom: each task has a **review gate** — output is presented,
Balram Bandhu says **"adjust"** or **"done"**. Nothing downstream starts
until its dependencies are done. Deps on Balram Bandhu's list are marked
`you:Tx`. One task at a time, in dependency order.

**Automation indicator:**
- 🟢 Fully automatable — runs end-to-end once set up.

**Cost tag:** `$0` · `media` = draws on the Muse plan (video/TTS/image
generation).

---

## Phase 1 — Setup (one-time build)

- [ ] **T1.6 — Build `youtube-publisher` skill** 🟢 `$0`
  Owner: Muse Bandhu · Dep: you:T1.3 · Output: reusable skill — resumable
  upload, native scheduling via `publishAt`, quota ledger (stops at 90%),
  AI-disclosure handling per upload (API support verified here; fallback
  = per-batch manual Studio check).
  Gate: dry-run upload to private passes.

- [ ] **T1.7 — Build `meta-page-publisher` skill** 🟢 `$0`
  Owner: Muse Bandhu · Dep: you:T1.4 · Output: reusable skill — Graph API
  video upload to the Page (publishes as Reel), native scheduling via
  `published=false` + `scheduled_publish_time`, backoff on 429.
  Gate: dry-run to unpublished/draft passes.

- [ ] **T1.8 — Build assembly + QC scripts** 🟢 `$0`
  Owner: Muse Bandhu · Dep: — (parallel track) · Output: `assemble.sh`
  (concat → 1080×1920, burned-in captions, VO mix), `qc.py`
  (duration/codec/size checks + frame extraction, categorized rejection
  reasons feeding the failure-pattern history). Verifies FFmpeg on the
  VM (installs if missing).
  Gate: 3 test renders pass QC.

- [ ] **T1.9 — Scaffold the workspace** 🟢 `$0`
  Owner: Muse Bandhu · Dep: you:T0.2 · Output: `video-pipeline/` tree —
  channel template, brand config, idea queue, state ledger, sponsor
  ledger, failure log (schemas: tech spec §2–§3).
  Gate: folder layout shown; config matches T0.2/T0.3.

- [ ] **T1.10 — End-to-end dry run (no publishing)** 🟢 `media`
  Owner: Muse Bandhu · Dep: T1.8, T1.9, you:T0.2 · Output: 3 complete
  pilot videos in `ready/`, QC reports. Cost: ~15 clips + 3 voiceovers +
  3 images.
  Gate: **Balram Bandhu watches all 3** — look, voice, pacing approved or
  revised.

- [ ] **T1.15 — Calibration batch: test shorts + content review** 🟢 `media`
  Owner: Muse Bandhu · Dep: T1.8, T1.10, you:T0.2 · Output: 6–9 small
  test shorts (~15–20s, 2 clips each — cheap) spanning the key variants:
  with vs without voiceover, caption styles, pacing, hook styles, visual
  density. BalRam watches and scores each one — is the voiceover needed
  or does text + visuals carry it (decided per format), plus visual
  style, caption readability, pacing, hooks. Every decision is recorded
  into `brand.yml` (VO policy per format, caption style, visual tuning);
  the loop repeats until approved.
  Cost: ~15 clips + a few test voiceovers.
  Gate: BalRam approves the calibration — **no publishing candidate is
  built (T2.1) until then.**
  *Early observation (2026-09-23): initial Explore-chat tests looked
  better without voiceover (voice quality itself is realistic, not
  robotic) — calibration will confirm across more samples before the
  VO policy is locked.*

- [ ] **T1.16 — Build the audio library** 🟢 `$0`
  Owner: Muse Bandhu · Dep: you:T0.2 · Output: `shared/audio/` — ~20–30
  **original/AI-generated** background beds + stingers, loudness-normalized
  and mood-tagged to the channel brand, so no video generates music from
  scratch. **Default is original/AI-generated audio** per the locked
  original-media rule; licensed commercial beds are added only if BalRam
  explicitly approves them. (Trending commercial sounds stay a manual
  native swap on winners — promo plan §3.)
  Gate: sample bed under a test render approved.

- [ ] **T1.17 — Prove the metrics sources** 🟢 `$0`
  Owner: Muse Bandhu · Dep: T1.6, T1.7, T1.14 · Output: a per-platform
  metrics capability matrix — what retention / watch-time / follower
  attribution each API actually returns, and the defined proxy where true
  retention is unavailable. T2.3's scale/kill/test loop is built only on
  metrics that provably exist.
  Gate: matrix reviewed; any promised-but-unavailable metric is cut or
  proxied before T2.3 is built.

- [ ] **T1.11 — Cadence control (single-prompt adjustment)** 🟢 `$0`
  Owner: Muse Bandhu · Dep: T1.9 · Output: `cadence.yml` per channel
  (`videos_per_day` + scope: today | this_week | this_month |
  until_changed); publish jobs re-read it every run; scoped overrides
  auto-revert on expiry; current setting shown in the weekly digest.
  Gate: live test — "1 video today" adjusts the slots and reverts
  correctly.

- [ ] **T1.12 — Review / staging publish (admin preview)** 🟢 `$0`
  Owner: Muse Bandhu · Dep: T1.6, T1.9 · Output: `review:` config block
  in `brand.yml` (enabled flag; destination: youtube_unlisted /
  youtube_private / review_channel / chat_preview; per-run override by
  single prompt; optional auto-promote timer); `youtube-publisher` gains
  `--review` and `promote` (unlisted→public via `videos.update`).
  Temporary by design: on through the initial weeks until vision-lock
  (you:T3.1), then off — re-enable any time by prompt.
  Gate: test — unlisted upload lands, chat link delivered,
  promote-to-public works.

- [ ] **T1.13 — Video reference scheme + action commands** 🟢 `$0`
  Owner: Muse Bandhu · Dep: T1.6, T1.7, T1.9 · Output: refs
  (`<channel>.yyyy.MM.dd.N`, N = 1–5/day, channel prefix optional when
  unambiguous) assigned at generation, stored in `meta.json`, ledger
  keyed by ref → platform IDs, ref embedded as the last line of the
  description/caption on all four platforms (human-searchable fallback;
  ledger stays the machine source of truth); a `video` command handling
  `status` / `unpublish` / `remove` / `adjust`+republish /
  `block|unblock comments` / `comment` / `report` / `promote` / `review`
  by ref. Destructive actions always confirm first; platform gaps surface
  as explicit manual steps, never silent failures. `unpublish`/hide
  checks the sponsor obligations ledger first and is blocked while
  obligations are active unless the contract permits it.
  Gate: every action tested on a scratch ref end-to-end.

- [ ] **T1.18 — Build the topic engine (guardrailed ideation)** 🟢 `$0`
  Owner: Muse Bandhu · Dep: T1.9, you:T0.1 ✅ · Output: `topic-engine` —
  candidate sourcing (official product/feature announcements, new tools,
  pricing/cost changes, announced launches + event calendars,
  search/platform trends, prior performance via the learning KB); dedup
  against the full content ledger (near-duplicates rejected, variation
  preserved); **universal content guardrails enforced at ideation, before
  scripting** — violations rejected or flagged for BalRam's review; the
  channel's editorial scope enforced (for AI Technology Education: no
  negative reputational news — products, capabilities, tools, launches,
  pricing only); pilot candidates route through BalRam's approval gate.
  Gate: a week's candidate queue reviewed — no duplicates, no guardrail
  violations, sane variation.

- [ ] **T1.19 — Sponsor obligations ledger + media kit + affiliate scaffolding** 🟢 `$0`
  Owner: Muse Bandhu · Dep: T1.9, you:T0.4 · Output: `sponsor-ledger.json`
  (per-video: sponsor/brand, contract + campaign id, minimum-live-until,
  required links/text, pinned-comment requirements, on-screen/audio
  integration, usage rights, exclusivity, restrictions, approval/contact
  record); the `video` command blocks hide/alter while obligations are
  active; **media-kit generator** producing a sponsor kit from real
  channel metrics only (never invented numbers); sponsor prospect
  shortlist + outreach templates with tracking; affiliate scaffolding —
  tracked-link hub, CTA rotation config, click/conversion ingestion for
  revenue attribution. Sponsorship routes supported: inbound discovery,
  personalized outbound pitching, creator marketplaces, agencies/MCNs,
  UGC/content-production deals. **Manual gates stay manual:** identity/tax
  details, application submissions, outreach sends, negotiation, closing.
  Gate: ledger blocks a test hide on a fake active obligation; media kit
  numbers match the ledger exactly.

- [ ] **T1.20 — Pipeline observability (own tracking, self-healing, alerts)** 🟢 `$0`
  Owner: Muse Bandhu · Dep: T1.8, T1.9 · Output: this pipeline's
  independent observability — `state/failures.jsonl` event tracking (bugs,
  failures, performance events), `state/failure-patterns.md` history
  feeding generation prompts and the shared learning KB, **bounded
  self-healing** (generation retries ≤3 with backoff, fallback
  models/endpoints, quarantine; repeated failures escalate instead of
  looping), **anomaly detection** (unfavorable conditions, exceptions,
  weak growth, bottlenecks — e.g. buffer draining, quota burn, retention
  collapse), and **severity-tiered alerts** (P1/P2/P3 by importance,
  occurrence rate, urgency, need for human review/approval/intervention —
  thresholds locked in you:T0.5).
  Gate: a fault-injection drill — failed generation self-heals within
  budget, repeated failure escalates with the right severity.

- [ ] **T1.21 — Operational reports (this pipeline's own)** 🟢 `$0`
  Owner: Muse Bandhu · Dep: T1.20, T2.1 · Output: daily **production
  report** (videos made, QC pass/reject with categories, buffer health,
  cost per video, generation usage vs allowance, self-healing actions)
  and weekly **content performance summary** (per-video velocity,
  retention, engagement, format leaderboard, breakout flags,
  scale/kill/test calls) — produced automatically, on-demand any time.
  These feed the shared R1 cross-pipeline rollup owned by the
  performance-monitoring pipeline's reporting framework.
  Gate: first daily + weekly reports reviewed together.

---

## Phase 2 — Pilot

- [ ] **T1.14 — TikTok publishing integration** 🟠 `$0`
  Owner: Muse Bandhu · Dep: you:T1.1 (TikTok account) · Output: custom
  `tiktok-publisher` skill via the Content Posting API (upload + caption
  with ref on last line), wired into the publish crons; if TikTok's app
  approval stalls, a documented **semi-manual fallback** instead (video +
  caption + cover staged in `ready/`, BalRam posts natively) so TikTok
  distribution is never blocked on the API.
  Gate: test video lands on TikTok (via API or the staged fallback).
  *Why 🟠: the API requires TikTok's app audit/approval — not guaranteed;
  verified at build (tech spec §1.4).*

- [ ] **T2.1 — Create publish crons (pilot, warm-up aware)** 🟢 `$0`
  Owner: Muse Bandhu · Dep: T1.6, T1.7, T1.10, T1.11, T1.12, T1.14, T1.15, T1.16 · Output:
  scheduled jobs for the pilot slots (cadence-, review- and warm-up-aware:
  week 1 at 1 video/day, week 2 at 2/day, full cadence from week 3),
  writing to the ledger.
  Gate: cron list confirmed; first run time agreed.

- [ ] **T2.3 — Automated impact & popularity reports (organic)** 🟢 `$0`
  Owner: Muse Bandhu · Dep: T2.1, T1.17, T1.21 · Output: (1) nightly metrics pull into
  `state/metrics.jsonl`; (2) weekly **Content impact & popularity**
  report — per-video velocity (views/hour, first 48h), retention,
  engagement rate, follower/sub attribution, format leaderboard, breakout
  flags for paid promotion; (3) on-demand — "how did this week's videos
  do?" any time. Sunday digest keeps the scale/kill/test calls.
  (4) monthly **winner recycling** — top-decile videos → cutdowns,
  "best of" compilations, and 30-day reposts with fresh hooks (each gets
  its own ref, ledger records `recycled_from`); (5) weekly **remix
  shortlist** — 3–5 breakout videos from larger in-niche creators as
  response-video targets for your approval; (6) **hook-variant testing
  loop** — 2–3 first-3s variants on new formats, retention picks the
  winner, winners promoted into the format template; (7) **organic
  dayparting** — publish slots retuned per platform from audience-online
  data in the weekly digest; (8) **weekly long-form companion** — the
  week's top Shorts recut as an 8–12 min YouTube deep-dive/compilation
  (⚠️ TO-VERIFY: the ≈50× Shorts RPM figure is an open audit item, not a
  settled fact). Gate: first weekly report reviewed together. (Feeds promo
  reports R1/R3.)

- [ ] **T2.5 — First-hour engagement workflow** 🟢 `$0`
  Owner: Muse Bandhu · Dep: T2.1 · Output: a `first-hour.md` runbook +
  ping jobs at publish +15/+30/+45 min surfacing new comments in chat; a
  question-comment seeded at publish to start discussion (via API where
  proven, else staged for BalRam); reply drafts where the API allows,
  otherwise BalRam replies natively. The 60-minute window is the
  highest-leverage organic lever — this makes it a checklist, not a hope.
  Gate: one live publish walks the full 60 minutes.

---

## Phase 3 — Full auto

- [ ] **T3.2 — Health monitoring** 🟢 `$0`
  Owner: Muse Bandhu · Dep: you:T3.1 · Output: 3-day content buffer
  enforced; monthly token/connection health check; quarantine alerts;
  **nightly backup** of `state/` (ledger, queue, metrics) + channel
  configs to an off-VM copy; **disk archival** — work dirs of videos
  published >30 days ago are slimmed (finals + meta kept, intermediates
  dropped); **generation-usage monitor** — weekly usage vs plan allowance
  with an alert at 80%. Health signals feed T1.20's anomaly detection and
  severity-tiered alerts.
  Gate: buffer verified full once; restore drill from backup passes.

---

## Phase 4 — Expansion (per new theme)

- [ ] **T4.2 (build part) — Clone template, fresh creds, staggered crons** 🟢 `$0`
  Owner: Muse Bandhu · Dep: you:T4.1 · Output: new channel folder from
  template, publisher skills reused, cron set cloned with staggered slots.
  (Accounts + OAuth clicks are Balram Bandhu's — T4.2 in the
  decisions list.)
  Gate: dry run passes.

- [ ] **T4.3 — Pilot → auto for the new channel** 🟢 `media`
  Owner: Muse Bandhu · Dep: T4.2 · Output: repeat of Phase 2–3,
  compressed.
  Gate: same sign-off as you:T3.1.

---

## Dependency map (this list)

```
(you:T1.3) → T1.6 ─┐
(you:T1.4) → T1.7 ─┼→ T1.12 ─┐
                   ├→ T1.13 ─┬→ T2.1 → T2.3
(you:T0.2) → T1.9 ─┴→ T1.11 ─┘ │
(you:T1.1 TikTok) → T1.14 ─────┘
T1.8 ──→ T1.10 ──→ T1.15 ──────┘
(you:T0.2) → T1.16 ──→ (audio library feeds generate-batch)
(T1.6, T1.7, T1.14) → T1.17 ──→ T2.3 (metrics only from proven sources)
(you:T0.1 ✅) → T1.18 (topic engine, guardrailed)
(you:T0.4) → T1.19 (sponsor ledger, media kit, affiliates)
T1.8, T1.9 → T1.20 (observability) → T1.21 (operational reports) → T2.3
T2.1 → T2.5 (first-hour workflow)
(you:T3.1) → T3.2 → (you:T4.1) → T4.2 (build) → T4.3
```

## Cost summary

| | Upfront | Recurring |
|---|---|---|
| Phase 1 setup | **$0** | — |
| Pilot (2 wks, ramped 1→2 vids/day) | — | media for ~21 videos |
| Full auto (3 vids/day) | — | media for ~90 videos/mo (~500–600 clips + up to 90 VO + ~95 images; fewer VOs if calibration drops VO) |

Media generation draws on the Muse plan — usage/allowance can be pulled
any time to sanity-check cadence before scaling.

**How we review:** each task's output is presented; Balram Bandhu says
"adjust" or "done". Checkboxes tick as we go; this file stays current.
