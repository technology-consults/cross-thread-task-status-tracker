# Short-Video Pipeline — Task List (Decisions & Approvals)

Companion to `plan.md`. **Every task here is owned by
Balram Bandhu** — these are your decisions, manual actions, and approval
gates. (Muse Bandhu's build work lives in `tasks-muse.md`; promotion is
a separate pipeline: `../promotion/plan.md`, `../promotion/tasks-balram.md`,
`../promotion/tasks-muse.md`, plus both tech specs. Locked decisions:
`../reference/decisions-log.md`.)

Work top-to-bottom: each task has a **review gate** — Muse Bandhu presents
the output, you say **"adjust"** (what to change) or **"done"** (move on).
Nothing downstream starts until its dependencies are done. One task at a
time, in dependency order — no checkbox is ticked early.

**Automation indicator** (what does this task need from you?):
- 🟡 Needs your decision, review, or approval.
- 🔴 Manual action required — Muse *cannot* do this; you do it yourself
  (Muse Bandhu guides each step).

**Cost tag:** `$0` · `media` = draws on your Muse plan (video/TTS/image
generation) · `ads` = ad spend (lives in the promo pipeline).

---

## Phase 0 — Decisions (finalize the idea)

- [x] **T0.1 — Lock the niche for channel #1 (+ shortlist for #2)** 🟡 `$0`
  ✅ **DONE 2026-09-24** — you said "done".
  Owner: Balram Bandhu · Dep: — · Output: **Channel #1 = AI Technology
  Education** (AI-generated original illustrations + own automated real
  screen captures; news-reactive: product/feature announcements, new
  tools, pricing/cost changes; no AI mock interfaces as genuine
  screenshots; no internet media without disclosure + approval).
  Backups: **#1 history & mythology explainers**, **#2 real-world crime
  news** (strictly scoped — universal guardrails apply). Universal content
  guardrails locked for all niches/channels (see plan §12).

- [ ] **T0.2 — Brand kit: pick name, voice, style** 🟡 `$0` *(in progress)*
  Owner: Balram Bandhu · Dep: T0.1 ✅ · Output: brand name + handles,
  narrator voice, caption style, hashtag sets.
  Status 2026-09-25: 10 names screened against YouTube/TikTok/Instagram —
  **7 taken** (The AI Brief, ByteSized AI, AI Decoded, The Prompt Lab,
  Model Behavior, AI Unpacked, The AI Edge); 2 risky (Promptly, Machine
  Minded); **Neural Notes recommended as cleanest**. 4 narrator samples
  rendered and awaiting your listen: `../brand/voice-warm.mp3`,
  `../brand/voice-smooth.mp3`, `../brand/voice-sleek.mp3`,
  `../brand/voice-radiant.mp3`. Caption style + hashtag sets still to
  draft once the name is picked.
  Gate: you pick the name, voice, and style.

- [ ] **T0.3 — Operating parameters: lock the numbers** 🟡 `$0`
  Owner: Balram Bandhu · Dep: T0.1 ✅ · Output: videos/day (default 3),
  publish slots, monthly ad budget cap, publish mode (per-video approval
  vs full-auto after pilot), language, default campaign duration for later
  promo use. (Muse Bandhu proposes; you lock.)
  Gate: you lock the numbers.

- [ ] **T0.4 — Sponsorship & affiliate decisions** 🟡 `$0`
  Owner: Balram Bandhu · Dep: T0.2 · Output: approve the auto-generated
  media kit (built from real metrics — tech T1.19), the rate-card
  framework, the sponsor prospect shortlist, and outreach templates;
  approve/decline affiliate program applications. **Manual gates stay
  yours:** identity/tax details, application submissions, outreach sends,
  negotiation, and closing.
  Gate: media kit + rate card approved; first outreach batch approved.

- [ ] **T0.5 — Alert thresholds & report format** 🟡 `$0`
  Owner: Balram Bandhu · Dep: T0.2 · Output: severity-tier thresholds for
  this pipeline's alerts (what counts as P1/P2/P3), and the format of the
  daily production report + weekly content summary. (Muse Bandhu proposes
  from the observability design — tech T1.20/T1.21.)
  Gate: you lock the thresholds and formats.

---

## Phase 1 — Your setup actions (one-time, ~2–3 hours)

- [ ] **T1.1 — Create the four accounts** 🔴 `$0`
  Owner: Balram Bandhu · Dep: T0.2 · Output: YouTube channel + Instagram
  professional account + Facebook Page + TikTok account, IG linked to the
  FB Page. (Muse Bandhu guides each click.)
  Gate: you confirm all four are live and linked.
  *Why manual: platforms require the account holder's own clicks/consent.*

- [ ] **T1.2 — Connect IG + FB (OAuth clicks)** 🔴 `$0`
  Owner: Balram Bandhu · Dep: T1.1 · Output: accounts linked via Meta
  Accounts Center. (Muse Bandhu verifies with the CLIs afterwards.)
  Gate: both connections verified live.

- [ ] **T1.3 — Google Cloud + YouTube API setup** 🔴 `$0`
  Owner: Balram Bandhu · Dep: T0.2 · Output: GCP project, OAuth client
  with `youtube.upload` scope, app in Testing mode with you as test user,
  refresh token in the Secure Vault. (Muse Bandhu prepares every value to
  paste.)
  Gate: token stored; test call succeeds.

- [ ] **T1.4 — Meta app + Page token** 🔴 `$0`
  Owner: Balram Bandhu · Dep: T1.1 · Output: Meta developer app with the
  needed permissions, long-lived Page token in the Secure Vault.
  (Muse Bandhu prepares the config; you create the app and complete the
  secure entry.)
  Gate: token stored; test Page read succeeds.

- [ ] **T1.5 — Submit the YouTube quota-increase request** 🟡 `$0`
  Owner: Balram Bandhu · Dep: T1.3 · Output: increase request filed with
  Google (takes weeks — filed early on purpose). (Muse Bandhu drafts the
  submission; you submit under your identity.)
  Gate: confirmation receipt saved.

---

## Phase 2 — Pilot (2 weeks, per-video approval)

- [ ] **T2.2 — Pilot publishing: your per-video approval** 🟡 `media`
  Owner: Balram Bandhu · Dep: tech T2.1 · Output: ~21 videos published
  across YT/IG/FB/TikTok over 2 weeks (warm-up ramp: 1/day week 1, 2/day
  week 2) via the review flow (unlisted + chat link → your approval
  promotes to public; batched — one review session per day, ~15–20 min).
  Topic-engine candidates also route through your approval during the
  pilot (guardrail enforcement is automatic; editorial taste is yours).
  Cost: ~105 clips + ~21 voiceovers + ~21 images for the pilot.
  Gate: weekly check-in — keep, tweak, or kill formats. Your corrections
  steer the output toward the vision. The week-4 check-in carries the
  explicit **go / pivot / pause** verdict for the channel (plan §9).

- [ ] **T2.4 — Approve promo parameters, kick off promotion** 🟡 `$0`
  Owner: Balram Bandhu · Dep: T2.2 (need organic winners first) ·
  Output: promo parameters locked (promo plan P0.1); promotion starts on
  its own track while the pipeline keeps publishing.
  Gate: you approve the promo numbers; promotion runs separately from here.

---

## Phase 3 — Full auto

- [ ] **T3.1 — "Go auto" + vision-lock sign-off** 🟡 `media`
  Owner: Balram Bandhu · Dep: T2.2 review · Output: pilot sign-off
  recorded, cadence raised to 3/day (adjustable any time by single
  prompt), per-video approval off; **vision-lock check** — if the content
  now consistently matches the vision, review mode switches off;
  re-enable any time by prompt ("turn review back on"). Learning-driven
  pipeline changes need your approval during the pilot; bounded automatic
  adjustments are considered only after full automation is authorized.
  Cost at scale: ~450 clips + 90 voiceovers + 90 images/month.
  Gate: you say "go auto" (and "lock the vision" when the output's there).

---

## Phase 4 — Expansion (month 3+, per new theme)

- [ ] **T4.1 — Theme #2: approve the brief** 🟡 `$0`
  Owner: Balram Bandhu · Dep: T3.1 stable · Output: new theme bible +
  brand config. (Muse Bandhu drafts from a 5-minute brief.)
  Gate: you approve theme #2.

- [ ] **T4.2 (your part) — New channel accounts + OAuth clicks** 🔴 `$0`
  Owner: Balram Bandhu · Dep: T4.1 · Output: second quartet of accounts
  created and connected (same manual steps as T1.1–T1.4). (Muse Bandhu
  handles skill reuse, scaffolding, and staggered schedules — tech T4.2.)
  Gate: accounts live; dry run passes.

---

## Ongoing — monthly (after launch)

- [ ] **TM.1 — Monthly stale-content review sign-off** 🟡 `$0`
  Owner: Balram Bandhu · Dep: T3.1 · Output: housekeeping pipeline's
  monthly review (accuracy, relevance, links, sponsor obligations, newer
  versions) presented with a triage proposal per stale video —
  update-in-place, trim + redirect, or full remake. **Nothing is ever
  deleted**; unlist only if fully outdated AND misleading/inaccurate.
  Hiding anything with active sponsor obligations is blocked unless the
  contract allows it.
  Gate: you approve the month's remediation actions.

---

## Dependency map (this list)

```
T0.1 ✅ → T0.2 → T1.1 → T1.2
     ↘ T0.3 · T0.4 · T0.5
T0.2 → T1.3 → T1.5
T1.1 → T1.4
(tech T2.1) → T2.2 → T2.4 → T3.1 → T4.1 → T4.2 (your part)
T3.1 → TM.1 (monthly)
```

**How we review:** Muse Bandhu presents each task's output, you say
"adjust" or "done". Checkboxes get ticked as we go; this file stays current.
