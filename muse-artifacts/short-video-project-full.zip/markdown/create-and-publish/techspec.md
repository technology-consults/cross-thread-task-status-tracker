# Short-Video Pipeline — Technical Specification

Companion to `plan.md` (the what/why). This file is
the how: APIs, schemas, scripts, and build details.
**Build tasks:** `tasks-muse.md`
**Locked decisions referenced:** `../reference/decisions-log.md` ·
**Guardrails:** `../reference/content-guardrails.md` ·
**Architecture:** `../reference/architecture.md`

> This spec covers the **create-and-publish pipeline** only. Each of the
> five pipelines owns its own observability (own tracking, failure
> patterns, self-healing, anomaly detection, severity-tiered alerts) and
> its own operational reports; they share a learning knowledge base. The
> performance-monitoring pipeline owns the shared reporting framework and
> the R1/R2/R3 cross-pipeline rollups.

## 1. Platform integrations

### 1.1 YouTube — Data API v3 (custom `youtube-publisher` skill)

No YouTube skill exists in Muse today — built once with the
`skill_creator` workflow, reused by every channel.

- **Auth:** GCP OAuth 2.0 client, `youtube.upload` scope. For own
  channels, keep the GCP app in **Testing** mode with the owner as test
  user — no Google verification needed. Refresh token → Secure Vault
  (`credentials.request_api_access`); the skill mints short-lived access
  tokens. Tokens never touch files, memory, or logs.
- **Upload:** `videos.insert` (resumable). Vertical ≤3 min + `#Shorts` ⇒
  Short automatically.
- **Scheduling (native):** `status.privacyStatus="private"` +
  `status.publishAt` (RFC-3339) — YouTube auto-publishes at the slot.
- **Promote (review flow):** `videos.update` flipping privacyStatus
  unlisted→public (50 units).
- **Quota — the critical constraint:** default project quota is
  **10,000 units/day**. `videos.insert` ≈ **1,600 units** (verify the
  current cost at build — sources conflict) ⇒ ~6 uploads/day on one
  project, minus `videos.update`/`thumbnails.set` (50 each).
  **Compliant capacity plan:** one GCP project; file the quota-increase
  request early (Google audit, takes weeks). Do NOT create extra projects
  to dodge quota unless Google explicitly authorizes it. The publisher
  tracks spend per project in `state/quota.json` and stops cleanly at 90%
  (`quotaExceeded` → re-queue for next window).
- **Analytics:** YouTube Analytics API, read-only (~1 unit/call).

### 1.2 Instagram — `instagram-cli` (built-in skill)

- **Prereqs:** account connected via Meta Accounts Center
  (`instagram-cli accounts` to verify); professional account required —
  verify Business vs Creator at build.
- **Publish:** `instagram-cli post-feed --account-id <id> --file final.mp4
  --cover cover.jpg --video-thumbnail-playback-offset-ms 1200
  --caption '<caption>'` → Reel shared to feed + grid.
- **Hard limits:** 100 MB/file; 9:16 1080×1920; per-account daily publish
  limit (pipeline caps slots conservatively); **no auto-retry on publish**
  — a retry could double-post. Ledger marks "attempted" before the call;
  failures → manual review.
- **Scheduling:** no reliable native scheduling via this CLI — the cron
  job fires at slot time and publishes live.
- Media must live under the workspace path (never `/tmp`) before posting.

### 1.3 Facebook — Graph API (custom `meta-page-publisher` skill)

`facebook-cli` is read-only for posts — publishing goes through the Meta
Graph API via a small custom skill (built once with `skill_creator`).

- **Prereqs:** Meta developer app + Facebook Page; long-lived Page access
  token (derived from a long-lived user token — effectively non-expiring)
  → Secure Vault.
- **Permissions:** `pages_manage_posts`, `pages_read_engagement` (verify
  current requirements at build).
- **Upload:** `POST /{page-id}/videos` to `graph-video.facebook.com`
  (multipart). Since mid-2025 all Facebook videos publish as Reels.
  Spec: 9:16 1080×1920, MP4/H.264 + AAC, ≥3s.
- **Scheduling (native):** `published=false` +
  `scheduled_publish_time=<unix>` (≥10 min out).
- **Rate limits:** ~200 calls/hour per Page token — trivially fine;
  exponential backoff on 429.

### 1.4 TikTok — Content Posting API (custom `tiktok-publisher` skill)

Built once with `skill_creator`, reused by every channel. ⚠️ This is the
least certain integration — the API exists but requires an **app audit /
approval** from TikTok before posting works, and approval is not
guaranteed. Build it against a sandbox first; if approval stalls, TikTok
publishing degrades to a documented **semi-manual step** (video + caption
+ cover staged in `ready/`, BalRam posts natively) until the API path is
unblocked. TikTok's organic reach per post (benchmarked at build against
current figures) justifies the integration attempt either way.

- **Prereqs:** TikTok developer app (approved for Content Posting API);
  user access token → Secure Vault.
- **Upload:** `POST /v2/post/publish/video/init` (FILE_UPLOAD) →
  `final.mp4` (9:16 1080×1920, ≤287.6 MB per current docs — verify) +
  caption with ref on the last line.
- **No native scheduling** on the posting API at time of writing — the
  cron job fires at slot time and publishes live (same pattern as IG).

### 1.5 Verification checklist (prove before treating as spec)

- [ ] Current `videos.insert` quota cost (docs conflict).
- [ ] Quota-increase request path and realistic grant size (no promises
      of "1M+ units/day").
- [ ] IG publishing: Business-only or Business + Creator.
- [ ] FB video/Reel endpoints, permissions, token lifetime, scheduling
      params against current docs.
- [ ] TikTok Content Posting API: current app-approval process, upload
      limits, and whether scheduling exists yet. Define the semi-manual
      fallback precisely if approval is blocked.
- [ ] YouTube AI-disclosure ("altered content") API field support;
      fallback = manual Studio check per batch.
- [ ] YouTube YPP originality review: current stance on high-volume
      AI-generated channels (repetitious-content policy); what evidence
      of human creative input reviewers expect.
- [ ] Retention data sources per platform (YouTube Analytics API;
      Instagram / Facebook / TikTok availability) — define proxy metrics
      where true retention is unavailable, before T2.3 is built.
- [ ] FFmpeg present on the VM (else install at T1.8).
- [ ] Story poll/question stickers, comment reply/pin, Trial Reels via
      API — assume **unsupported** until a working integration is proven;
      never promise them.
- [ ] Native duet/stitch cannot be driven via API on any platform — the
      pipeline's remix/response format is an **original response video**
      (with credit to the source), produced through the normal pipeline,
      not a platform duet. Never claim otherwise.
- [ ] Never claim paid views directly cause organic distribution.
- [ ] ⚠️ **TO-VERIFY (open audit items — not settled facts):** (a) claims
      that YPP thresholds will change in February 2027; (b) claims that
      finance is categorically blocked for AI personas; (c) the working
      figure that long-form earns ≈ 50× Shorts RPM (used in §4
      `longform-compile`). Verify each against current official/reliable
      sources before asserting in any report, plan, or external material.

## 2. Workspace layout

```
~/workspace/video-pipeline/
├── channels/
│   ├── _template/                 # clone for each new channel
│   │   ├── brand.yml              # name, voice id, caption style, hashtag sets, review block
│   │   ├── theme-bible.md         # niche, audience, pillars, do/don't list, guardrail notes
│   │   ├── cadence.yml            # videos/day + scope; single-prompt adjustable
│   │   └── accounts.json          # channel/page/account ids (no secrets)
│   ├── <channel-1>/               # ai-tech-education
│   │   ├── ideas/queue.json       # ranked idea queue
│   │   ├── work/<video-id>/       # script.txt, vo.mp3, clips/, final.mp4, cover.jpg, meta.json
│   │   ├── ready/                 # QC-passed videos awaiting publish
│   │   └── published/             # posted videos + per-platform receipts
│   └── <channel-2>/ …             # same layout
├── shared/
│   ├── scripts/                   # assemble.sh, captions.py, qc.py, publishers/
│   ├── skills/                    # youtube-publisher, meta-page-publisher
│   └── audio/                     # reusable beds/stingers (original/AI-generated by default)
├── state/
│   ├── ledger.json                # keyed by video ref: platform ids, status, metrics
│   ├── sponsor-ledger.json        # per-video sponsor/deal obligations (§3)
│   ├── quota.json                 # YouTube quota spend per GCP project
│   ├── failures.jsonl             # this pipeline's bug/failure/performance events
│   └── failure-patterns.md        # captured recurring patterns + what fixed them
└── reports/
    ├── daily/                     # production reports (this pipeline's own)
    └── weekly/                    # content performance summaries
```

## 3. File schemas

**`brand.yml`** (per channel): name, handles, voice_id, caption_style,
hashtag_sets, packaging_rules (per-platform title/caption tuning),
language,
`review: {enabled, destination (youtube_unlisted|youtube_private|review_channel|chat_preview),
review_channel_id, auto_promote_after_hours}`.

**`cadence.yml`**: `videos_per_day`, `scope`
(today|this_week|this_month|until_changed), `set_on`. Every publish job
re-reads it at run time; scoped overrides auto-revert on expiry (Monday
check restores default); current setting shown in the weekly digest.

**`accounts.json`**: channel/page/account IDs only — no secrets.

**`meta.json`** (per video): ref, idea_id, script_hash, vo_voice, clips[],
cover, qc_report, created_at, sponsor_ref (nullable → sponsor-ledger entry).

**`ledger.json`**: keyed by video ref →
`{platforms: {youtube: {video_id, status, url, published_at}, instagram:
{…}, facebook: {…}}, superseded_ids[], metrics_ref}`. **Nothing is ever
deleted from the ledger** — unlisted/hidden videos keep their records.

**`sponsor-ledger.json`** (per video with sponsor/affiliate
integration): `{sponsor/brand, contract_id, campaign_id,
minimum_live_until, required_links_text, pinned_comment_required,
onscreen_audio_integration, usage_rights, exclusivity, restrictions,
approval_contact, status}`. Any hide/unlist/material-alter action on the
video is **blocked while obligations are active** unless the contract
explicitly permits it; the `video` command checks this ledger first.

**`quota.json`**: per GCP project: date, units_used, uploads.

**`failures.jsonl`**: this pipeline's own bug/failure/performance event
log — timestamp, stage, ref, error class, retry count, outcome. Feeds
`failure-patterns.md` and the shared learning knowledge base.

## 4. Content pipeline implementation

- **Topic engine (`topic-engine`):** candidate sources = official product
  and feature announcements, new tools, pricing/cost changes, announced
  launches and event calendars, search/platform trends, and performance
  data from prior videos (via the learning knowledge base). Every
  candidate is compared against the full content ledger — near-duplicates
  rejected, meaningful episode-to-episode variation preserved. **The
  universal content guardrails are enforced at ideation, before any
  scripting:** candidates violating the guardrails (or the channel's
  editorial scope — e.g. no negative reputational news for AI Technology
  Education) are rejected, or flagged for BalRam's review. The engine
  reacts to unannounced news; it never pretends to predict it. During the
  pilot, candidates route through BalRam's approval gate. Full-auto runs
  idea→publication without routine human handling only after "go auto".
- **Script template rules:** spoken form only (numbers spelled out,
  abbreviations spaced, no URLs/stage directions); hook in first 8 words;
  one idea per sentence.
- **TTS:** `tts` CLI — fixed voice per channel, used only where the
  calibration VO policy calls for it (full / none / hybrid per format);
  `tts synthesize-script` for multi-speaker skits.
- **Video:** `media.generate_video` ≈ 10s/call → 4–6 clips per video;
  `snapshot_id` carried forward for visual continuity; mood-described
  audio bed in the prompt. For channel #1 the visual mix is
  AI-generated original illustrations + our own automated real screen
  captures of the tools/actions being explained. **AI-generated mock
  interfaces are never presented as genuine screenshots.**
- **Covers:** `media.generate_image`, 9:16 1080×1920 (IG cover; YT Shorts
  uses the first frame as thumbnail).
- **Assembly (`assemble.sh`):** concat clips → build SRT from script timed
  against VO duration (`ffprobe` the mp3, distribute sentences
  proportionally) → ffmpeg render: 1080×1920, H.264, 30fps, AAC 128k,
  ≤100 MB, burned-in captions (DejaVu Sans 24, outline), VO mixed over
  bed (bed at 0.25), `+faststart`.
- **QC (`qc.py`):** ffprobe checks (duration, resolution, codec, size);
  3 extracted frames visually verified (no garbled text/black frames);
  first/last caption sync spot-check. Failures → `quarantine/` + reason
  log; job moves to next idea. Rejection reasons are categorized and fed
  to the failure-pattern history.
- **Hero tier:** `generate-batch` produces 2 volume + 1 hero per day.
  Hero = up to 8 clips (vs 4–6), 2–3 hook variants rendered for new
  formats, extra QC pass (5 frames), priority slot in the publish queue.
- **Loopable format:** script written so the closing line flows into the
  opening line; `assemble.sh` crossfades audio and matches first/last
  frames for a seamless loop.
- **Per-platform packaging:** the packaging step emits per-platform
  variants from `brand.yml` `packaging_rules` — YouTube: keyword-first
  title + `#Shorts`; TikTok: trend-native caption; IG: share/save CTA +
  hashtag mix. Ref on the last line everywhere. Sponsor/affiliate videos
  additionally inject the ledger-required links/text, pinned-comment
  content, and on-screen/audio integration markers.
- **Evergreen input:** `trend-scan` also pulls search-suggestion keywords
  (YouTube/TikTok) for "what is X" explainers; evergreen ideas are tagged
  and never expire from the queue.
- **Weekly long-form (`longform-compile`):** the week's top Shorts →
  an 8–12 min YouTube deep-dive/compilation (scripted bridges, existing
  clips reused + fresh VO), published as long-form via
  `youtube-publisher`. ⚠️ *TO-VERIFY: the working figure of ≈50× Shorts
  RPM is an open audit item — treat as hypothesis until verified.*
- **Audio library (`shared/audio/`, built once in T1.16):** ~20–30
  **original/AI-generated** background beds + stingers, loudness-normalized
  and mood-tagged to the channel brand, so no video generates music from
  scratch. Default is original/AI-generated audio; licensed commercial
  beds are used only if BalRam explicitly approves them. (Trending
  commercial sounds stay a manual native swap on winners — promo plan §3.)
- **Media kit generator (`media-kit`):** auto-generates a sponsor media
  kit from **real channel metrics** (subscribers, views, engagement,
  audience) pulled from the ledger + metrics — never invented numbers.
  Output reviewed and approved by BalRam before any outreach.
- **Affiliate scaffolding:** tracked-link hub (one canonical link per
  program + per-video tracked variants), CTA rotation config in
  `brand.yml`, click/conversion ingestion feeding revenue attribution.
- **Winner recycling (monthly job `recycle-winners`):** select top-decile
  videos by velocity from `state/metrics.jsonl` → (a) **cutdowns:** best
  15s slice re-rendered via `assemble.sh` variant as a new Short;
  (b) **30-day reposts:** proven videos re-published with fresh
  hook/cover. ("Best of" compilations are owned by the weekly
  `longform-compile` job — no duplication.) Every recycle gets its own
  ref; ledger records `recycled_from: <original ref>`. Reposts go through
  the same review gate as new videos during the pilot.
- **Remix/response format:** weekly `trend-scan` also outputs a remix
  shortlist (3–5 larger creators' videos in-niche with breakout
  velocity). Approved targets become response videos — original scripted
  takes with on-screen credit to the source — produced through the normal
  pipeline. (Native duet/stitch buttons are not API-drivable; see §1.5.)

## 5. Orchestration

| Job | When (ET) | What |
|---|---|---|
| `trend-scan` | 05:30 daily | Refresh idea queue from trends + analytics; weekly remix shortlist; evergreen keyword input |
| `generate-batch` | 06:00 daily | Produce until 3-day buffer is full (2 volume + 1 hero/day) |
| `publish-slot-1/2/3` | 08:00/13:00/19:00 daily | Publish next ready video → YT, IG, FB, TikTok |
| `metrics-pull` | 23:30 daily | Per-video stats → `state/metrics.jsonl` |
| `weekly-review` | Sun 09:00 | Digest + scale/kill/test calls; hook-variant winners → template; retune publish slots per platform (dayparting) |
| `recycle-winners` | 1st of month 07:00 | Cutdowns + 30-day reposts from top decile |
| `backup-state` | 02:00 daily | Snapshot `state/` + channel configs (off-VM copy) |
| `longform-compile` | Mon 08:00 weekly | Weekly 8–12 min YouTube deep-dive from top Shorts |
| `promo-handoff-check` | Mon 10:00 | Prompt to start promo plan once winners exist |
| `production-report` | 23:45 daily | This pipeline's own operational report (see §10) |

- **Idempotency:** ledger checked before every publish call — at most one
  publish per video per platform; reruns resume incomplete platforms.
- **Buffer:** 3-day ready buffer; generation retries ≤3x with backoff.
- **Failures:** publish failures never blind-retry — they page into the
  daily ops digest.

## 6. Review flow implementation

- `review:` block in `brand.yml` (§3); per-run prompt override
  ("send this one for review first", "skip review for this batch").
- `youtube-publisher --review` uploads unlisted and returns the URL;
  `promote <ref>` flips to public/scheduled via `videos.update`.
- IG/FB review = chat preview (video + caption); nothing posts until
  approved.
- Temporary by design: on through the initial weeks; your "lock the
  vision" sets `review.enabled=false`; re-enable any time by prompt
  (optionally with `auto_promote_after_hours` as a safety net).

## 7. Reference scheme implementation

- Assigned at generation: `<channel>.yyyy.MM.dd.N` (N = daily sequence,
  1–5; cap configurable in channel config).
- Stored in `meta.json`; ledger keyed by ref (§3); embedded as the last
  line of the description/caption on all four platforms (human-searchable
  fallback — ledger is the machine source of truth).
- `video` command actions: `status` / `unpublish` / `remove` /
  `adjust`+republish / `block|unblock comments` / `comment` / `report` /
  `promote` / `review`.
- `adjust`+republish: metadata edits in place; new media = delete +
  re-upload (platforms can't swap files) — old IDs move to
  `superseded_ids[]`, ref stays constant.
- `remove` always confirms first, even in full-auto. Platform gaps →
  explicit manual step, never silent.
- `unpublish`/hide actions check `sponsor-ledger.json` first: blocked
  while sponsor obligations are active unless the contract explicitly
  permits it. **Nothing is ever deleted** — unpublish means unlisted /
  private / archived per platform, and only when content is fully outdated
  AND misleading/inaccurate (stale-content policy, plan §9).

## 8. This pipeline's observability (self-governance)

Independent of the other four pipelines; shared patterns are written back
to the learning knowledge base.

- **Own event tracking:** `state/failures.jsonl` logs every bug, failure,
  and performance event for this pipeline (generation failures, QC
  rejects by category, publish failures, quota events, buffer breaches).
- **Failure-pattern history:** `state/failure-patterns.md` captures
  recurring patterns and what fixed them; QC-rejection categories feed
  back into generation prompts.
- **Self-healing (bounded):** predefined mechanisms with automated
  execution plans — generation retries ≤3 with backoff, fallback
  models/endpoints, quarantine of broken outputs (`quarantine/` + reason
  log). Repeated healing failures **escalate** instead of looping: the
  job stops, the pattern is logged, and a P2 alert fires.
- **Anomaly detection:** watches for unfavorable conditions, exception
  scenarios, weak growth, and bottlenecks — e.g. the 3-day buffer
  draining, quota burn running hot, a format's retention collapsing, a
  stage's failure rate spiking.
- **Severity-tiered alerts:** P1 = needs BalRam now (publishing fully
  halted, quota exhausted mid-day); P2 = needs a decision soon (repeated
  self-healing failures, buffer below 1 day); P3 = informational (a format
  trending down, usage at 80% of allowance). Tiers are set by importance,
  occurrence rate, urgency, and the need for human review, approval, or
  intervention — thresholds locked with BalRam in T0.5.

## 9. Security

- All tokens/keys in the Secure Vault via hosted capture pages — never
  pasted in chat, never in files/memory/logs.
- One standing authorization for scheduled publishing (recorded in memory
  + plan). Ad spend always needs per-campaign approval.

## 10. This pipeline's operational reports

Defined and produced by this pipeline (tech task T1.21); they feed the
shared R1 cross-pipeline rollup owned by the performance-monitoring
pipeline's reporting framework.

- **Daily production report** (`reports/daily/`): videos made, QC
  pass/reject counts with rejection categories, buffer health (days of
  ready video), cost per video, generation usage vs allowance, failures
  and self-healing actions taken.
- **Weekly content performance summary** (`reports/weekly/`): per-video
  velocity (views/hour, first 48h), retention, engagement rate,
  follower/sub attribution, format leaderboard, breakout flags for paid
  promotion, scale/kill/test calls.
- On-demand: "how did this week's videos do?" any time.

## 11. Key references

- YouTube Data API v3 quota & `videos.insert` costs — Google Cloud docs
  (verify current figures at build)
- Meta IG Graph API — Content Publishing:
  https://developers.facebook.com/documentation/instagram-platform/content-publishing/
- Meta video upload (resumable):
  https://developers.facebook.com/documentation/instagram-platform/content-publishing/resumable-uploads
- Google Ads — YouTube Shorts Video View campaigns:
  https://support.google.com/google-ads/answer/16041302?hl=en
- Google Ads — Shorts asset specs:
  https://support.google.com/google-ads/answer/16041697?hl=en
