# Short-Video Content Pipeline — Plan

**Owner:** Balram Bandhu · **Built & operated by:** Muse Bandhu
**Date:** 2026-09-23 · **Updated:** 2026-09-24 — T0.1 done; locked decisions incorporated
**Status:** In build (Phase 0)
**Technical spec:** `techspec.md`
**Tasks:** `tasks-balram.md` (decisions & approvals — yours) ·
`tasks-muse.md` (build work — Muse's)
**Sibling systems:** `../promotion/plan.md` (paid + organic promotion —
separate pipeline, separate docs) · `../reference/` (locked decisions,
brand kit, guardrails, platform policies, research) · `../ledgers/`
(operational records)

> This document covers the **create-and-publish pipeline** only: ideation
> through publication. It is one of five independent pipelines, each with
> its own codebase, its own docs, and its own observability —
> **create-and-publish** (this), **promotion**, **housekeeping**,
> **performance-monitoring**, and **earnings-improvement**. They share a
> learning knowledge base (see §12). Locked decisions referenced here live
> in full in `../reference/decisions-log.md`.

## 1. Vision

A fully automated short-video factory run by Muse: every day, multiple
vertical short videos (30–60s) are ideated, scripted, voiced, rendered,
assembled, and published to **YouTube (Shorts)**, **Instagram (Reels)**,
**Facebook (Reels)**, and **TikTok** — with zero day-to-day effort from
you after setup. The system is a **replicable template**: launching
channel #2, #3, … with a different theme is copy-and-configure, not a
rebuild.

**Default throughput (adjustable any time):** 3 videos/day × 4 platforms
(2 volume + 1 higher-effort **hero**; hero = 1 per 3 videos, rounding up —
so a 1-video day is all hero).

## 2. Objectives

- Publish 3 videos/day, 7 days/week, on all four platforms.
- Grow subscribers/followers and views on each platform (numeric targets
  set after pilot data).
- Keep production cost per video as low as possible — tracked, not guessed.
- Promotion (separate pipeline) funds only proven organic winners:
  min cost, max impact.
- Every video complies with the universal content guardrails and the
  original-media rule (see §3–§4); the topic engine enforces them at
  ideation, before any generation.
- The pipeline watches itself: own failure tracking, failure-pattern
  learning, bounded self-healing, and severity-tiered alerts (see §12).

A weekly automated review decides which formats to scale and which to kill.

## 3. Channel setup

- **Channel 1 (primary): AI Technology Education** ✅ locked 2026-09-24
  (T0.1 done). Production approach: **AI-generated original
  illustrations** + **our own automated real screen captures** of
  tools/actions. Never present AI-generated mock interfaces as genuine
  screenshots. No publicly sourced internet media without explicit
  disclosure and your approval. News-reactive topics focus on **product
  launches, feature announcements, new tools, and pricing/cost
  changes** — never negative reputational news, scandals, or
  controversies. Voiceover policy is set by T1.15 calibration (early
  samples were preferred without voiceover even though the voice sounded
  realistic). One brand = one YouTube channel + one Instagram
  professional account + one Facebook Page + one TikTok account, all
  linked together.
- **Backup #1:** History & mythology explainers (pivot insurance for the
  week-4/week-8 evaluations — not a commitment to launch now).
- **Backup #2:** Real-world crime news — strictly scoped: nothing
  sensitive or objectionable, nothing involving children, no current
  politics, nothing controversial or inappropriate.
- **Universal content guardrails** (all current and future niches and
  channels): no sensitive or objectionable content; nothing involving
  children; no current politics; nothing potentially controversial or
  otherwise inappropriate. The topic engine enforces these at ideation;
  violations are rejected or flagged for your review. Full text:
  `../reference/content-guardrails.md`.
- **Future channels:** each new theme gets its own quartet of accounts and
  its own config. Accounts are never shared across themes — platforms
  reward topical consistency, and it isolates risk.

## 4. How videos get made

Each video goes through the same 7 stages. Stages 1–6 run unattended on
schedule; stage 7 publishes.

1. **Ideation (topic engine).** The engine autonomously finds candidate
   topics from: official product and feature announcements, new tools,
   pricing and cost changes, announced launches and event calendars,
   search/platform trends, and performance data from prior videos. Every
   candidate is compared against the full content ledger — near-duplicates
   are rejected, and meaningful episode-to-episode variation is preserved.
   **Guardrails are enforced here, before scripting:** candidates that
   violate the universal content guardrails (or the news-reactive scope
   for AI Technology Education) are rejected or flagged for your review.
   The engine reacts to unannounced news rather than pretending to
   predict it. During the pilot, candidates route through your approval
   gate. Output: a ranked queue of video ideas.
2. **Script.** Muse writes a voiceover-ready script (~120–150 words ≈
   45–60s): hook in the first seconds, one idea per sentence for clean
   captions.
3. **Voiceover.** Per-format policy set in calibration (tech task
   T1.15): full VO, VO-free (text + visuals carry it), or hybrid. Where
   VO is used, it's the channel's fixed narrator voice — the same voice
   every video = brand consistency.
4. **Visuals.** For channel #1: AI-generated original illustrations
   (~10s clips each, 4–6 per video) with visual continuity, plus our own
   automated real screen captures of the tools/actions being explained,
   plus a 9:16 cover image. **All generated media is original — nothing
   is pulled from the internet** (anything else requires disclosure and
   your approval first).
5. **Assembly.** Clips joined, captions burned in, voiceover mixed over
   background audio. Final spec: 1080×1920, 30–60s.
6. **Quality check (automated).** Duration, resolution, file health,
   frame spot-checks, caption sync. Anything broken is quarantined —
   never published.
7. **Packaging.** Title, description, hashtags, and AI-content disclosure
   **tuned per platform, not copied**: YouTube gets search-keyword titles,
   TikTok gets trend-native captions, Instagram gets share/save hooks.
   **Sponsor/affiliate hooks:** videos that carry sponsor or affiliate
   integrations include the required description links/text, pinned
   comment, and on-screen/audio integration per the sponsor obligations
   ledger (`../ledgers/sponsor-obligations.md`); affiliate links come from
   the tracked link hub with CTA rotation.

### Formats

Proven structures the pipeline supports: hook → 3 beats → CTA
(listicles), relatable story/skit, myth-vs-fact hot takes, weekly
trend-jacks in the niche, **seamless loops** (the end flows into the
start — average watch time over 100%), **evergreen explainers** ("what
is X" — compounds via search for months), and **remix/response** — an
original take responding to a larger creator's video in-niche (borrows
their audience; Muse shortlists targets weekly, you approve). Every video
follows the same skeleton: **0–3s hook**, **3–40s payoff**, **last 3s
call-to-action**. **Hero tier:** 1 of every 3 videos is a hero — more
clips, tighter QC, hook variants tested; the rest are volume. (At reduced
cadence the ratio holds: 1 hero per 3 videos, rounding up.)

## 5. Publishing

- **One schedule, four platforms.** Publish slots (default 08:00, 13:00,
  19:00 ET — adjustable) fire automatically; each video goes to YouTube,
  Instagram, Facebook, and TikTok.
- **Warm-up ramp.** New accounts start slow — posting 3 videos/day from
  day one on a fresh account risks spam flags and throttled distribution.
  The pilot doubles as warm-up: week 1 at 1 video/day, week 2 at 2/day,
  full cadence from week 3. Cross-platform post times are staggered, not
  simultaneous.
- **Never a duplicate.** Each video publishes to each platform at most
  once; reruns resume where they stopped.
- **3-day buffer.** The generator keeps three days of ready videos, so a
  bad generation day never means a missed publish day.
- **Broken stays unpublished.** Failed publishes don't auto-retry blindly;
  they land in a daily digest for your review.
- **Dayparted by data.** Default slots 08:00/13:00/19:00 ET; the weekly
  review retunes times per platform from audience-online analytics —
  free reach, zero cost.
- **Native scheduling** where supported (YouTube/Facebook auto-publish at
  the slot time).
- **Sponsor-gated alterations.** Hiding, unlisting, or materially altering
  a published video is blocked while its sponsor obligations are active
  unless the contract explicitly allows it — the sponsor obligations
  ledger is checked before any such action.

### Playlists (YouTube-first)

- **Category playlists.** One playlist per content category — categories
  come from the format taxonomy locked in T0.2 (e.g. explainers,
  myth-vs-fact, stories). Every published video is auto-added to its
  category playlist at publish time 🟢. The channel page stays organized,
  viewers get bingeable shelves, and playlists add a second discovery
  surface (search/SEO) — all with zero ongoing effort.
- **Long-form shelf.** Weekly long-form episodes auto-collect into a
  dedicated "Deep dives" playlist 🟢.
- **"Start here" playlist.** Built rule-based from R1 performance scores:
  the current top-performing videos, refreshed monthly 🟢 — a binge path
  that converts new subscribers.
- **Series playlists.** Multi-part videos grouped in watch order 🟢
  (order comes from series metadata set at creation).
- **TikTok playlists** where the feature is available on the account 🟠
  (partially manual — API support is limited, fallback is manual add).
  Instagram and Facebook have no video-playlist equivalent — skipped
  there.
- **New playlist categories need your ok** 🟡 — categories mirror the
  channel's format taxonomy, so adding one is a channel-structure
  decision, not a background tweak.

## 6. Your control panel — single-prompt controls

- **Cadence:** "2 videos a day this week", "back to 3 a day for October",
  "just one video today" — for a day, a week, a month, or until you change
  it. Scoped changes revert automatically.
- **Review mode:** "send this one for review first", "turn review back on
  for this week".
- **Emergency stop:** "pause all publishing now" — everything halts until
  you say resume.
- **Video actions by reference** (see §7): "unpublish 2026.09.24.3",
  "report 2026.09.24.3", "promote 2026.09.24.3".
- **Campaign controls** live in the promotion plan.

## 7. Video references

Every video gets a short reference at creation:
`<channel>.yyyy.MM.dd.N` (e.g. `ainews.2026.09.24.3`; channel prefix
optional with a single channel; N = 1–5 per day). The ref is printed as
the last line of every description/caption — searchable by you in YouTube
Studio / Business Suite, effectively invisible to viewers — and is the key
for everything: status checks, unpublish, remove, adjust-and-republish,
comment controls, per-video reports, promotion handoff, review.
Destructive actions always ask first. (Storage and resolution mechanics:
tech spec §7.)

## 8. Review flow (initial weeks only)

Until the generated content fully matches your vision, every video goes
through admin review: uploaded as **unlisted** to YouTube (chat preview
for IG/FB/TikTok), you get the link, you say "approve" — it goes public. Each
review is also how you steer the output: your corrections feed back into
the channel's style guide. When the output consistently matches the
vision, you say **"lock the vision"** → review switches off and publishing
goes fully automatic. Re-enable any time with a prompt.

Reviews are **batched**: each day's videos arrive in one session, not one
ping per video — expect ~15–20 min/day of your time during the pilot,
less after vision-lock.

## 9. Analytics, reports & feedback loop

This pipeline defines its **own operational reports** (built in tech task
T1.21): a daily **production report** (videos made, QC pass/reject with
rejection reasons, buffer health, cost per video, generation usage vs
allowance) and a weekly **content performance summary** (per-video
velocity, retention, engagement, format leaderboard, breakout flags).
These feed the shared **R1 cross-pipeline rollup** owned by the
performance-monitoring pipeline's reporting framework — one framework,
many detectors; see `../reference/architecture.md`.

- **Nightly:** per-video views, retention, likes, comments, shares, and
  follows/subs collected automatically.
- **Weekly (Sundays):** a digest in chat — top/bottom 3 videos per
  platform with *why* (hook retention, view duration), a format
  leaderboard, and concrete calls: **scale** (make variants), **kill**
  (retire), **test** (try one new format).
- **Winners feed back in:** successful hooks and formats get priority in
  the idea queue — the system learns weekly. Every video also writes its
  performance outcome back to the **shared learning knowledge base**;
  learning-driven pipeline changes need your approval during the pilot
  (bounded automatic adjustments only after full automation is
  authorized).
- **Project circuit breaker:** at week 4 and week 8, the digest carries
  an explicit **go / pivot / pause** verdict for the channel against
  preset gates (defaults: median views per video and follower growth vs.
  the niche baselines from T0.1 — tuned once the niche is locked). A dead
  niche gets pivoted before it burns months, not after. Backup niches
  (history/mythology, crime news) are the pivot options.
- **Hook-variant testing:** new formats ship with 2–3 different first-3s
  hooks; retention data picks the winner, which becomes the template.
- **Long-form companion (weekly):** the week's top Shorts recut as an
  8–12 min YouTube deep-dive/compilation. ⚠️ *TO-VERIFY: the working claim
  that long-form RPM ≈ 50× Shorts is an open audit item — do not treat as
  fact until verified against current official/reliable sources.*
- **Winner recycling (monthly):** the top 10% of videos get a second life —
  cutdowns (best 15s as a new Short) and reposts of proven videos with
  fresh hooks/covers after 30 days. ("Best of" compilations are owned by
  the weekly long-form job.) Winners keep working; the ledger tracks each
  recycle against its original ref.
- **Stale-content policy (locked 2026-09-24):** **nothing is ever
  deleted.** A monthly housekeeping review checks every video for
  accuracy, relevance, links, sponsor obligations, and newer versions.
  Slightly stale content gets an updated caption/description + links, a
  pinned comment pointing to the newer version, and cards/end screens
  where supported. A stale long-form segment is trimmed where supported
  and redirected. Thoroughly outdated content gets a full remake as a new
  upload — and the old version is hidden/unlisted **only** if leaving it
  public would mislead or be inaccurate. Sponsor obligations always gate
  any hide/alter action. Full triage ladder: §12 and
  `../reference/decisions-log.md`.
- **On demand:** "how did this week's videos do?" any time.

## 10. Promotion — separate pipeline

`../promotion/plan.md` (+ tech spec + two task lists). In short:
**min cost, max impact** — only proven organic winners get paid budget;
budgets climb a ladder (probe → validate → scale) and cut automatically
when efficiency slips; every campaign has a default 7-day duration you can
override; reporting separates organic results, paid results, and measured
relationships. The pipeline hands off at T2.4 once pilot winners exist.

## 11. Multi-channel expansion

Channel #2+ is a checklist, not a project: copy the template folder, fill
in the new theme's brand config (Muse drafts from a 5-minute brief you
approve), create the four accounts, connect credentials, stagger publish
times, run a 2-week pilot, then full-auto. Shared across channels:
publisher integrations, scripts, audio library. Per-channel: theme, voice,
accounts, config.

## 12. Approvals, guardrails & self-governance

| Action | Mode |
|---|---|
| Pilot phase (first ~2 weeks) | Per-video approve in chat |
| Scheduled publishing (after pilot) | Standing approval (revocable anytime) |
| Any ad spend / budget change | Always explicit approval, per campaign |
| New channel launch | Explicit approval |
| Credential changes | You complete the secure step |
| Sponsor outreach / negotiation / closing | Your approval at each step (manual gates) |
| Affiliate program applications | Your approval; identity/tax details are yours |
| Hiding or materially altering a video with active sponsor obligations | Blocked unless contract-approved |
| Learning-driven pipeline changes (pilot) | Your approval |

Muse never: publishes a quality-failed video, double-publishes, raises ad
spend unprompted, shares credentials, invents analytics numbers, deletes a
video, or hides/unlists a video with active sponsor obligations without
contract approval.

### Locked operating method

- One owner per task: you = decisions, manual work, approvals; Muse =
  technical work.
- One task at a time, in dependency order. Each result is presented; you
  reply **"adjust"** or **"done"**. No checkbox is ticked and no
  dependent work starts until you say "done".
- Upfront and recurring costs are stated on every task.
- 🟢/🟡/🔴/🟠 automation indicators are preserved on every task.
- Pilot publishing stays behind per-video approval; full automation begins
  only after "go auto" / "lock the vision" (or equivalent). "Turn review
  back on" restores review. **"Pause all publishing now"** halts
  everything until you say resume.
- Cadence is adjustable by one prompt for a day, week, month, or
  indefinitely.

### Universal content guardrails

Apply to **all** current and future niches and channels: no sensitive or
objectionable content; nothing involving children; no current politics;
nothing potentially controversial or otherwise inappropriate. The topic
engine enforces these at ideation; violations are rejected or flagged for
your review. Full text: `../reference/content-guardrails.md`.

### Original-media rule

All generated video and audio is original. No existing video or audio
from the internet is used without explicit disclosure and your approval.
**Real-human UGC is ruled out** (at least for now) — no real person on
camera. If UGC is ever pursued, it is the AI-avatar/AI-generated tier
only, with appropriate disclosure — or UGC is deprioritized in favour of
affiliates and later sponsorships.

### YouTube originality risk

Channels posting high volumes of AI-made content face extra scrutiny at
monetization review (repetitious-content policy). Mitigation:
format-variety quota (no single format >40% of weekly output), logged
human creative input per video (your calibration decisions + review
corrections count), AI-content disclosure on every upload. Current
platform stance verified at build (tech spec §1.5). ⚠️ *TO-VERIFY: claims
that YPP thresholds will change in February 2027, and that finance is
categorically blocked for AI personas, are open audit items — not settled
facts.*

### This pipeline's own observability

This pipeline watches itself, independently of the other four:

- **Own tracking:** every bug, failure, and performance event is logged
  against this pipeline (generation failures, QC rejects by category,
  publish failures, quota events).
- **Failure-pattern history:** recurring patterns are captured and used —
  QC-rejection categories feed back into generation prompts and the
  shared learning knowledge base.
- **Self-healing (bounded):** predefined mechanisms with automated
  execution plans — generation retries ≤3 with backoff, fallback models,
  quarantine of broken outputs. Repeated failures escalate instead of
  looping forever.
- **Anomaly detection:** watches for unfavorable conditions, exception
  scenarios, weak growth, and bottlenecks (e.g. buffer draining, quota
  burn running hot, a format's retention collapsing).
- **Severity-tiered alerts:** P1 (needs you now — e.g. publishing fully
  halted), P2 (needs a decision soon — e.g. repeated healing failures),
  P3 (informational — e.g. a format trending down). Tiers are based on
  importance, occurrence rate, urgency, and the need for human
  review/approval/intervention. Thresholds are locked with you in T0.5.

## 13. What needs your hands vs what runs itself

- **You, one-time (~2–3 hours):** create the YouTube channel, Instagram
  account, and Facebook Page; click through account linking and OAuth
  consents; add the ad-account payment method when promotion starts.
- **You, decisions:** niche ✅ (done), brand (in progress — T0.2),
  cadence, budgets, pilot video reviews, every ad dollar, sponsor
  outreach/negotiation/closing, affiliate applications, the go-auto
  sign-off.
- **You, manual-only:** identity/tax details for sponsor and affiliate
  programs; account creation and OAuth clicks; trending-audio swaps on
  winners (~2 min each).
- **Muse, everything else:** ideation, scripting, voiceover, visuals,
  assembly, quality checks, publishing, metrics, weekly reviews, campaign
  builds (each launch approved by you), media-kit generation from real
  metrics, sponsor prospect shortlists, outreach drafts and tracking.
- **Honest limits:** paid promotion is built through the ad platforms' web
  UIs — workable but partly manual and fragile to UI changes; trending
  commercial music can't be attached via API, so the pipeline ships with
  original audio (tech task T1.16 — default is original/AI-generated
  audio unless you approve licensed media) — proven winners get trending
  sounds swapped in natively by you (~2 min each, promo plan §3); some
  platform features may need a manual check until verified at build time
  (tech spec §1.4).

## 14. Costs

**Upfront: $0 out-of-pocket** (your time only).
**Recurring:** media generation draws on your Muse plan — each day ≈
16–20 AI clips (2 volume at 4–6 clips + 1 hero at up to 8) + up to 3
voiceovers + 3 cover images, plus ~1 voiceover + 1 thumbnail/week for the
long-form (≈500–600 clips + up to 90 voiceovers + ~95 images/month at
3/day — fewer voiceovers if calibration drops VO, see tech task T1.15).
API calls $0 within quotas. Ad spend = your cap (pilot suggestion
$150–300/mo, locked in the promo plan). Pipeline observability, reports,
and the learning knowledge base are $0 tooling on top of the same plan.

## 15. Timeline

- **Phase 0 — Decisions (this week):** T0.1 ✅ done; T0.2 brand in
  progress; T0.3–T0.5 lock numbers, sponsorship decisions, alert
  thresholds.
- **Phase 1 — Setup (weeks 1–2):** accounts, connections, integrations
  built; 3 dry-run videos (not published).
- **Phase 2 — Pilot (weeks 3–4):** 2 videos/day with per-video approval;
  promotion handoff once winners emerge.
- **Phase 3 — Full auto (week 5+):** 3 videos/day on standing approval;
  weekly reviews running.
- **Phase 4 — Expansion (month 3+):** clone for channel #2.

## 16. Open decisions (yours)

1. ~~Theme/niche for channel #1 (+ shortlist for #2)?~~ ✅ **Done
   2026-09-24** — AI Technology Education; backups: history & mythology
   explainers, real-world crime news.
2. Brand name + handles? *(T0.2 in progress — 10 names screened 2026-09-25:
   7 taken; Neural Notes recommended as cleanest; your pick pending)*
3. Narrator voice? *(T0.2 in progress — 4 samples at
   `../brand/voice-{warm,smooth,sleek,radiant}.mp3`; your pick pending)*
4. Caption style + hashtag sets? *(T0.2 pending)*
5. Videos per day — 3, or start at 2?
6. Publish mode after pilot — full-auto, or keep per-video approval?
7. Monthly ad budget cap (Meta + Google combined)?
8. Language — English first?
9. Promo parameters (locked in promo plan P0.1): ad cap, default campaign
   duration, cost thresholds, views- vs followers-first.
10. Sponsorship/affiliate decisions (T0.4): approve the auto-generated
    media kit, rate-card framework, prospect shortlist, outreach
    templates; affiliate program applications (manual gates stay yours).
11. Alert severity thresholds + operational report format (T0.5).
