# Notes: Sponsorship rates + inbound threshold (read 2026-09-24, index only)

RATE BENCHMARKS (all estimated/reported ranges; sources disagree 2-3x):

1. YouTube Creator Partnerships (hawksem.com, updated Sept 17, 2026 — VERIFIED LIVE read):
   - Creators set starting rate in YouTube Studio; typical $10-$30 CPM; tech/finance up to $100 CPM.
   - Gemini matches brands/creators; creators must be in YouTube Partner Program; creators sharing channel insights surfaced 60% more.
   URL: https://hawksem.com/blog/youtube-creator-partnership-ads/

2. Variant International agency (Medium, May 2026): sponsorship rate = (avg views/1000) × niche CPM.
   Niche CPMs: Tech $18-35; Finance $22-42; Gaming $12-20; Lifestyle $8-14. Example: 150K-view tech video → $3,200-$4,500.
   URL: https://medium.com/@sponsorcraft/most-creators-are-undercharging-for-sponsorships-heres-the-real-math-1e83aa05de40

3. James Nash (Medium, Jul 2026), compiled from 2 agency rate guides + brokered-deal dataset:
   - Niche CPM spread: ~$10 (entertainment) to ~$100 (finance top).
   - Creators Agency founder Apple Crider (Jul 17, 2026, 4,000+ brokered deals): ~90% of finance/business mid-rolls $50-$200 CPM, median ~$100.
   - Integration multiplier: standalone Short 0.4-0.6x; 60-90s mid-roll 1x; dedicated video 1.3-2x.
   URL: https://medium.com/@james_nash_hhh/youtube-sponsorship-calculator-what-to-charge-brands-by-views-and-niche-5452b7664928

4. Sponsorship CPM by creator size (Medium @spaces00, Jan 2026): smaller creators $15-30; mid-sized $30-75; high-intent/niche audiences $100+.
   URL: https://medium.com/@spaces00/how-youtube-earnings-and-brand-deals-work-a210eeb28ead

5. Per-post by tier (Instagram):
   - Keepface (citing IMH/Collabstr/ClickAnalytic 2026): Nano $10-$100; Micro $100-$1,000; Mid-tier $1,000-$5,000; Macro $5,000-$20,000; Mega $50,000+.
   - GrowbyShare agency 2026 (per sponsored short-form video): Nano 1-10K $50-$250; Micro 10-100K $250-$1,500; Macro 100K-1M $1,500-$8,000; Mega 1M+ $8,000+.
   - Shopify 2026 data (via Nash): nano nets ~$10-25 per 1,000 followers; mega ~$2-5 per 1,000 followers.
   URLs: https://keepface.com/site/en/micro-vs-macro-influencer-strategy-2026/ ; https://medium.com/@growbyshare/how-much-should-brands-pay-influencers-b6c4a98e1047

6. Platform ad payouts (context):
   - YouTube Shorts RPM: $0.02-$0.30/1k (US/UK); finance/business/B2B $0.30-$1.50; entertainment/memes often <$0.05; self-reported case 1.8M views → $46.12 (~$0.026/1k). lilachbullock.com, Sept 2026. Creator keeps 45% of Shorts pool.
   - TikTok Creator Rewards: ~$0.40-$1.00 per 1k qualified views; requires 10K followers, 100K views/30d, videos >1 min (GitHub autonomous-revenue-engine ops doc, Sept 2026 — treat as directional).
   - YPP Shorts threshold rising Feb 1, 2027: 20M qualified Shorts views/90d (was 10M); long-form 8,000 watch hours (was 4,000).

INBOUND THRESHOLD:
- First paid deals possible at ~500 followers with niche + engagement (creator coach claims, Medium Oct 2025).
- UGC model needs zero followers; beginner UGC videos ~$200/video reported.
- TikTok Creator Marketplace eligibility implies ~10K followers.
- No source gives a hard "inbound starts at X" number; consensus pattern: outbound from day 1 (UGC/affiliate), organic inbound typically from ~10K-50K with consistent niche content. Flag as estimate.

FACELESS/AI CHANNELS:
- YouTube "inauthentic content" policy (renamed from repetitious, effective July 15, 2025): mass-produced templated content ineligible for monetization, channel-wide; AI use itself NOT targeted (Murdoch, Medium Jun 2026).
- Grey Journal (Sept 2026): brand deals "increasingly squeezed by AI-generated content that brands can produce themselves" → less reliable for AI channels.
- Brand categories that do sponsor faceless/tech channels: AI SaaS tools, fintech, dev tools/hosting/VPNs; reported $500-$5,000/video (LinkedIn creator post). Self-reported case studies (faceless finance channel $18K ads + $4K affiliate/mo) — hype-level sources, label accordingly.
