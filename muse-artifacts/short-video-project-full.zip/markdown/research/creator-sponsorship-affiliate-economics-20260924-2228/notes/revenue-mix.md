# Notes: Revenue mix sources (read 2026-09-24)
All via web index (browser_search), not live-verified.

1. eMarketer Feb 2026 forecast (cited in kaloiq.com Creator Economy Statistics 2026 PDF, June 2026; also SQ Magazine stats page, updated ~May 2026):
   - US social creator revenue $21.10B in 2026.
   - Revenue mix: 59% sponsored content, 24.4% platform payouts, 8.2% affiliate.
   - Nano/micro = 49.9% of US creator spend.
   URL: https://www.kaloiq.com/assets/research-pdf/Creator-Economy-Statistics-2026.pdf ; https://sqmagazine.co.uk/creator-economy-statistics/

2. Influencer Marketing Factory Jan 2026 survey of 1,000 US creators aged 18-65 (via SQ Magazine + blotato.com breakdown video):
   - 48.7% earn <$10K/yr; 45.6% earn $10K-$100K; 5.7% earn $100K+.
   - Product sales + affiliate = 21.2% of creator income.
   - 53% created 0-10 sponsored posts in 2025; 23.9% made 10-20.
   URL: https://sqmagazine.co.uk/creator-economy-statistics/

3. Influencer Marketing Hub 2025 benchmark (via blotato.com, Sept 2026):
   - Just over 49% of creators earn MOST revenue from brand deals (10% decrease YoY).
   - 64% would PREFER brand deals as primary income (preference lagging reality).
   URL: https://www.blotato.com/blog/how-much-do-content-creators-make

4. Kajabi 2025 State of Creator Commerce (via blotato.com): survey of Kajabi users only —
   brand deal revenue down 52% YoY, affiliate down 36%, platform payouts down 33%; podcast revenue +47%, digital downloads +20%, memberships +10%. NOTE: single platform's user base.
   URL: https://www.blotato.com/blog/how-much-do-content-creators-make

5. Epidemic Sound 3,000-creator global survey (via Neal Schaffer, cited on fanvault.shop Sept 2026): top 2025 income sources — live streaming 32%, ad revenue 29%, fan subscriptions 27%. NOTE: conflicts with eMarketer mix; different sample (global, music-focused creator base).
   URL: https://fanvault.shop/blog/direct-to-fan-payments-eating-ad-based-creator-income-2026

6. Lumanu analysis of >$420M tracked creator payouts (via fanvault.shop): platform-native ads = 28% of creator income.
   URL: https://fanvault.shop/blog/direct-to-fan-payments-eating-ad-based-creator-income-2026

7. IAB 2025 Creator Economy Ad Spend & Strategy Report (via kaloiq PDF): US creator spend $37B in 2025, +26% YoY, ~$44B projected 2026.
   Goldman Sachs: creator economy TAM ~$250B (2024) → ~$480B by 2027; 2023 report said brand deals ~70% of creator revenue (per blotato).
   SQ Magazine affiliate stats (updated June 1, 2026): 61% of creators earn from affiliate; TikTok Shop GMV $23.4B.
   URL: https://sqmagazine.co.uk/affiliate-marketing-statistics/
