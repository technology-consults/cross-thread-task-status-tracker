# Notes: Affiliate economics + playbook (read 2026-09-24, index only unless noted)

AFFILIATE COMMISSION RANGES (GitHub swotbee research, Sept 2026 — estimates):
- Retail/e-commerce: 3-10% per sale
- SaaS: 20-50% recurring
- Finance/insurance: $50-$200 per qualified lead (CPA)
- Health & wellness: 10-50%
- Education/eLearning: 15-40%
- DTC brands: 10-15% or flat $10-$15 per new customer
Also: Amazon 1-10% by category (Grey Journal); SaaS often 20-30% recurring (Grey Journal).
URL: https://github.com/swotbee/swotbee.github.io/blob/HEAD/docs/research/multi-tiered-affiliate-incentive-research.md ; https://greyjournal.net/hustle/how-creators-make-money-2026/

AFFILIATE PERFORMANCE:
- 61% of creators earn from affiliate marketing (SQ Magazine affiliate stats, June 2026).
- Affiliate = 8.2% of creator revenue mix (eMarketer via kaloiq).
- Affiliate revenue up 9% per market report (londondaily.news — low-credibility source, label accordingly).
- CTR on affiliate links: 0.5-1.0% (Grey Journal, Sept 2026); affiliate works best as supplement ($500-$2,000/mo), not foundation.
- TikTok Shop GMV $23.4B (SQ Magazine). TikTok Shop affiliate described as major creator income path (GitHub revenue paths doc).
- Avg affiliate conversion 1-3% (top 5-10%); brand ROI $11:$1 (swotbee/GitHub — industry averages).
- Per-1,000-view affiliate benchmarks for short-form video: NO solid published data found. Medium data-driven guide gives framework: Revenue per 1,000 views = net revenue ÷ page views × 1,000 (example $250-$360/1k for articles — NOT video). Best-converting categories for video creators: beauty, fashion, fitness, tech (greyjournal Instagram 2026 piece); software/SaaS for review channels; finance products for finance channels.

PLAYBOOK — MEDIA KITS (what's credible):
- First page: short bio, niche topics, audience size, audience location, recent reach, contact (Kirby Soto, Medium Sept 2026).
- Metrics brands want: engagement rate, reach, follower count, audience demographics (age/location), past collaboration results (views/clicks/sales), content samples, services offered (Reels/TikToks/Stories/UGC), rates as starting point with scope caveat (usage rights, exclusivity, timeline).
- Sources: https://medium.com/@socialmediaexpertise/the-media-kit-that-opens-doors-how-i-negotiate-with-brands-9bf7931f15cf ; https://www.theblogsocial.com/include-in-your-media-kit/ ; https://dev.to/imtaslim/the-influencer-media-kit-reinvented-dynamic-trackable-shareable-5

PLAYBOOK — CHANNELS TO GET DEALS:
- Cold outreach: DM/email with personalized pitch; <10% response typical (Laxman Kafle, Medium Jul 2026). Target brands already sponsor-active (#ad + niche searches, CollabFeed).
- Creator marketplaces: Collabstr (1.2M+ vetted creators, escrow, no subscription); TikTok Creator Marketplace (creators set rates, brands filter by demo/engagement); YouTube Creator Partnerships Hub (2026, ex-BrandConnect, in Studio; set rate; Gemini matching; requires YPP). Aspire, Influencity for mid-market/agencies.
- Agencies/MCNs: take 20-40% cut (Kafle); retainer discounts ~50% on long-term deals (Keepface).
- UGC path: zero audience needed; ~$200/video beginner; $2K-$12K/mo claims (creator self-reports).
- URLs: https://nerdbot.com/2026/09/19/top-10-influencer-marketing-platforms-in-the-usa-2026/ ; https://hawksem.com/blog/youtube-creator-partnership-ads/ (VERIFIED LIVE) ; https://collabfeed.io/

ADD-ONS THAT RAISE RATES (Nash, Medium Jun 2026): usage rights +20-30% (website/email), +30-50% (paid ads), +50%+ (OOH); exclusivity; whitelisting. Can double/triple base rate.

NICHE CPM TABLE (directional, long-form ad CPMs; multiple sources agree on ranking):
- Personal finance: $15-45; B2B SaaS reviews $20-50; Insurance $25-50; Legal $20-40; Tech reviews $12-28; Software reviews $12-25; Beauty/fashion $10-18; Health $5-20; Education $5-25; Travel $8-15; Make money online $5-12; Gaming $2-5; Entertainment broad: lowest.
- Sponsor-driven (high CPM + active brand spend): finance, fintech, tech/SaaS, beauty/fashion, health/supplements, education/coding.
- Ad-driven (volume play, low CPM): entertainment, comedy, memes, gaming, dance.
- Note: sponsor-driven and ad-driven correlate — high-CPM niches attract both brands and advertisers.

TIMELINE (new channel → meaningful sponsorship):
- No published survey data found; only creator-coach claims.
- Claim pattern: fintech sponsorships within ~6 months (loca.us); $500-$5K sponsors at ~50K subscribers (LinkedIn post); faceless finance case study: YPP approval month 5, $2,100/mo (ads only) by month 11 (GitHub case studies — self-reported).
- Realistic synthesis: affiliate/UGC revenue possible in weeks 1-4 (zero audience needed); consistent sponsorship pipeline typically 6-12 months of niche posting.
