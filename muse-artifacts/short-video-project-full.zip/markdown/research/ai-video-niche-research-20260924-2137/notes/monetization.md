# Notes — Monetization data (index research, Sep 24, 2026)

## Shorts RPM by niche (creator-reported ranges — NOT official)
- virvid.ai: https://virvid.ai/blog/most-profitable-ai-youtube-shorts-niches-2026-rpm-data (index)
  - Finance/Investing Shorts RPM $0.15-$0.45 (long-form $9-15); Real Estate $0.10-$0.30; Business/SaaS $0.10-$0.25; Tech/Software $0.08-$0.20; Career/Resume $0.06-$0.12; Health/Fitness $0.04-$0.10; Beauty $0.03-$0.08; Food $0.02-$0.05; Gaming $0.02-$0.05; Entertainment/Comedy $0.01-$0.05.
- miraflow.ai: https://miraflow.ai/blog/youtube-cpm-rates-by-niche-2026-how-much-youtubers-earn (index)
  - Most creators report Shorts RPM $0.03-$0.10; 5-20x lower than long-form; creator cut 45% of pooled Shorts revenue.
- lilachbullock (own-channel data): https://www.lilachbullock.com/youtube-shorts-pay-per-1000-views/ (index)
  - US/UK audiences $0.02-$0.30/1k; finance/business $0.30-$1.50/1k in good months; entertainment < $0.05/1k; low-CPM countries <$0.01/1k. Own examples: 1.8M views → $46.12 (~$0.026 RPM); 220K business views → $61 (~$0.28 RPM).
- beexly (github, directional, not Origin-measured): https://github.com/beexly/autonomous-revenue-engine/blob/HEAD/ops/CONFORMAL_FOR_PLATFORM_METRICS.md (index)
  - Shorts RPM typically $0.02-$0.20 (most $0.04-$0.12); 1M Shorts views ≈ $20-$150 band; US finance higher.
  - TikTok Creator Rewards: official range ~$0.40-$1.00/1k qualified views; eligibility 10k followers, 100k views/30d, original >1 min.
- godofprompt.ai: https://www.godofprompt.ai/blog/dollar8000-monthly-from-ai-youtube-shorts (index) — Shorts RPM $0.01-$0.07 ($10-$70 per million views); >25% of YPP creators earn via Shorts.
- anil-matcha/ai-creator-academy (github, index): short-form RPM $0.02-$0.06; per-video AI production cost ~$0.50-$0.70 (ElevenLabs TTS ~$0.15 + video-gen credits ~$0.50); argues profit requires affiliate/digital-product conversion.

## Niche-level monetization claims
- vibecoder10 (github, claims — treat as unverified opinion): https://github.com (storyengine/YOUTUBE-INTELLIGENCE-RULESET.md, index)
  - True crime/legal narration ~$7-13 RPM [ESTIMATE, long-form likely]; history/documentary creator claimed ~$700K/yr at 85%+ margins [unverified self-report]; business case studies $10-25 RPM; saturated death traps: generic motivation/stoicism, top-10-facts listicles (named in YouTube non-compliant examples), Reddit-story reuploads, AI slideshows (named verbatim in policy as demonetized), quiz/trivia.
- AI story videos ranked #1 for long-term potential by Marius Simoliunas (Medium): https://medium.com/@msimoliunas/i-tested-multiple-ai-video-niches-heres-what-actually-gets-views-in-2026-6bd86f5725b2 (index)
- Faceless niches (Medium/@ainextec11, @warlx0536, @frameloopai, @isaisa606): finance/CPM $15-50 claims; true crime affiliate links to books/documentary platforms; affiliate works best in tutorials/reviews/explainers; sponsors (tech, finance, lifestyle) pay for shoutouts/pins regardless of faceless identity.
- appleworld.today (Sept 2026): AI dramas are one of fastest-growing genres; sponsorships from AI software companies/tech platforms for AI-drama channels. URL: https://appleworld.today/2026/09/the-iphone-monetization-blueprint-how-to-build-a-profitable-faceless-media-empire-with-ai-in-2026/ (index)
- growwithal (blogspot): business/finance/SaaS Shorts $0.80-$2.50+ RPM; entertainment $0.02-$0.10.

## AI music channel RPM (outlierkit — related but not core niche)
- https://outlierkit.com/resources/ai-generated-music-youtube-monetization-2026/ (index)
- Lofi/sleep/cinematic AI music channels: $3-$8 RPM (long-form presumably); cinematic $5-$10 CPM.
