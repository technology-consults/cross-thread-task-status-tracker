# Notes — Platform policies & compliance (index + 1 live read, Sep 24, 2026)

## YouTube disclosure
- builtbyfoundry.io (4 days old): https://www.builtbyfoundry.io/blog/do-you-have-to-label-ai-content-2026-3-rules-2-laws (index)
  - Disclosure required when realistic content is generated or meaningfully altered with AI (real person appearing to say/do what they didn't; altered footage of real event/place; realistic scene that didn't occur). NOT required: scripts, titles, thumbnails, beauty filters, color/lighting, background blur, captions, sharpening/upscaling, audio repair, idea generation, own-voice clone.
  - Set "AI use" to Yes in Attributes at upload; consequence of non-disclosure: manually applied label, removal, or YPP suspension.
  - YouTube states disclosure "won't limit a video's audience or impact its eligibility to earn money."
- aiclipviral: https://aiclipviral.com/blog/youtube-inauthentic-content-policy (index)
  - From May 2026 YouTube auto-applies AI disclosure labels when systems detect "significant photorealistic AI" not self-disclosed; label below player (long-form), overlay on Shorts. Quote: "a disclosure label alone does not change how a video is recommended or whether it's eligible to earn money."

## YouTube "inauthentic content" policy (formerly "repetitious content", renamed 2025-07-15)
- TechRepublic (Jul 21, 2026): https://www.techrepublic.com/article/news-youtube-ai-video-monetization-rules/ (index)
  - Clarification effective Jul 16, 2026. Three categories: (1) generic/repetitive/template-based near-identical AI/CGI/template videos; (2) "off-putting" or emotionally manipulative content (example: animal distress/rescue) — loses YPP access whether or not AI involved; (3) AI personas on sensitive topics (health, finance, legal, medical).
- TechCrunch (Jul 20, 2026): https://techcrunch.com/2026/07/20/youtube-clarifies-policies-around-ai-slop-and-upsetting-videos/ (index)
  - Confirms three categories; announced by Matt Halprin (YouTube trust & safety); Rene Ritchie called it "a minor update to YouTube's long-standing YPP policies."
- Enforcement reports (creator-reported / third-party — treat numbers as estimates):
  - fanvault.shop: https://fanvault.shop/blog/youtube-fake-ai-experts-doctors-lawyers-demonetization-inauthentic-content (index) — Jan 2026: 16 top-100 AI-slop channels removed from YPP: 4.7B lifetime views, 35M subs, ~$10M/yr est (per OutlierKit; unverified by YouTube). Individual cases: Bible-story channel $30k/month and exam-prep channel $7.5k/month demonetized under policy.
  - thedroidguy: https://thedroidguy.com/... (index) — same Jan 2026 wave; categories hit: AI-narrated faceless channels, news aggregation farms, template Shorts spammers, minimal-commentary reaction channels.
  - Medium/@monkscript (index): MilX April 2026 reported thousands of faceless AI channels' monetization suspended; Fliki found exam-prep $7.5k/mo case; 12-channel portfolio: 7 demonetized for "reused content", 3 flagged, 2 collapsed in reach.
  - moneywise (index): http://moneywise.com/news/top-stories/youtube-ai-slop-inauthentic-content-monetization-rules — confirms three categories.
- YPP thresholds rising Feb 1, 2027: 8k watch hours OR 20M Shorts views (beexly github, index); existing members grandfathered, accept updated terms by Jan 31, 2027 (techtrox: https://techtrox.com/youtube-monetization-policy-update-2026/, index).
- Live browser check: support.google.com/youtube/answer/15423570 returned "Sorry, this page can't be found" — my guessed URL was wrong; official policy verified only via index sources.

## TikTok
- builtbyfoundry.io (index): label AI-generated or significantly edited realistic content; unlabeled may be removed/restricted/labeled by TikTok; auto label cannot be removed once applied.
- storrito: https://storrito.com/resources/what-tiktoks-ai-monetization-restrictions-signal-for-creator-income/ (index)
  - Fully AI-generated content excluded from Creator Rewards Program; minor AI assists (color, captions, AI B-roll) remain eligible. Penalty escalation: removal → posting restrictions → permanent program removal after 4th offense. External sponsorships still allowed for disclosed AI content.
- tiktoknewshub (creator-advice quality, unverified): Creator Rewards requires labeling; "low originality"/unlabeled AI removed from reward pool. (label carefully)
- hub.paper-checker: TikTok auto-labeled 1.3B+ videos as AI-generated. URL: https://hub.paper-checker.com/blog/ai-detection-social-media-instagram-tiktok-twitter-2026/ (index)
- Virtual influencers must identify as AI in bio and label posts (cgallic github reference, index).

## Meta (Instagram/Facebook)
- autoadify: https://autoadify.com/blog/instagram-automation-algorithm-2026 (index) — "AI info" label via C2PA; no credible evidence of ranking penalty for AI content; audience skip behavior drives watch time.
- deletefootprints: https://deletefootprints.ai/remove-ai-info-instagram/ (index) — 330M+ labeled pieces in 29 days (~1T label views); Aug 31, 2026: Meta will "limit the reach of profiles that feature an AI-generated person and do not add this label" — no published post-level penalty for correctly labeled content.
- reshapinglife5 (wordpress, ads focus): https://reshapinglife5.wordpress.com/2026/07/25/meta-now-requires-ai-disclosure-on-facebook-and-instagram-ads-what-small-business-owners-need-to-know-2026/ (index) — AI disclosure mandatory for ads; undisclosed AI valid reason for ad rejection.
- auditsocials: https://www.auditsocials.com/blog/meta-ai-generated-content-label-policy-2026 (index) — enforcement for deceptive synthetic media with reported reach reductions ~80% (analyst claim, unverified); ~14% of ad rejections attributed to undisclosed AI (unverified).

## Disclosed vs undisclosed distribution evidence
- ppc.land: https://ppc.land/youtube-shifts-generative-ai-labels-to-spots-viewers-will-actually-see/ (index) — YouTube docs: label by itself does not change ranking; recommendation driven by viewer signals. If viewers disengage from labeled content, distribution drops indirectly.
- insider-gaming (reporting Science Says study, 8 experiments, 1M+ TikTok posts): https://insider-gaming.com/ai-labels-can-reduce-social-media-engagement-study-finds/ (index) — labeled posts got up to 8% fewer likes, ~7% less interaction even at identical content quality; perceived effort -15.6%.
- TU Delft thesis: https://repository.tudelft.nl/file/File_629244e4-d687-4934-9a0c-e2ce0d95d851 (index) — statistically lower median like/view ratio for AI-labeled videos on TikTok and YouTube Shorts; correlation ≠ causation; limited YouTube label visibility caveat.

## Legitimate compliance strategies (creator-advice sources, index)
- Add genuine original value: original scripts/research, storytelling, commentary, human editing decisions, editorial judgment (TechRepublic; milx: https://milx.app/en/trends/should-you-use-ai-generated-videos-and-how-will-it-impact-youtube-monetization).
- Disclose realistic AI content at upload on all platforms (YouTube "AI use" toggle; TikTok AI-generated label; Meta disclosure).
- Vary formats/topics per episode; avoid mass-duplication/templates (aiclipviral; vibecoder ruleset).
- Avoid AI personas giving advice on sensitive topics (finance/health/legal/medical) — demonetization target.
- Avoid emotionally manipulative loops (staged animal rescue/peril) — YPP removal regardless of AI use.
- Keep C2PA/provenance intact; do not strip metadata. Own audience off-platform; diversify revenue.
- Explicitly DECEPTIVE tactics excluded per mission instructions (metadata stripping, fake personas, undisclosed synthetic endorsements).
