# AI-Generated Short-Video Niches — Evidence-Based Research (Sep 24, 2026)

## Summary
**Verified headline facts (2026):** AI-generated shorts are a structural part of short-form feeds — a Kapwing study found 21% of Shorts served to a new YouTube account were AI-generated (33% "brainrot"), and 59% on a new TikTok account, with TikTok auto-labeling 1.3B+ videos. The biggest view-getting AI formats are AI animal videos, religious/mythology AI content, AI history reenactments, AI story/narration channels, AI satisfying/oddly-calming clips, true-crime/mystery explainers, AI sports "what if" recreations, and AI comedy/brainrot skits. **Monetization reality:** YouTube Shorts RPM is tiny ($0.02–$0.20 per 1k views, most $0.04–$0.12, creator-reported) — so revenue per follower is highest in finance/tech/business niches (Shorts RPM up to $0.30–$1.50 in good months) and lowest in entertainment/brainrot (<$0.05). TikTok Creator Rewards pays ~$0.40–$1.00/1k qualified views but *excludes fully AI-generated content*. **Policy:** YouTube's July 2026 "inauthentic content" clarification demonetizes (1) templated/mass-produced repetitive content, (2) off-putting emotionally manipulative content (e.g., staged animal rescues), and (3) AI personas giving sensitive-topic advice; a Jan 2026 wave reportedly removed 16 top-100 slop channels (~4.7B views, ~$10M/yr est). Disclosure labels themselves do not reduce distribution on YouTube or Meta — but labeled posts get slightly lower audience engagement (~8% fewer likes on TikTok per one study), and undisclosed realistic AI risks removal, reward disqualification, and YPP suspension.

**Top-5 niches for a new automated channel (balancing popularity, monetization, policy safety):**
1. AI true-crime / mystery explainers — 2. AI history / mythology "documentaries" — 3. AI suspense story narration / mini-dramas — 4. AI satisfying / relaxation loops — 5. AI sports "what if" recreations.

---

## Part 1 — Which AI short-form formats are actually popular in 2026

All figures below are estimates from third-party studies unless marked "verified" (two independent sources or primary source).

### 1. AI animal videos / AI "cute animal" brainrot — strongest on YouTube Shorts & TikTok
- **Evidence:** Kapwing data reported by Search Engine Journal: India's "Bandar Apna Dost" (AI monkey in dramatic human situations) — 2.4B views, ~$4.25M/yr estimated; Singapore's "Pouty Frenchie" (AI French bulldog in candy forests) ~$4M/yr estimated; a South Korean channel's AI "realistic" animals beaten by cute pets drew billions of views. Italian brainrot (Bombardino Crocodilo, Tralalero Tralala — animal/object hybrids with absurd narration) is a Gen Alpha phenomenon on TikTok/Reels.
- **Hook mechanics:** ultra-realistic but logic-defying scenes create a scroll-stop "what am I watching" moment; 10-second loops get replayed; cute-animal dopamine response; comments ("Shoutout to the cameraman").
- **Longevity:** MIXED — massive views but this exact loop-format is what YouTube's "inauthentic content" enforcement targets (see Part 3: templated/interchangeable content + animal-distress policy). High fad-burnout risk.
- Sources: https://www.searchenginejournal.com/youtubes-ai-slop-problem-and-how-marketers-can-compete/567297/ (index); https://en.shuziqushi.com/new265519.html (index); https://medium.com/technology-hits/so-anyway-my-brother-watches-crocodile-brainrot-now-2e47601f61e6 (index)

### 2. AI religious / mythology content — strongest on TikTok, then Shorts & Reels
- **Evidence:** Springer Journal of Religious Education (2026) case study: TikTok trend of biblical figures (Moses, Mary, Joseph, Jesus, Peter) speaking as contemporary vloggers, some videos >30M views. @believerdaily's AI Jesus ~23M views; @dailyfaithministry TikTok posts routinely draw 35–53K likes with 15–24K comments. Spain leads world slop-subscriber growth via religious-themed AI accounts. YouTube Shorts religious AI content uses explicit AI disclosures in descriptions.
- **Hook mechanics:** strong pre-existing emotional/identity investment; "comment amen" CTAs drive engagement; shareability within faith communities; novelty of seeing sacred figures as modern vloggers.
- **Longevity:** DURABLE audience (faith content is evergreen), but policy/risk watch: a Feb 2026 analysis flagged invented details added to 25 viral TikTok AI Bible videos (scripture distortion); research paper warns of blurred lines between interpretation and misinformation. Requires respectful, accurate handling.
- Sources: https://link.springer.com/article/10.1007/s40839-026-00302-w (index); https://www.youtube.com/watch?v=dmG4oSE6-zA (index); https://en.shuziqushi.com/new265519.html (index)

### 3. AI history reenactments / POV history — strongest on TikTok, strong on Shorts
- **Evidence:** arXiv paper (2606.23300) studying history POV TikToks; @timetravellerpov's Black Plague video hit 53M views; Fast Company documented the account's rapid growth to 329K+ followers in months. YouTube Shorts: "Farzan Films", "The AI Historian" formats are widely cloned (tutorial at https://www.youtube.com/watch?v=BHRJP8jqfko).
- **Hook mechanics:** "POV: You wake up..." first-person immersion; first-person hands/body, atmospheric sound; curiosity + visceral experience; comment sections debate what happened.
- **Longevity:** STRONG — each topic is naturally distinct (auto-passes the "interchangeable" inauthentic test), endless supply of historical events, educational framing favored by platforms. Accuracy criticism (BBC/historian critiques) is a watch item — disclosure that content is dramatized helps.
- Sources: https://arxiv.org/pdf/2606.23300 (index); https://www.fastcompany.com/91280871/this-ai-trend-lets-tiktok-users-relive-historys-best-and-worst-moments (index); https://gamereactor.eu/are-viral-ai-pov-videos-spreading-inaccurate-history-1502933/ (index)

### 4. AI story / narration channels (suspense, mystery, "what if", mini-dramas) — TikTok & Shorts
- **Evidence:** Medium field-test author Marius Simoliunas ranked AI story videos #1 for long-term potential (curiosity loops improved retention dramatically). AI dramas described as "one of the fastest-growing video genres" (appleworld.today, Sep 2026); 60-second suspense mini-series, sci-fi thrillers, urban legends via AI avatars.
- **Hook mechanics:** curiosity gaps ("what happens next"), cliffhangers, seamless loops, emotional arcs; story carries weak visuals.
- **Longevity:** STRONG — narrative formats are the most defensible against "inauthentic content" flags (each story is genuinely distinct); evergreen catalog effect.
- Sources: https://medium.com/@msimoliunas/i-tested-multiple-ai-video-niches-heres-what-actually-gets-views-in-2026-6bd86f5725b2 (index); https://appleworld.today/2026/09/the-iphone-monetization-blueprint-how-to-build-a-profitable-faceless-media-empire-with-ai-in-2026/ (index)

### 5. AI true-crime / mystery explainers — YouTube Shorts & TikTok
- **Evidence:** Widely recommended by creators as top faceless niche (Frameloop, Warlx); Kapwing category data shows science/education/health/history cluster 33–35% AI slop on TikTok. True crime described as YouTube's most-watched genre with extremely high binge factor.
- **Hook mechanics:** real stakes, "unsolved" open loops, case-structure beats, moral judgment; loyal repeat audience.
- **Longevity:** STRONG — loyalty + evergreen backlog. Policy watch: avoid AI personas presenting as authorities on legal/medical matters; keep dramatized and non-graphic; original narration protects against "reused content" flags.
- Sources: https://medium.com/@frameloopai/25-best-faceless-youtube-channel-ideas-with-ai-in-2026-d69acebddaa9 (index); https://medium.com/@warlx0536/the-faceless-youtube-playbook-10-niches-that-print-money-without-ever-showing-your-face-in-2026-59f81b5e1b6c (index)

### 6. AI satisfying / oddly-calming clips & ASMR — TikTok, Reels, Shorts, FB Reels
- **Evidence:** Hydraulic-press ASMR accounts on TikTok with hundreds of thousands of likes per video (@hydraulic.press49); YouTube channel "MastiPress2026" posting AI simulation crush shorts; "which bed would you pick?" repeated-fantasy-bed AI ASMR (MessyLab example); AI rust-removal noted as a 2026 "oddly satisfying" trend.
- **Hook mechanics:** sensory satisfaction, completion anticipation, no language barrier (global audience), low skip rate.
- **Longevity:** DURABLE but LOW-DIFFERENTIATION — template-driven; each video must vary enough to avoid "interchangeable" classification. Revenue per follower is weak.
- Sources: https://www.youtube.com/shorts/21iO4bT6neY (index); https://www.youtube.com/watch?v=DMFuGi8usWM (index); https://medium.com/@yiyangzou772/ai-slop-has-become-the-word-of-the-year-when-the-information-flow-is-filled-with-noise-who-210cdbc4d796 (index)

### 7. AI sports "what if" recreations — YouTube Shorts & TikTok
- **Evidence:** Active Shorts/TikTok accounts (e.g., "What If Messi Scored THIS Bicycle Kick", AI Messi/Ronaldo compilations) with explicit "AI-generated, did not happen" disclaimers in descriptions; "AI or Real?" reaction content as a meta-format.
- **Hook mechanics:** fan tribalism (Messi vs Ronaldo comments), fantasy fulfillment of impossible moments, debate fuel.
- **Longevity:** MODERATE — strong fandom demand but risk of fad saturation; must clearly label as fictional (likeness of real athletes) — unlabeled realistic fake footage of real people is the core disclosure trigger everywhere.
- Sources: https://www.youtube.com/shorts/2bYAL1rh7Nw (index); https://www.youtube.com/shorts/sEOi6V7Ql6o (index)

### 8. AI comedy skits / brainrot memes — TikTok-first
- **Evidence:** Italian brainrot animal memes; weird AI animal videos (Medium Sep 2026 piece documents creators turning attention into affiliate clicks).
- **Hook mechanics:** absurdity, shareability, meme remix culture.
- **Longevity:** FAST BURNOUT — humor formats churn quickly; lowest monetization.

### 9. AI movie-trailer-style cinematic shorts / AI documentaries — YouTube Shorts
- **Evidence:** "Zack D Style" 3D semi-realistic educational shorts; AI documentary shorts via Veo 3.1 (per https://www.youtube.com/watch?v=DMFuGi8usWM, index); Simoliunas found generic cinematic AI edits "increasingly hard to scale."
- **Hook mechanics:** high production-value wow factor; educational curiosity.
- **Longevity:** MODERATE — quality differentiates, but generic cinematic AI is increasingly crowded.

### 10. AI relaxation / sleep ambience — YouTube & TikTok (long-tail)
- **Evidence:** Simoliunas's testing: slow accumulation of views over time, consistent passive traffic, monetization potential; related long-form AI music/sleep channels reach $3–$8 RPM (outlierkit, index).
- **Hook mechanics:** utility, not entertainment; search + repeat-view behavior.
- **Longevity:** STRONGEST — utility content compounds; lowest viral ceiling but most durable.

**Formats from the mission list NOT well-evidenced as trending:** AI true-crime explainers (verified ✓), AI sports highlights (verified ✓), AI religious content (verified ✓), AI comedy skits (verified ✓), AI ASMR (verified ✓), AI story/narration (verified ✓), AI movie-trailer shorts (verified, moderate), AI history reenactments (verified ✓), AI animal/baby videos (animals verified ✓; "baby videos" appear in Guardian's description of fastest-growing AI channels — babies in space — partially verified), AI "what if" (verified ✓). Not found as standalone trending: pure AI motivation videos (described as heavily saturated), AI tech-tool breakdowns as their own viral format (they exist but more as YouTube automation advice than a trending watch format).

---

## Part 2 — Monetization reality per niche

**Baseline (creator-reported, not official):** YouTube Shorts RPM $0.02–$0.20 per 1,000 views, most $0.04–$0.12; 1M Shorts views ≈ $20–$150. TikTok Creator Rewards ~$0.40–$1.00/1k *qualified* views (only >1-min videos; fully AI-generated content is excluded). Per-video AI production cost ~$0.50–$0.70 (TTS + video-gen credits), so ad revenue alone rarely covers production — affiliate/digital-product conversion is the standard profit path.

| Niche | YouTube Shorts RPM (creator-reported) | Brand sponsors | Affiliate fit | Growth speed vs revenue/follower |
|---|---|---|---|---|
| True-crime/mystery explainers | Entertainment-adjacent; shorts likely $0.04–$0.12 range; long-form true-crime claims $7–13 [unverified] | Moderate (documentary/streaming brands, podcast platforms) | Strong — true-crime books, podcast/documentary platform subscriptions, Patreon (high binge loyalty) | Balanced: fast loyal growth, decent monetization |
| History/mythology AI | Education-adjacent; shorts $0.04–$0.12; one creator claimed ~$700K/yr at 85% margins on AI history long-form [unverified self-report] | Low-moderate (edtech, audiobook apps) | Moderate — history books, documentary subscriptions, courses | Good: strong views, above-average RPM for AI content |
| AI story/dramas/narration | Entertainment $0.02–$0.10 (creator-reported entertainment baseline) | Growing — AI software companies sponsor AI-drama channels (tool showcases) | Moderate — digital products, AI tool affiliates, ebooks | Good: high retention growth; affiliate needed for real revenue |
| Religious AI | Entertainment-adjacent; mass-appeal → low RPM (<$0.05 typical) | Very low (brands avoid the niche) | Weak — donations/digital devotionals possible but limited | Fastest growth, weakest revenue/follower; also highest misinformation-policy risk |
| AI animals/brainrot | Entertainment $0.01–$0.05 (lowest tier, creator-reported) | Very low (merch/toys for kids' content at best) | Very weak | Fastest growth, near-zero revenue/follower; enforcement risk |
| Satisfying/ASMR loops | Entertainment <$0.05 typical | Very low | Weak-moderate — sleep/relaxation products | Durable slow growth; revenue/follower weak |
| Sports "what if" | Entertainment <$0.05; fan-content low purchase intent | Moderate — sports/gaming apps, fantasy platforms (betting-adjacent risks) | Moderate — merch, streaming subscriptions | Fast growth; revenue moderate |

**Best growth-speed-to-revenue-per-follower ratio:** history/mythology and true-crime/mystery — they combine high-retention formats (which platforms reward) with advertiser-acceptable, affiliate-friendly audiences. Pure-brainrot niches (AI animals, comedy memes) grow fastest but monetize worst and carry the highest policy risk.

---

## Part 3 — Platform AI-content policies & legitimate compliance

### YouTube (current 2026) — verified via multiple index sources; official help page live-check failed (guessed URL 404'd)
- **Disclosure:** At upload, set "AI use" to Yes for realistic AI-generated or meaningfully altered content (a real person appearing to say/do something they didn't; altered footage of a real event/place; realistic scenes that didn't happen). NOT required: AI scripts, titles, thumbnails, captions, color grading, filters, audio repair, your own cloned voice. Non-disclosure consequences: manually applied label, video removal, or YPP suspension.
- **Auto-labeling (since May 2026):** YouTube applies AI labels itself when it detects "significant photorealistic AI" you didn't disclose; label sits below the player (long-form) and as an overlay on Shorts.
- **"Inauthentic content" policy (renamed from "repetitious content" July 15, 2025; clarified July 13–16, 2026):** three monetization-excluded categories — (1) generic/repetitive/template-based mass production (AI slideshows, characters in identical situations, templated top-10s are named examples); (2) "off-putting"/emotionally manipulative content such as staged animal distress-and-rescue — **removed from YPP whether or not AI was used**; (3) AI personas giving advice on sensitive topics (finance, health, legal, medical). This is NOT an AI ban — YouTube says AI-assisted content with genuine original value (commentary, research, storytelling, human perspective) stays eligible.
- **Enforcement (creator/third-party reported, not confirmed by YouTube — treat as estimates/rumors):** Jan 2026 wave reportedly removed 16 top-100 slop channels (4.7B lifetime views, 35M subs, ~$10M/yr est, per OutlierKit); a Bible-story channel (~$30K/mo) and exam-prep channel (~$7.5K/mo) demonetized; April 2026 wave reportedly suspended thousands of faceless AI channels (MilX).
- **YPP thresholds rise Feb 1, 2027** to 8K watch hours OR 20M Shorts views/90d; existing members grandfathered (accept terms by Jan 31, 2027).

### TikTok — verified via index sources
- **Labels:** Mandatory "AI-generated" label for realistic synthetic media; TikTok detects via C2PA/invisible watermarking; once TikTok auto-labels your post, you cannot remove the label. Unlabeled realistic AI may be removed, restricted, or labeled by TikTok; TikTok auto-labeled 1.3B+ videos.
- **Monetization:** **Fully AI-generated content is explicitly excluded from the Creator Rewards Program**; minor AI assists (color correction, captions, AI B-roll) stay eligible. Program requirements: 18+, 10K followers, 100K views/30d, videos >1 min, 1K+ FYP views to qualify. Escalation for unlabeled AI: removal → posting restrictions → permanent program removal (reported 4th-offense pattern — creator-reported, not official). External sponsorships remain available for properly disclosed AI content.
- Virtual influencers must identify as AI in bio and label every post; cannot make experience-based claims.

### Instagram/Facebook (Meta) — verified via index sources
- **"AI info" labels:** Applied when Meta detects industry-standard signals (C2PA/IPTC) or the uploader self-discloses; on fully AI-generated images the label sits under the account name; on lightly AI-edited images it's in the post menu (since Sep 2024). Scale: 330M+ labeled pieces in 29 days with ~1T label views.
- **Distribution effect:** **No published post-level distribution penalty for correctly labeled AI content.** The one published reach limit: as of Aug 31, 2026, Meta limits reach of *profiles* featuring an AI-generated person without the label. Organic reach loss is driven by audience behavior (skips), not the label.
- **Ads:** AI disclosure mandatory for FB/IG ads (unified "About this ad" destination from June 2026); undisclosed AI is a valid reason for ad rejection (~14% of rejections attributed, per one analyst — unverified).

### Evidence: does disclosure reduce distribution?
- **No evidence of a platform-imposed penalty:** YouTube's own documentation (via ppc.land) states a disclosure label "does not change how a video is recommended or whether it's eligible to earn money." Meta has published no post-level penalty for labeled content.
- **Indirect audience effect (not a platform penalty):** Science Says study of 1M+ TikTok posts (reported by insider-gaming) found AI-labeled posts got up to 8% fewer likes and ~7% less total interaction even at identical content quality; creators perceived as -15.6% less effort. A TU Delft thesis found statistically lower median like/view ratios for labeled videos on TikTok and YouTube Shorts — correlation, not proven causation.
- **Non-disclosure is the risky path:** TikTok removes/restricts unlabeled realistic AI and disqualifies it from Creator Rewards; YouTube can suspend from YPP for repeated non-disclosure.

### Legitimate compliance strategies (all legitimate; deceptive tactics excluded per mission)
1. **Original human creative layer:** original scripts/research, commentary, narrative structure, editorial decisions, human editing — the test YouTube applies is output originality, not the tool.
2. **Disclose realistic AI content on every platform** at upload (YouTube "AI use" toggle; TikTok AI-generated label; Meta disclosure). No evidence disclosure hurts distribution.
3. **Format variety:** each episode genuinely different topic/story; avoid near-identical templates across uploads — this is the #1 inauthentic-content trigger.
4. **Avoid AI personas on sensitive topics** (finance, health, legal, medical) — explicit demonetization category on YouTube; use human-presented or clearly editorial content instead.
5. **Avoid emotionally manipulative loops** (animal distress/rescue, shock-bait) — loses YPP regardless of AI use.
6. **Keep provenance intact** (C2PA metadata) so platforms can verify disclosure; don't strip AI watermarks.
7. **Diversify revenue and audience off-platform** (email/digital products) — monetization on any single platform is rented, not owned.
8. **For TikTok:** keep AI as assistance, not authorship, if you want Creator Rewards; ensure videos exceed 1 minute for qualification.

---

## Ranked top-5 AI-video niches for a new automated channel (popularity × monetization × policy safety)

1. **AI history / mythology explainers** — proven multi-million-view demand, evergreen, naturally distinct episodes (passes inauthentic test), educational framing is platform-favored; monetize via books/documentary affiliates + higher-tier Shorts RPM.
2. **AI true-crime / mystery explainers** — highest audience loyalty/binge, strong affiliate (books, podcast platforms, Patreon); keep narration original and non-graphic, no synthetic "expert" personas.
3. **AI suspense story narration / mini-dramas** — strongest retention mechanics (curiosity loops, cliffhangers), works across all four platforms, attracts AI-tool brand sponsorships; fully distinct stories per episode.
4. **AI sports "what if" recreations** — huge fandom demand, easy compliance via clear "did not happen" disclaimers; entertainment RPM is low so pair with merch/streaming affiliates; avoid implying real events.
5. **AI satisfying / relaxation loops** — most policy-safe and durable (utility content compounds), language-independent global reach; accept low RPM and monetize via sleep/ambience products and long-tail catalog views.

**Deliberately excluded from top-5:** AI animal brainrot (biggest views, worst revenue/follower, highest inauthentic-content enforcement risk); AI religious content (huge reach but weakest monetization and misinformation-policy risk unless handled with rigor); AI comedy memes (fastest burnout).

---

## Could not verify / open questions
- Exact current payout numbers are all creator-reported; platforms do not publish RPM tables.
- Enforcement wave figures (16 channels, 4.7B views, $10M/yr) come from OutlierKit/creator reports, not YouTube.
- Official YouTube help page for disclosure could not be verified live (guessed URL 404'd; YouTube Help site was reachable).
- TikTok Creator Rewards' exact AI-exclusion wording is from secondary sources, not TikTok's official terms.

## Sources
- Scale: https://www.searchenginejournal.com/youtubes-ai-slop-problem-and-how-marketers-can-compete/567297/ (index, 2026-09-24); https://Www.itechpost.com/articles/236367/20260617/tiktok-features-3x-more-ai-slop-vs-youtube-says-new-studyhow-avoid-these-content.htm (index); https://dailyguardian.ae/tiktok-feeds-show-3-times-more-ai-slop-than-youtube-study-reveals/ (index); https://www.thestreet.com/technology/ai-slop-is-taking-over-youtube-shorts (index)
- Formats: https://en.shuziqushi.com/new265519.html (index); https://arxiv.org/pdf/2606.23300 (index); https://www.fastcompany.com/91280871/this-ai-trend-lets-tiktok-users-relive-historys-best-and-worst-moments (index); https://link.springer.com/article/10.1007/s40839-026-00302-w (index); https://medium.com/@msimoliunas/i-tested-multiple-ai-video-niches-heres-what-actually-gets-views-in-2026-6bd86f5725b2 (index); https://medium.com/technology-hits/so-anyway-my-brother-watches-crocodile-brainrot-now-2e47601f61e6 (index); https://medium.com/@yiyangzou772/ai-slop-has-become-the-word-of-the-year-when-the-information-flow-is-filled-with-noise-who-210cdbc4d796 (index); https://www.youtube.com/watch?v=BHRJP8jqfko (index); https://www.youtube.com/watch?v=DMFuGi8usWM (index); https://www.youtube.com/watch?v=dmG4oSE6-zA (index); https://www.youtube.com/shorts/2bYAL1rh7Nw (index); https://www.youtube.com/shorts/21iO4bT6neY (index)
- Monetization: https://virvid.ai/blog/most-profitable-ai-youtube-shorts-niches-2026-rpm-data (index); https://miraflow.ai/blog/youtube-cpm-rates-by-niche-2026-how-much-youtubers-earn (index); https://www.lilachbullock.com/youtube-shorts-pay-per-1000-views/ (index); https://github.com/beexly/autonomous-revenue-engine/blob/HEAD/ops/CONFORMAL_FOR_PLATFORM_METRICS.md (index); https://www.godofprompt.ai/blog/dollar8000-monthly-from-ai-youtube-shorts (index); https://github.com/anil-matcha/ai-creator-academy/blob/HEAD/tracks/03-faceless-ai-channels/03-rpm-and-earnings.md (index); https://medium.com/@frameloopai/25-best-faceless-youtube-channel-ideas-with-ai-in-2026-d69acebddaa9 (index); https://appleworld.today/2026/09/the-iphone-monetization-blueprint-how-to-build-a-profitable-faceless-media-empire-with-ai-in-2026/ (index); http://growwithal.blogspot.com/2026/07/faceless-youtube-shorts-tiktok-with-ai.html (index); https://outlierkit.com/resources/ai-generated-music-youtube-monetization-2026/ (index)
- Policy: https://www.techrepublic.com/article/news-youtube-ai-video-monetization-rules/ (index); https://techcrunch.com/2026/07/20/youtube-clarifies-policies-around-ai-slop-and-upsetting-videos/ (index); https://www.builtbyfoundry.io/blog/do-you-have-to-label-ai-content-2026-3-rules-2-laws (index); https://aiclipviral.com/blog/youtube-inauthentic-content-policy (index); https://techtrox.com/youtube-monetization-policy-update-2026/ (index); https://fanvault.shop/blog/youtube-fake-ai-experts-doctors-lawyers-demonetization-inauthentic-content (index); https://Www.techtimes.com/articles/320629/20260715/youtube-wiped-35m-subscribers-over-ai-slop-now-its-judging-your-taste.htm (index); https://moneywise.com/news/top-stories/youtube-ai-slop-inauthentic-content-monetization-rules (index); https://storrito.com/resources/what-tiktoks-ai-monetization-restrictions-signal-for-creator-income/ (index); https://tiktoknewshub.com/news/tiktok-creator-rewards-program-2026-navigating-the-new-era-of-monetization/ (index); https://hub.paper-checker.com/blog/ai-detection-social-media-instagram-tiktok-twitter-2026/ (index); https://autoadify.com/blog/instagram-automation-algorithm-2026 (index); https://deletefootprints.ai/remove-ai-info-instagram/ (index); https://reshapinglife5.wordpress.com/2026/07/25/meta-now-requires-ai-disclosure-on-facebook-and-instagram-ads-what-small-business-owners-need-to-know-2026/ (index); https://www.auditsocials.com/blog/meta-ai-generated-content-label-policy-2026 (index); https://ppc.land/youtube-shifts-generative-ai-labels-to-spots-viewers-will-actually-see/ (index); https://insider-gaming.com/ai-labels-can-reduce-social-media-engagement-study-finds/ (index); https://repository.tudelft.nl/file/File_629244e4-d687-4934-9a0c-e2ce0d95d851 (index); https://milx.app/en/trends/should-you-use-ai-generated-videos-and-how-will-it-impact-youtube-monetization (index)
- Working notes: notes/niche-formats.md, notes/monetization.md, notes/policies.md
