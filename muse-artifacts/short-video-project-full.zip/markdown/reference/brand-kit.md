# Brand Kit

Last updated: 2026-09-25. Status: **T0.2 IN PROGRESS — nothing final until BalRam says "done."**

## Name screening (2026-09-25)

10 candidate names screened against YouTube, TikTok, and Instagram for existing channels.

**TAKEN (rule out):**
- The AI Brief — active YouTube channel (@theaibriefyt20) + theaibrief.com
- ByteSized AI — active TikTok (@bytesizedai, ~454K likes) + newsletter
- AI Decoded — active YouTube/TikTok/Instagram (@AIDecoded), recent uploads
- The Prompt Lab — "Prompt Lab 88" on YouTube (AI prompt hacks) + ThePromptLab AI art page
- Model Behavior — @modelbehavior on TikTok + an active podcast
- AI Unpacked — @aiunpacked7 on TikTok + "The AI Unpacked" weekly YouTube channel
- The AI Edge — theaiedge.io newsletter + "THE AI EDGE PODCAST" on YouTube

**RISKY:**
- **Promptly** — no channel found, but the name is used by several AI prompt products. Possible trademark issue.
- **Machine Minded** — an existing YouTube channel (engineering videos) + GitHub repo. Different niche, same name.

**CLEAN (recommended):**
- **Neural Notes** — only hit is an Instagram music page "neuralnotes25" (variant handle). No AI-education channel under this name anywhere found.

Screening is collision-checking only, not definitive handle availability. Do not create accounts or reserve handles without authorization.

## Narrator voice

4 samples rendered 2026-09-24 at `brand/voice-{warm,smooth,sleek,radiant}.mp3`. Awaiting BalRam's pick.

Sample text: "There's a new A I model in town, and it just changed the game. It writes code, designs slides, and answers questions like a pro. Here's what it can do, what it costs, and the one trick most people miss. Let's dive in."

Note: early tests looked better **without** voiceover; final call at T1.15 calibration. If voiceover is used, the selected voice here applies.

## Caption style

Pending. Locked after name + voice.

## Hashtag sets

Pending. Locked after name + voice.

## Visual identity

AI-generated original illustrations in a consistent style + our own automated real screen captures. No publicly sourced internet media without disclosure and approval.
