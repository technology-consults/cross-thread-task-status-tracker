# Architecture — Five Independent Pipelines

Last updated: 2026-09-25

## Principle

Five separate, maintainable codebases. Each pipeline has its **own** bug/failure/performance tracking, its **own** predefined self-healing mechanisms with automated execution plans, and its **own** anomaly detection with severity-tiered alerting. They share one learning knowledge base, but nothing else operational.

## The five pipelines

### 1. Create and publish
Ideation → scripting → media generation (images, screen captures, voiceover) → assembly → QC → publish. Owns the topic engine, the content ledger writes, and the per-video approval gate during the pilot.

### 2. Promotion
Organic amplification (comments, Stories, playlists, Trial Reels, cross-posting) plus the paid ladder: $5/day probe → $15/day validate → $30–50/day scale, with kill triggers. Objective: **min cost and max impact**. Promotes only organically proven winners; any material launch or scale-up needs approval.

### 3. Housekeeping
Monthly stale-content review and remediation, content-ledger hygiene, link checks, sponsor-obligation expiry tracking. Enforces the stale-content policy (see `reference/decisions-log.md`): nothing is ever deleted; unlist only when fully outdated AND misleading/inaccurate.

### 4. Performance monitoring and reporting
Collects stats from all pipelines. Owns:
- The **shared reporting framework**: formats, cadence conventions, delivery targets.
- **R1/R2/R3 cross-pipeline rollups** that stitch the five pipelines' numbers together.
- The **shared severity-tiering framework**: P1–P3 definitions based on importance, occurrence rate, urgency, and need for human review/approval/intervention.

Each pipeline writes its **own operational reports** under the shared framework (e.g., create-and-publish reports videos made, QC pass rate, cost per video; promotion reports spend, CPV, kill triggers; housekeeping reports review outcomes; earnings reports attribution).

### 5. Earnings improvement
Revenue attribution (by video, topic, format, platform), affiliate click/conversion tracking and optimization, the sponsor pipeline (prospect shortlist, outreach tracking, rate card, deal ledger), media-kit generation from real channel metrics, CTA rotation.

## How they interact

- **Shared learning knowledge base.** Every video writes performance and revenue outcomes back to it: winning hooks, formats, topics, failure patterns, QC-rejection categories, comment/feedback insights, trend signals, model benchmarks, cost-per-video tracking.
- **Performance-monitoring reads from all.** Stats flow from each pipeline into the shared reporting framework; the R1/R2/R3 rollups combine them.
- **Earnings-improvement reads attribution.** It consumes performance data plus affiliate/sponsor data to attribute revenue per video/topic/format/platform.
- **Housekeeping reads the content ledger.** The monthly review scans every published video for staleness, broken links, and expiring sponsor obligations.
- **Learning flows back.** The knowledge base informs topic selection, format choices, and model selection in create-and-publish; spend decisions in promotion; offer optimization in earnings-improvement.

## Per-pipeline observability and self-healing

Every pipeline implements, in its own codebase:
- Bug, failure, and performance tracking.
- Captured failure-pattern history, used for improvement.
- Predefined self-healing mechanisms with automated execution plans: bounded retry budgets, fallback models/providers, quarantine of poisoned items.
- Escalation when repeated healing fails.
- Anomaly detection: unfavorable conditions, exception scenarios, weak growth, bottlenecks.
- Severity-tiered notifications via the shared framework (P1 = needs BalRam now; P3 = logged for review).

## Pilot vs full-auto modes

| Mode | Trigger | Behavior |
|---|---|---|
| **Pilot (review-on)** | Default | Every video behind per-video approval gate. Learning-driven pipeline changes need approval. |
| **Full auto** | BalRam says **"go auto"** / **"lock the vision"** (or equivalent) | Idea → publication runs without routine human handling. Bounded automatic adjustments allowed. |
| **Review restored** | **"Turn review back on"** | Back to per-video approval. |
| **Hard pause** | **"Pause all publishing now"** | Everything halts until BalRam says resume. |

## Cadence control

Publishing cadence is adjustable by a single prompt for a day, a week, a month, or indefinitely.
