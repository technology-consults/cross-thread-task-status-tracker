# Content Guardrails

Locked 2026-09-24. Apply to **ALL current and future niches and channels.**

## Universal guardrails

- No sensitive or objectionable content.
- Nothing involving children.
- No current politics.
- Nothing potentially controversial or otherwise inappropriate.

## Enforcement

- The topic engine enforces these rules **at ideation, before generation**.
- Violations are **rejected** outright, or **flagged for BalRam's review** when borderline.
- No video proceeds to scripting while a guardrail flag is unresolved.

## News-reactive scoping (AI Technology Education)

In-scope:
- Product launches and feature announcements.
- New tools.
- Pricing and cost changes.

Out of scope:
- Negative reputational news about companies or people.
- Scandals and controversies.
- Anything that risks reputational harm to the channel.

Sensitive or reputational-risk topics are flagged for BalRam's call **before** publishing — never published on the pipeline's own judgment.

## Review note

During the pilot, every candidate and video additionally routes through BalRam's per-video approval gate, which is a second enforcement layer on top of the automated rules.
