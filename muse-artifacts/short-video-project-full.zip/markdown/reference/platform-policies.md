# Platform Policies

Last updated: 2026-09-25.

Every item below is **TO-VERIFY from official sources** unless stated otherwise. Nothing here is asserted as fact until verified against the platform's current official documentation during the technical audit. Do not build on assumptions.

## YouTube

| Item | Status |
|---|---|
| Publishing eligibility (Shorts + long-form) | TO-VERIFY |
| AI-content disclosure requirements | TO-VERIFY |
| Originality / inauthentic-content rules (research-reported: "repetitious content" policy renamed "inauthentic content" 2025-07-15; AI use itself not targeted, line is "meaningful human involvement" — TO-VERIFY officially) | TO-VERIFY |
| API posting limits and quota | TO-VERIFY |
| Scheduling via API | TO-VERIFY |
| Comments and comment pinning | TO-VERIFY |
| Hiding mechanics (discussed: Unlisted / Private — TO-VERIFY) | TO-VERIFY |
| Cards, end screens, trimming | TO-VERIFY |

Open audit items: YPP eligibility thresholds (a claimed change effective 2027-02-01 is **not** officially verified — do not treat as settled); treatment of paid views under YPP.

## TikTok

| Item | Status |
|---|---|
| Content Posting API approval requirements | TO-VERIFY |
| API posting limits | TO-VERIFY |
| Scheduling | TO-VERIFY |
| AI-content disclosure requirements | TO-VERIFY |
| Hiding mechanics (discussed: Private as closest equivalent — TO-VERIFY) | TO-VERIFY |
| Comments and pinning | TO-VERIFY |

Open audit items: Content Posting API approval process; Creator Rewards eligibility and treatment of AI-generated content under it.

## Instagram

| Item | Status |
|---|---|
| Publishing eligibility, endpoints, permissions | TO-VERIFY |
| Access tokens and token refresh | TO-VERIFY |
| Scheduling | TO-VERIFY |
| AI-content disclosure requirements | TO-VERIFY |
| Hiding mechanics (discussed: Archive — TO-VERIFY) | TO-VERIFY |
| Comments, pinning, Stories, Trial Reels | TO-VERIFY |

## Facebook

| Item | Status |
|---|---|
| Publishing eligibility, endpoints, permissions | TO-VERIFY |
| Scheduling and tokens | TO-VERIFY |
| AI-content disclosure requirements | TO-VERIFY |
| Hiding mechanics (discussed: restricted/private audience where supported — TO-VERIFY) | TO-VERIFY |
| Comments and pinning | TO-VERIFY |

## Analytics (all platforms)

TO-VERIFY availability of: reach, retention, watch time, revenue/revenue attribution, and paid/organic separation.

## Other audit items

- FFmpeg availability for assembly.
- Current ad objectives and placements for the paid ladder.
- Audio originality/licensing rules.
- Warm-up, throttling, spam, and reach behavior claims — all TO-VERIFY.
- RPM, sponsor-rate, affiliate-return, CPV, CPF, and "long-form vs Shorts" earnings claims — all TO-VERIFY; none are settled facts.
