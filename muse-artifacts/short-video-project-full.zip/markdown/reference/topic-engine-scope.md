# Topic Engine Scope

Last updated: 2026-09-24.

## Candidate sources

The pipeline autonomously identifies candidate topics from:
- Official product and feature announcements.
- New tools.
- Pricing and cost changes.
- Announced launches and event calendars.
- Search and platform trends.
- Performance data from prior videos (via the shared learning knowledge base).

## Selection rules

- **Dedup:** every candidate is compared against the full content ledger; near-duplicates are rejected.
- **Variation:** episode-to-episode variation must be meaningful — no template-churned repeats of the same topic.
- **Guardrails first:** universal content guardrails are enforced at ideation, before any scripting (see `reference/content-guardrails.md`).
- **News-reactive, not predictive:** the engine reacts to unannounced news as it breaks; it never pretends to predict events.

## Editorial scope (AI Technology Education)

- In scope: product launches, feature announcements, new tools, pricing/cost changes.
- Out of scope: negative reputational news, scandals, controversies.
- Sensitive or reputational-risk topics are flagged for BalRam's call before publishing.

## Approval flow

- **Pilot:** candidates and finished videos route through BalRam's per-video approval gate.
- **Full auto:** only after BalRam authorizes it ("go auto" / "lock the vision"). The engine then runs idea → publication without routine human handling, within the guardrails and scope above.
