# Monetization Research (distilled)

Research date: 2026-09-24. Full report: `../research/creator-sponsorship-affiliate-economics-20260924-2228/report.md`. Tight reference only — see the full report for sources and method.

## Normalized creator-revenue mix (established creators)

Based on the eMarketer February 2026 forecast, with the researcher's own arithmetic:

| Stream | Share |
|---|---|
| Brand sponsorships | ~59% |
| View-based platform advertising | ~24.4% |
| Affiliate marketing | ~8.2% |
| Products, courses, merch, fan revenue, other | ~8.4% |

**Caveats:**
- No single survey published a complete six-stream breakdown summing to 100%; the 100% is normalized by the researcher's arithmetic.
- No reliable 100%-summing split by follower tier or by niche was found.
- Other sources disagree materially about sponsorship share (e.g., Goldman Sachs ~70%; Epidemic Sound survey shows a fan-payment-heavy mix).
- Most rate, timeline, affiliate, and RPM figures are industry estimates or creator reports, not official payout data.
- Claims about sponsorships reliably beginning at particular follower counts, repeatable deals taking a particular number of months, or AI-tech sponsors paying particular amounts are **estimates, not guarantees**.

## Sponsorship rate ranges (2026, estimated/reported)

- Typical: **$10–30 CPM** per 1,000 expected views.
- Tech niche: **$18–35 CPM**, up to **$100 CPM** for high-intent audiences.
- Standalone sponsored Short ≈ **0.4–0.6×** of a 60–90s mid-roll.
- Per-post by tier (short-form video): nano $50–$250, micro $250–$1,500, macro $1,500–$8,000, mega $8,000+.
- Add-ons raise quotes: usage rights +20–50%, exclusivity, whitelisting (can double/triple base).

## Platform ad revenue context (not sponsorship)

- YouTube Shorts RPM ~**$0.02–$0.30** per 1,000 views (finance/B2B higher, entertainment often <$0.05).
- TikTok Creator Rewards ~**$0.40–$1.00** per 1,000 qualified views (directional; requires 10K followers + 100K views/30d + >1-min videos — TO-VERIFY officially).

## Affiliate economics

- SaaS/software: **20–50% recurring**. Retail/e-commerce: **3–10%**. Finance: **$50–200 per qualified lead (CPA)**.
- **Gap:** no solid published per-1,000-view affiliate benchmark for short-form video exists.
- Creator-reported realistic early band: ~$500–$2,000/mo as a supplement, not a foundation.

## The five sponsorship routes

1. **Inbound discovery** — brands find you (typically micro-to-mid tier with consistent niche content).
2. **Personalized outbound pitching** — DM/email to sponsor-active brands with 1–3 content ideas + media kit.
3. **Creator marketplaces** — YouTube Creator Partnerships (requires YPP), TikTok Creator Marketplace, Collabstr.
4. **Agencies/MCNs** — take ~20–40% cut.
5. **UGC/content-production deals** — paid content for brands' own channels; beginner ~$200/video; no audience required.

## Faceless / AI-generated channels

- Sponsors buy audience trust and intent, not production method. Faceless channels in intent-heavy niches (finance, tech/AI tools, education) get sponsored; faceless entertainment/meme content mostly does not.
- Reported brand hesitancy: brands that can generate content in-house have less reason to sponsor generic AI channels (analyst commentary, not surveyed).

## Bottom line for years 1–2

- **Platform ad revenue** is first and near-automatic once YPP-eligible — but tiny for short-form.
- **Sponsorships** are ~0% of revenue for the first 6–12 months; become the majority stream only after audience proof exists.
- **Affiliate** is the highest-leverage year-1 lever: no audience threshold, monetizes views from day one.
- **Build order:** (1) niche in an intent-heavy vertical, (2) posting consistency + original packaging, (3) affiliate link infrastructure, (4) media kit + outbound playbook, (5) owned-audience/product optionality.
