# Decisions Log

Locked decisions only. Nothing here is re-litigated without an explicit new decision. Dates are YYYY-MM-DD.

## 2026-09-24 — Niche selection (T0.1 DONE)
- **Channel #1:** AI Technology Education.
- **Backup #1:** History & mythology explainers.
- **Backup #2:** Real-world crime news (strictly within universal guardrails).
- Backups are pivot insurance for week-4/week-8 evaluations and potential future channels, not launch commitments.
- AI Tech Ed production approach: AI-generated original illustrations + our own automated real screen captures of tools/actions. Never present AI-generated mock interfaces as genuine screenshots. No publicly sourced internet media without explicit disclosure and approval.
- News-reactive topics focus on product launches, feature announcements, new tools, and pricing/cost changes.

## 2026-09-24 — Universal content guardrails
Apply to ALL current and future niches and channels:
- No sensitive or objectionable content.
- Nothing involving children.
- No current politics.
- Nothing potentially controversial or otherwise inappropriate.
- The topic engine enforces these at ideation, before generation. Violations are rejected or flagged for review.

## 2026-09-24 — Original-media rule (standing)
- "I don't want you to use any existing video from the internet." Generated audio/video must be original. Anything else requires disclosure and approval.
- T1.16 conflicts with this rule: default to original/AI-generated audio unless licensed media is explicitly approved.
- Early voice tests were realistic but videos looked better without voiceover; final voiceover call at T1.15 calibration.

## 2026-09-24 — UGC stance
- Real-human UGC tier ruled out "at least for now." No real person on camera.
- If UGC is pursued: AI-avatar/AI-generated UGC with disclosure, or deprioritize UGC in favor of affiliates and later sponsorships.

## 2026-09-24 — Topic-engine editorial scope
- News-reactive topics limited to product/feature announcements, new tools, pricing/cost changes. NOT negative reputational news (controversies, scandals).
- Sensitive/reputational-risk topics are flagged for BalRam's call before publishing.

## 2026-09-24 — Stale-content policy
- **Nothing is ever deleted.** Unlist only when content is fully outdated AND misleading/inaccurate.
- Tech evolved but video still broadly fine → keep public with redirect strategies (updated caption/description, pinned comment, cards/end screens pointing to newer version).
- Slightly stale → in-place update; one stale long-form segment → trim where supported + redirect; thoroughly outdated → full remake as a new upload, hide/unlist the old only if leaving it public would mislead.
- Review runs monthly; actions are gated by the sponsor obligations ledger (no unlist before minimum-live dates).
- Keep comments enabled rather than hiding feedback.

## 2026-09-24 — Sponsor/affiliate stances
- Build order: affiliate infrastructure first (day-1, zero-audience lever), media kit + outbound next, sponsorships after audience proof. Sponsorships are ~0% of revenue for the first 6–12 months.
- Five sponsorship routes: inbound discovery, personalized outbound pitching, creator marketplaces, agencies/MCNs, UGC/content-production deals.
- Proposed capabilities: auto-generated media kit from real metrics, sponsor prospect shortlist, outreach templates + tracking, rate-card framework, sponsor/deal obligations ledger, affiliate-program research + applications, link hub + tracked links, CTA rotation, revenue attribution/reporting.
- Manual gates: identity/tax details, applications, outreach, negotiation, closing.

## 2026-09-24 — Review gates and automation rules
- Keep publishing and promotion plans, specs, and task lists separate. One owner per task: **Balram** (decisions, manual work, approvals), **Muse** (technical work).
- Work one task at a time in dependency order. Present each result; BalRam replies **"adjust"** or **"done."** No task is checked off and no dependent work starts until **"done."**
- State upfront and recurring costs on every proposal. Preserve 🟢/🟡/🔴/🟠 automation indicators.
- Pilot publishing stays behind per-video approval. Full automation begins only after **"go auto,"** **"lock the vision,"** or equivalent.
- **"Turn review back on"** restores review. **"Pause all publishing now"** halts everything until BalRam says resume.
- Cadence adjustable by one prompt for a day, week, month, or indefinitely.

## 2026-09-24 — Promotion rules
- Objective: **"min cost and max impact."**
- Promote only organically proven winners. Material launches/scale-ups require approval.
- Reports separate organic results, paid results, and measured relationships.

## 2026-09-24 — Five-pipeline split
- Separate independent codebases: (1) create & publish, (2) promotion, (3) housekeeping, (4) performance monitoring & reporting, (5) earnings improvement.
- Shared learning knowledge base; per-pipeline bug/failure/performance tracking, failure-pattern capture, self-healing with bounded retry budgets/fallbacks/quarantine, escalation, anomaly detection, severity-tiered alerting.

## 2026-09-24 — Reporting split
- Each pipeline owns its **own operational reports** under a shared framework.
- Performance-monitoring owns the **shared reporting framework** (formats, cadence, delivery) and the **R1/R2/R3 cross-pipeline rollups**.
- Same shape as alerting: distributed detail, centralized framework.

## 2026-09-24 — Doc structure approval
- Approved the target tree in `00-START-HERE.md`: five pipeline folders (plan/spec/tasks each), `reference/`, `ledgers/`, `brand/`, `research/`, single-root zippable.

## 2026-09-25 — Brand name screening (T0.2 in progress)
- 10 names screened; 7 taken, 2 risky, 1 clean (Neural Notes, recommended). See `reference/brand-kit.md`.
- T0.2 not done — name/voice/style not final until BalRam says **"done."**
