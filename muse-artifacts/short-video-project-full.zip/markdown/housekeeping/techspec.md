# Housekeeping Pipeline — Technical Specification

Companion to `plan.md` (the what/why). This file is the how: jobs,
schemas, API mechanics, and build details.
**Build tasks:** `tasks-muse.md`

## 1. Workspace layout (independent codebase)

```
~/workspace/video-housekeeping/
├── jobs/
│   ├── monthly-review.py        # the full review pass (plan §4)
│   ├── link-check.py            # weekly link hygiene (plan §7)
│   └── obligation-guard.py      # sponsor ledger gate (plan §5)
├── actions/
│   ├── update-metadata.py       # rung (b): captions/descriptions/links
│   ├── pin-comment.py           # rung (b): pinned redirect comments
│   ├── cards-screens.py         # rung (b): YT cards/end screens (TO-VERIFY)
│   ├── trim.py                  # rung (c): trim stale segments (TO-VERIFY)
│   └── hide.py                  # rung (d): unlist/private/archive (TO-VERIFY)
├── state/
│   ├── review-log.jsonl         # every review decision, per video
│   ├── link-status.json         # last-known status per tracked link
│   ├── failures.jsonl           # bug/failure/performance tracking
│   ├── failure-patterns.json    # captured failure-pattern history
│   └── healing-log.jsonl        # self-healing executions
└── reports/
    └── monthly/                 # review outcome reports
```

Reads the content ledger (owned by create-and-publish) and the
sponsor/deal obligations ledger
(`files/ledgers/sponsor-obligations.md`, schema §5). Writes
`review-log.jsonl` and the shared learning knowledge base (via
performance-monitoring's write API). Never writes to another pipeline's
state.

## 2. Content inventory

`monthly-review.py` builds the review set from the content ledger: every
video ref with platform IDs and publish dates. Videos published within
the last 30 days get a light pass (links + obligations only) — fresh
content rarely needs a full accuracy re-check; videos older than 30 days
get the full five-point check (plan §4.1). Inventory mismatches (ledger
says published, platform says gone) are anomalies, not silent skips.

## 3. Check engine

- **Accuracy:** for news-reactive AI-tech topics, re-verify the video's
  core claims against current sources (product pages, pricing pages,
  official announcements). Claim extraction reuses the script text stored
  at creation. Disputed claims are flagged for your review, never
  auto-graded as false.
- **Links:** `link-check.py` resolves every tracked description link
  (HEAD, then GET on failure), follows redirects, records final URL +
  status. Bounded: 2 retries with backoff per link, then flagged.
- **Obligations:** `obligation-guard.py` verifies required links/text
  still present in descriptions, pinned comments still pinned, and
  minimum-live dates against today.
- **Newer versions:** topic-similarity match against the content ledger —
  if a newer video covers the same topic, it's the redirect target for
  rungs (b/c/d).

## 4. Triage actions (per rung)

- **Rung (b) update-metadata:** per-platform caption/description edits
  via the platform publishers (YouTube `videos.update`, Meta Graph,
  TikTok — TO-VERIFY each). Link swaps recorded in `link-status.json`.
- **Rung (b) pin-comment:** post + pin redirect comment. Pinning support
  is TO-VERIFY per platform; where unsupported, the redirect goes in the
  description top-line instead.
- **Rung (b) cards/end screens:** YouTube long-form only, TO-VERIFY
  current API support.
- **Rung (c) trim:** only where the platform supports it (TO-VERIFY).
  Trim ranges come from the review (timestamps of the stale segment).
  Published footage is never replaced or spliced — trim removes only.
- **Rung (d) hide:** unlist/private/archive per the platform table
  (plan §6, all TO-VERIFY). Requires your per-video approval **and** a
  clean obligation-guard pass.
- Every action is idempotent (ledger-checked before the call) and logged
  with before/after state. Destructive-adjacent actions (hide) always
  confirm first, even in full-auto.

## 5. Sponsor/deal obligations ledger (schema)

The ledger lives at `files/ledgers/sponsor-obligations.md` (human-readable)
with a machine-readable mirror `state/obligations.json`:

```json
{
  "<video-ref>": {
    "sponsor": "<brand>",
    "contract_id": "<id>",
    "campaign_id": "<id>",
    "minimum_live_until": "YYYY-MM-DD",
    "required_links": ["<url>"],
    "required_description_text": "<snippet>",
    "pinned_comment_required": true,
    "integration": "<on-screen/audio notes>",
    "usage_rights": "<notes>",
    "exclusivity": "<notes>",
    "contact": "<approval/contact record>"
  }
}
```

**Gate logic:** before any hide/alter action, `obligation-guard.py`
checks `minimum_live_until > today` → action **blocked**, decision routed
to you with the contract details. No override path exists in code —
only a contract amendment (recorded by you) clears the block. The
earnings-improvement pipeline writes new entries; housekeeping enforces
them.

## 6. Observability: tracking, self-healing, anomaly detection, alerts

This pipeline's own (independent of the other four pipelines'):

- **Tracking:** `failures.jsonl` — every bug, failed check, failed
  action, with timestamp, video ref, error, and outcome.
  `failure-patterns.json` — aggregated patterns (e.g. "tiktok caption
  edits fail at 3× the rate of others").
- **Self-healing (predefined, automated):** bounded retry budgets (link
  checks: 2 retries; API actions: 3 with exponential backoff); fallback
  (HEAD→GET for links; description top-line when pinning unsupported);
  quarantine (a video whose checks keep failing is quarantined from
  auto-actions and queued for your review — never force-processed).
- **Escalation:** repeated healing failure (same action failing 3 runs
  in a row, or 5 failures in one run) escalates to a P2 alert with the
  failure pattern attached.
- **Anomaly detection:** broken-link spike (failure rate 3× the trailing
  average), review backlog growth (unreviewed inventory growing month
  over month), obligation-breach risk (action requested inside a live
  obligation window).
- **Severity-tiered alerts:** via the shared framework owned by
  performance-monitoring (P1 = human now, P2 = human today, P3 = weekly
  digest, P4 = logged). Housekeeping assigns severities; perfmon
  delivers.

## 7. Orchestration

| Job | When (ET) | What |
|---|---|---|
| `link-check` | Mon 06:00 weekly | Resolve all tracked links; flag failures |
| `monthly-review` | 1st of month 07:00 | Full five-point review pass → triage ladder |
| `obligation-guard` | Before every rung b/c/d action | Ledger gate check |
| `review-report` | After each monthly run | Own operational report → chat |
| `backup-state` | 02:00 daily | Snapshot `state/` (off-VM copy) |

- **Idempotency:** review-log checked before any action — a video is
  never double-processed for the same review cycle.
- **On-demand:** "run housekeeping now" triggers `monthly-review` with a
  scope override (channel/date range).

## 8. Idempotency & safety

- No blind retries on platform mutations — ledger marks "attempted"
  before the call; failures go to your review, not back into the queue.
- Rung (c) and (d) actions are never batched silently — each carries its
  own approval record.
- `remove`/delete has no code path. There is no function that deletes a
  published video. This is deliberate.

## 9. Security

- Platform credentials via the Secure Vault (shared with the publishing
  integrations — housekeeping reuses the same skills, never new tokens).
- Review logs contain no secrets. Approval records reference contract
  IDs, never contract contents.

## 10. Verification checklist (prove before treating as spec)

- [ ] YouTube: caption/description edit, comment pin, cards/end screens,
      trim, unlisted/private — current API support for each.
- [ ] TikTok: caption edit, comment pin, private toggle, trim — current
      API support.
- [ ] Instagram: caption edit, comment pin, archive — current API
      support.
- [ ] Facebook: description edit, comment pin, restricted audience —
      current API support.
- [ ] Minimum API permission scopes for each of the above.
- [ ] Rate limits for metadata-edit calls per platform.

## 11. Key references

- YouTube Data API v3 — videos.update, comments, captions:
  https://developers.google.com/youtube/v3/docs
- Meta Graph API — video/page management:
  https://developers.facebook.com/docs/graph-api/
- TikTok Content Posting API docs (verify current capabilities at
  build).
- Sponsor obligations ledger: `files/ledgers/sponsor-obligations.md`
  (created in tasks-muse HKT1.4).
