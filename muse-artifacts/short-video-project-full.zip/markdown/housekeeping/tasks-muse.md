# Housekeeping — Build Tasks (Muse)

Technical work, in dependency order. Each result is presented for your
**adjust**/**done** before the next task starts. No implementation has
begun — these are build plans.

| ID | Task | Cost | Auto | Depends on | Status |
|---|---|---|---|---|---|
| HKT1.1 | Content inventory builder — read the content ledger, assemble the review set per video (light pass <30 days, full pass older), detect ledger-vs-platform mismatches | $0 out-of-pocket; Muse plan compute | 🟢 | — | Open |
| HKT1.2 | Link checker — weekly job resolving every tracked description link (HEAD→GET fallback), bounded 2-retry budget, `link-status.json` | $0 out-of-pocket; Muse plan compute | 🟢 | HKT1.1 | Open |
| HKT1.3 | Metadata/comment updater — per-platform caption/description edits + pinned redirect comments, with TO-VERIFY-gated fallbacks (description top-line where pinning unsupported) | $0; API calls within quotas | 🟡 | HKT1.8 | Open |
| HKT1.4 | Sponsor obligations ledger — schema + machine mirror (`state/obligations.json`), gate logic blocking hide/alter inside live obligation windows, no code override path | $0 out-of-pocket; Muse plan compute | 🟢 | — | Open |
| HKT1.5 | Trim + hide actions — rung (c) trim and rung (d) unlist/private/archive, each TO-VERIFY-gated per platform, idempotent, approval-recorded | $0; API calls within quotas | 🟡 | HKT1.3, HKT1.4, HKT1.8 | Open |
| HKT1.6 | Observability — own failure tracking (`failures.jsonl`), failure-pattern history, predefined self-healing (bounded retries, fallbacks, quarantine), escalation on repeated failure, anomaly detectors (link-rot spikes, backlog growth), severity-tiered alert hooks | $0 out-of-pocket; Muse plan compute | 🟢 | HKT1.1–HKT1.5 | Open |
| HKT1.7 | Monthly review report — own operational report (reviewed counts per rung, link-rot summary, obligation compliance) delivered in chat after each run | $0 out-of-pocket; Muse plan compute | 🟢 | HKT1.6 | Open |
| HKT1.8 | Platform verification pass — prove every capability in techspec §10 against current official docs/APIs; unproven items become documented manual steps | $0 out-of-pocket; Muse plan compute | 🟢 | — | Open |

**Dependency notes:** HKT1.8 (verification) gates HKT1.3 and HKT1.5 —
no platform mutation ships on an unverified capability. HKT1.4 (ledger
gate) is independent and can build in parallel with HKT1.1/HKT1.2.
