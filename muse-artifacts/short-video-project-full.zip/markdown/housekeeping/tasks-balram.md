# Housekeeping — Your Tasks (Balram)

Decisions and approvals only. Muse does all build work (`tasks-muse.md`).
One task at a time, in dependency order. Nothing is checked off until you
say **"done"** — reply **"adjust"** to change direction.

| ID | Task | What you decide/approve | Cost | Auto | Depends on | Status |
|---|---|---|---|---|---|---|
| HK0.1 | Approve the triage ladder | Confirm rungs (a)–(d) and the never-delete rule as written in `plan.md` §4, or adjust thresholds | Your time (~20 min review) | 🟡 | — | Open |
| HK0.2 | Monthly run date | 1st of the month, or pick another day | Your time (2 min) | 🟡 | HK0.1 | Open |
| HK0.3 | Rung (b) auto-mode | In-place caption/link updates fully automatic, or batched for your glance first | Your time (5 min) | 🟡 | HK0.1 | Open |
| HK0.4 | Hiding mechanics verification sign-off | Review the TO-VERIFY results for unlist/private/archive/trim per platform; anything unproven becomes a manual step you do natively | Your time (~15 min) | 🟡 | HKT1.8 | Open |
| HK0.5 | Per-action approvals (standing) | Each trim, remake, and hide/unlist is presented to you for approval — this is the ongoing job, not a one-time task | ~15–20 min per monthly run | 🟡 | HK0.1 | Open |
| HK0.6 | Sponsor conflict calls | When an action is blocked by a live obligation, you make the call (amend, wait, or escalate to the sponsor) | As needed | 🟡 | HK0.1 | Open |
| HK0.7 | Learning-driven changes (pilot) | Approve any housekeeping process change proposed from learning-KB findings during the pilot | As needed | 🟡 | — | Open |

**How this works:** after each monthly run you'll get one batch — the
review outcome plus every rung (c)/(d) decision queued for your approval.
Rung (b) updates either happen automatically or come in the same batch,
per HK0.3. Sponsor-blocked actions arrive separately with the contract
details attached (HK0.6).
