# Housekeeping Pipeline — Plan

**Owner:** Balram Bandhu · **Built & operated by:** Muse Bandhu
**Date:** 2026-09-24 · **Status:** Draft for review
**Technical spec:** `techspec.md`
**Tasks:** `tasks-balram.md` (decisions & approvals — yours) ·
`tasks-muse.md` (build work — Muse's)

## 1. Vision

Published content never rots silently. Every video across every platform
is re-examined on a monthly cadence: accuracy, relevance, links, sponsor
obligations, and whether a newer version exists. Stale content is
updated, redirected, trimmed, or remade — **never deleted** — and nothing
is hidden or altered while a sponsor obligation is still live. The
channel stays trustworthy as the technology it covers moves on.

## 2. Objectives

- Review 100% of published videos monthly, across YouTube, Instagram,
  Facebook, and TikTok.
- Catch and fix stale content before viewers do: broken links, outdated
  pricing/features, superseded topics.
- Honor every sponsor obligation to the letter — no hide, unlist, or
  material alteration before the minimum-live date without contract
  approval.
- Keep a clean, queryable record of every review decision (what was
  checked, what was done, why).
- Feed failure patterns back into the shared learning knowledge base
  (which topics age fastest, which link sources rot).

## 3. Scope

All published videos on all four platforms, for every channel. This
pipeline does not create content and does not spend money — it maintains
what's already live. Remakes it orders become *new* uploads and are
produced through the create-and-publish pipeline; housekeeping tracks
them, it doesn't render them.

## 4. The monthly workflow — the triage ladder

### 4.1 The review pass

Once a month, on a fixed schedule, the pipeline walks the full content
ledger and checks each video for:

1. **Accuracy** — are the facts, prices, features, and claims still true?
2. **Relevance** — is the topic still worth a viewer's time?
3. **Links** — do description links resolve? Any link rot or redirects to
   dead pages?
4. **Sponsor obligations** — are required links, pinned comments,
   on-screen integrations still in place and compliant?
5. **Newer versions** — does a newer video on this channel cover the same
   topic better?

### 4.2 The ladder

Every video lands on exactly one rung:

- **(a) Still broadly accurate → leave public.** Technology evolved, the
  video is still fine. No action. Logged as reviewed.
- **(b) Slightly stale → update in place.** Refresh the
  caption/description and links; add a pinned comment pointing to the
  newer version; on YouTube long-form, add cards/end screens pointing
  onward where supported (TO-VERIFY current support). The video stays
  public with a clear path to the fresher take.
- **(c) One stale segment → trim and redirect.** Where the platform
  supports trimming (TO-VERIFY per platform), cut the stale segment and
  redirect viewers to updated content via caption/pinned comment. Note:
  published footage generally **cannot** be replaced or spliced — trim
  only removes.
- **(d) Thoroughly outdated → full remake as a NEW upload.**
  Housekeeping flags it; the create-and-publish pipeline produces the
  remake. The old version is hidden/unlisted **only if leaving it public
  would mislead or be inaccurate**. Otherwise it stays public with
  redirect pointers (rung b treatment).

### 4.3 The never-delete rule

**Nothing is ever deleted.** Not underperformers, not embarrassments,
not outdated takes. Deletion destroys watch-time history, breaks embeds,
and looks like a cover-up. Hide/unlist is the strongest action this
pipeline takes, and only on rung (d) with your approval.

### 4.4 Comments stay enabled

Feedback is signal. Hiding comments to dodge criticism is not a
housekeeping action — objections and corrections in comments feed the
learning knowledge base and can trigger a re-review.

## 5. Sponsor obligations — the gate

The sponsor/deal obligations ledger (`ledgers/sponsor-obligations.md`,
schema in techspec §5) records per video: sponsor/brand, contract and
campaign ID, **minimum-live-until date**, required description
links/text, pinned-comment requirements, on-screen/audio integration,
usage rights, exclusivity, approval/contact record.

**The gate:** any action that would hide, unlist, or materially alter a
video is **blocked while obligations remain active**, unless explicitly
approved under the contract. The pipeline checks the ledger before every
rung-(b/c/d) action; a live obligation routes the decision to you, not
around you.

## 6. Platform hiding mechanics (TO-VERIFY from official sources)

Current understanding — verify each against official docs at build:

| Platform | Hide equivalent |
|---|---|
| YouTube | Unlisted / Private |
| TikTok | Private (closest equivalent) |
| Instagram | Archive |
| Facebook | Restricted / private audience where supported |

Same for: pinned comments, caption/description edits, cards/end screens,
trimming, and comment controls. The techspec §10 lists every capability
as a verification item. **Nothing in §4 that depends on a platform
feature ships until that feature is proven.**

## 7. Link hygiene

Links rot faster than facts. The link checker runs more often than the
full review (weekly): every tracked link in every description is
resolved; failures are retried on a bounded budget, then flagged. A spike
in failures from one domain is an anomaly (techspec §6), not just a list
of broken links — it may mean a whole affiliate program or tool shut
down.

## 8. Learning hooks

This pipeline reads from and writes to the **shared learning knowledge
base** (winning hooks/formats/topics, failure patterns — maintained by
the performance-monitoring pipeline). Housekeeping writes: which topics
aged fastest, which link domains rotted, which rung each video landed on
and why, remake performance vs. original. During the pilot,
learning-driven changes need your approval.

## 9. Your control panel — single-prompt controls

- **Run now / schedule:** "run housekeeping now", "housekeeping first of
  the month" — the monthly run is automatic; on-demand runs anytime.
- **Scope:** "review just September's videos", "housekeeping for channel
  1 only".
- **Pause:** "pause housekeeping" halts scheduled runs until you resume.
  (Note: "pause all publishing now" halts publishing; housekeeping is
  separate — say "pause everything" to stop both.)

## 10. Approvals & guardrails

| Action | Mode |
|---|---|
| Monthly review run | Automatic 🟢 |
| Rung (a) leave public / rung (b) in-place updates | Automatic 🟢 |
| Rung (c) trim + redirect | Your approval per video 🟡 |
| Rung (d) remake as new upload | Your approval per video 🟡 |
| Hide/unlist/archive any video | Your approval per video 🟡 |
| Sponsor-conflicted action (obligation live) | Your call, always 🟡 |
| Learning-driven process changes (pilot) | Your approval 🟡 |

Muse never: deletes a video, hides/unlists without your approval, alters
a video under active sponsor obligation without contract approval, or
invents review results.

## 11. Observability & self-healing (summary)

Like every pipeline, housekeeping has its **own** bug, failure, and
performance tracking with captured failure-pattern history; predefined
self-healing mechanisms with automated execution plans (bounded retry
budgets, fallbacks, quarantine); escalation when repeated healing fails;
anomaly detection (broken-link spikes, review backlog growth); and
severity-tiered notifications. Details in techspec §6.

## 12. Reports

Housekeeping's **own operational reports** (defined here, produced by
this pipeline): the monthly review outcome — videos reviewed, and counts
per rung (left public / updated / trimmed / remade / unlisted), link-rot
summary, sponsor-obligation compliance check. Delivered in chat after
each run. Cross-pipeline rollups (R2/R3) are owned by
performance-monitoring.

## 13. What needs your hands vs what runs itself

- **You, per action:** approve trims, remakes, and any hide/unlist;
  resolve sponsor conflicts; approve learning-driven changes in the pilot.
  Expect a short batch session after each monthly run.
- **Muse, everything else:** inventory, checks, link hygiene, ledger
  enforcement, in-place updates, reports, self-healing.
- **Honest limits:** platform features (pin, trim, cards, archive) are
  TO-VERIFY — anything unproven becomes an explicit manual step, never a
  silent skip.

## 14. Costs

**Upfront: $0 out-of-pocket** (your time only).
**Recurring:** draws on your Muse plan for the monthly run + weekly link
checks (light compute — page fetches and API calls, well within quotas).
API calls $0 within quotas. No ad spend, no subscriptions, no per-video
fees in this pipeline.

## 15. Timeline

- **Build (with the other pipelines):** inventory + check engine first,
  then triage actions, then ledger gate, then observability.
- **First run:** one full review cycle after create-and-publish has
  published videos worth reviewing (no earlier than week 5 of the main
  pipeline).
- **Steady state:** monthly review + weekly link checks, fully automatic
  except your per-action approvals.

## 16. Open decisions (yours)

1. Monthly run date — 1st of the month, or another day?
2. Rung (b) in-place updates: fully automatic, or batched for your
   glance first?
3. Remake threshold: how outdated is "thoroughly outdated" — your call
   per video, or do you want written criteria?
