# Content Ledger

Last updated: 2026-09-25. One row per published video. Written by the create-and-publish pipeline; read by housekeeping (monthly review), performance-monitoring (reporting), and earnings-improvement (attribution).

## Schema

| Column | Meaning |
|---|---|
| Video ID | Unique ID for the video (pipeline-assigned) |
| Pipeline run | Run ID that produced it |
| Topic | Topic title |
| Niche / channel | Channel #1 (AI Technology Education) or future channel |
| Platforms posted | YouTube / TikTok / Instagram / Facebook (+ per-platform post IDs) |
| Publish date | YYYY-MM-DD |
| Format / voice | Format template, voice used (or no-voiceover) |
| Views | Per platform |
| Retention | Average watch-through / retention |
| Subscribers gained | Attributed subs |
| Revenue | Platform ad revenue + affiliate + sponsor, attributed |
| Sponsor | Sponsor/brand if sponsored (links to sponsor-obligations.md) |
| Stale-review status | Current / needs-update / remade / unlisted (with reason + date) |
| Remake links | Newer version video ID(s), if any |

## Ledger

| Video ID | Pipeline run | Topic | Niche / channel | Platforms posted | Publish date | Format / voice | Views | Retention | Subscribers gained | Revenue | Sponsor | Stale-review status | Remake links |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| _none yet — no videos published_ | | | | | | | | | | | | |
