# Sponsor Obligations Ledger

Last updated: 2026-09-25. One row per sponsored video. Maintained by the earnings-improvement pipeline; housekeeping reads it for the monthly review.

## Gating rule

**No action to hide, unlist, archive, trim, or materially alter a video is permitted while its obligations remain active, unless explicitly approved under the contract.** The stale-content remediation workflow must check this ledger first.

## Schema

| Column | Meaning |
|---|---|
| Video | Content-ledger video ID |
| Sponsor / brand | Brand name |
| Contract + campaign ID | Contract identifier and campaign name/ID |
| Minimum-live-until | Date (YYYY-MM-DD) the content must stay live and unaltered |
| Required description links/text | Exact links and text the description must carry |
| Pinned-comment requirements | Required pinned comment text and duration |
| On-screen / audio integration | Required on-screen elements, verbal mentions, duration |
| Usage rights, exclusivity, restrictions | What the sponsor may reuse; exclusivity windows; category restrictions |
| Approval / contact record | Who approved, contact details, approval date |
| Status | Active / expired / fulfilled |

## Ledger

| Video | Sponsor / brand | Contract + campaign ID | Minimum-live-until | Required description links/text | Pinned-comment requirements | On-screen / audio integration | Usage rights, exclusivity, restrictions | Approval / contact record | Status |
|---|---|---|---|---|---|---|---|---|---|
| _none yet_ | | | | | | | | | |
