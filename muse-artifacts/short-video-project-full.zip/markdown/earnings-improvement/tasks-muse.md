# Earnings Improvement — Build Tasks (Muse)

Technical work, in dependency order. Each result is presented for your
**adjust**/**done** before the next task starts. No implementation has
begun — these are build plans.

| ID | Task | Cost | Auto | Depends on | Status |
|---|---|---|---|---|---|
| EKT1.1 | Attribution model — `revenue.jsonl` schema, revenue→video/topic/format/platform mapping, confidence labeling (direct/inferred/unknown) | $0 out-of-pocket; Muse plan compute | 🟢 | — | Open |
| EKT1.2 | Tracked-link mechanics — per-video/per-platform link parameters, server-side redirects, click logging to `clicks.jsonl` | $0 out-of-pocket; Muse plan compute | 🟢 | — | Open |
| EKT1.3 | Affiliate layer — program research + `programs.json`, link-hub pages (versioned), dashboard ingestion (API where available, documented manual CSV where not — TO-VERIFY per network) | $0 out-of-pocket; Muse plan compute | 🟡 | EKT1.2, E0.1 | Open |
| EKT1.4 | CTA rotation engine — performance-weighted rotation, weekly updates, 4-week minimum data before a CTA rotates out, KB-backed rules | $0 out-of-pocket; Muse plan compute | 🟢 | EKT1.2 | Open |
| EKT1.5 | Sponsor pipeline tooling — `prospects.json` + monthly shortlist refresh, personalized outreach templates + send tracking (sending gated to you), negotiation prep (numbers + term sheets) | $0 out-of-pocket; Muse plan compute | 🟡 | E0.2 | Open |
| EKT1.6 | Media kit generator — auto-built from real performance-monitoring metrics, monthly refresh, draft-only until you release | $0 out-of-pocket; Muse plan compute | 🟢 | EKT1.1 | Open |
| EKT1.7 | Rate-card framework — formula-driven ranges with sourced, dated bases; estimates labeled as estimates | $0 out-of-pocket; Muse plan compute | 🟢 | E0.3, EKT1.6 | Open |
| EKT1.8 | Obligations ledger writer — on deal close, writes to `files/ledgers/sponsor-obligations.md` + machine mirror in one transaction (schema shared with housekeeping) | $0 out-of-pocket; Muse plan compute | 🟢 | — | Open |
| EKT1.9 | Cost-per-video tracking + price-watch — per-video cost logging, weekly dependency pricing checks, P3 alert on change (P2 if >20%) | $0 out-of-pocket; Muse plan compute | 🟢 | — | Open |
| EKT1.10 | Seasonal ad-market monitoring — demand calendar, window flags feeding R3 (intelligence only, no automated spend decisions) | $0 out-of-pocket; Muse plan compute | 🟢 | — | Open |
| EKT1.11 | Observability — own failure tracking, failure-pattern history, self-healing (bounded retries, CSV fallback, quarantine), escalation, anomaly detectors (revenue drops, CTR collapse, sponsor silence), severity-tiered alert hooks | $0 out-of-pocket; Muse plan compute | 🟢 | EKT1.1–EKT1.4 | Open |
| EKT1.12 | Earnings operational report — weekly attribution/affiliate/sponsor/cost report folding into R2 | $0 out-of-pocket; Muse plan compute | 🟢 | EKT1.11 | Open |
| EKT1.13 | Verification pass — prove techspec §16 items against current official docs/APIs (dashboard APIs, payout granularity, marketplace terms, hub hosting, price sources) | $0 out-of-pocket; Muse plan compute | 🟢 | — | Open |

**Dependency notes:** EKT1.13 (verification) informs EKT1.3's ingestion
paths — API-first where proven, manual CSV where not. EKT1.5's outreach
tooling is gated on your sponsor-category decision (E0.2); EKT1.7 on the
rate-card basis (E0.3). No revenue figure is ever projected as a promise.
