# Earnings Improvement — Your Tasks (Balram)

Decisions and approvals only. Muse does all build work (`tasks-muse.md`).
One task at a time, in dependency order. Nothing is checked off until you
say **"done"** — reply **"adjust"** to change direction.

| ID | Task | What you decide/approve | Cost | Auto | Depends on | Status |
|---|---|---|---|---|---|---|
| E0.1 | Affiliate categories | Which categories are in-bounds (tools, courses, hardware…?) and any to exclude | Your time (10 min) | 🟡 | — | Open |
| E0.2 | Sponsor categories | Which sponsor categories to pursue; any to exclude | Your time (10 min) | 🟡 | — | Open |
| E0.3 | Rate-card basis | Views, subscribers, or engagement-weighted — how starting rates are framed | Your time (10 min) | 🟡 | — | Open |
| E0.4 | Agency/MCN route | Open to introductions, or direct-only for now | Your time (5 min) | 🟡 | — | Open |
| E0.5 | Affiliate applications (standing) | You review the shortlist and submit applications — in your name, your call | ~30 min per application batch | 🟡 | E0.1, EKT1.3 | Open |
| E0.6 | Outreach sending (standing) | Muse drafts personalized pitches; you send (or explicitly authorize a batch) | ~15 min per batch | 🟡 | EKT1.5 | Open |
| E0.7 | Negotiation & closing (standing) | You talk terms and sign — Muse prepares numbers and term sheets | As needed | 🟡 | E0.6 | Open |
| E0.8 | Identity/tax onboarding (standing) | Any affiliate/sponsor onboarding needing your personal details — you complete directly | As needed | 🔴 | — | Open |
| E0.9 | Media kit release (standing) | Auto-generated from real metrics; nothing goes out without your approval | ~10 min per release | 🟡 | EKT1.6 | Open |
| E0.10 | Learning-driven changes (pilot) | Approve CTA-rotation rule changes or attribution changes proposed from KB findings during the pilot | As needed | 🟡 | — | Open |

**How this works:** Muse builds the tracking and pipeline tooling; you
make the human calls — applications, outreach, negotiation, signatures.
Weekly earnings reports fold into the Sunday R2; the numbers are always
attributed and confidence-labeled, never projected as promises.
