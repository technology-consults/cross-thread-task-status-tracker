# Earnings Improvement — Technical Specification

Companion to `plan.md` (the what/why). This file is the how:
attribution, tracked links, affiliate ingestion, the sponsor pipeline,
media kit generation, and cost monitoring.
**Build tasks:** `tasks-muse.md`

## 1. Workspace layout (independent codebase)

```
~/workspace/video-earnings/
├── attribution/
│   ├── attribute.py             # revenue → video/topic/format/platform
│   └── confidence.py            # direct | inferred | unknown labeling
├── affiliate/
│   ├── programs.json            # researched programs + terms + status
│   ├── linkhub/                 # versioned link-hub pages
│   ├── tracker.py               # click/conversion ingestion
│   └── cta-rotate.py            # CTA rotation engine
├── sponsors/
│   ├── prospects.json           # prospect shortlist + stage per prospect
│   ├── outreach.py              # templates + send tracking (gated)
│   ├── mediakit.py              # auto-generated media kit
│   └── ratecard.py              # rate-card framework
├── costs/
│   ├── cost-per-video.py        # per-video cost logging
│   └── price-watch.py           # pricing-change alerts on dependencies
├── market/
│   └── seasonal.py              # seasonal ad-market notes
├── state/
│   ├── revenue.jsonl            # revenue events with attribution
│   ├── clicks.jsonl             # tracked-link events
│   ├── failures.jsonl           # own bug/failure/performance tracking
│   ├── failure-patterns.json
│   └── healing-log.jsonl
└── reports/
    └── weekly/                  # own operational reports
```

## 2. Attribution model

Every revenue event is recorded in `revenue.jsonl`:

```json
{
  "date": "YYYY-MM-DD",
  "source": "platform_ads|affiliate|sponsor",
  "amount": 0.0, "currency": "CAD",
  "ref": "<video ref>", "topic": "<topic>", "format": "<format>",
  "platform": "youtube|instagram|facebook|tiktok",
  "confidence": "direct|inferred|unknown",
  "note": "<basis for inferred attribution>"
}
```

- **Platform ad payouts:** attributed per platform from payout reports;
  per-video split is *inferred* from view share unless the platform
  reports per-video revenue (TO-VERIFY).
- **Affiliate commissions:** *direct* via tracked-link parameters.
- **Sponsor payments:** *direct* via contract/campaign ID, mapped to
  the video refs carrying the integration.
- `confidence.py` enforces the labeling — nothing inferred is ever
  reported without the basis shown.

## 3. Tracked-link mechanics

Links carry per-video parameters (`?src=<ref>&pl=<platform>`) through
the link hub; `tracker.py` records clicks. Conversions come from
affiliate dashboards (§4) joined on the same parameters. Redirects are
server-side (no client JS dependency), and the hub degrades gracefully
if tracking is blocked — the click still lands, only the attribution is
lost (logged as `unknown`, not guessed).

## 4. Affiliate dashboard ingestion (TO-VERIFY per network)

Per program, in `programs.json`: dashboard URL, API availability, auth
method, report cadence. Where an API exists, `tracker.py` pulls on
schedule (bounded retries). Where it doesn't, ingestion is a **documented
manual CSV step** — the pipeline prompts you in chat with exactly what
to download and where to drop it. Manual steps are explicit, never
silent gaps.

## 5. Link hub implementation

Versioned static pages under `affiliate/linkhub/` (one per program or
product group), each link tracked per §3. Descriptions across all four
platforms point at the hub, never at raw affiliate URLs — one place to
update when a program changes terms or a link dies. Hub link inventory
is shared with housekeeping's link checker.

## 6. CTA rotation engine

`cta-rotate.py` holds the CTA pool with per-CTA performance (clicks,
conversions from `clicks.jsonl` + KB). Rotation weights update weekly:
winners get more slots, losers rotate out — bounded (no CTA disappears
entirely without 4 weeks of data). Rotation rules read the learning KB;
rule changes during the pilot need your approval.

## 7. Sponsor pipeline implementation

`prospects.json`: per prospect — brand, contact, niche-fit score,
audience-match notes, stage
(`prospect → contacted → negotiating → closed | declined`), history.

- **Prospecting:** shortlist generated from niche fit + audience match +
  observed sponsor behavior in the space; refreshed monthly.
- **Outreach:** `outreach.py` holds personalized templates and send
  tracking. **Sending is gated** — the pipeline drafts and queues; you
  (or your explicit authorization per batch) send.
- **Negotiation/close:** the pipeline prepares numbers (rate-card output
  + your metrics) and term sheets; you talk and sign. Closed deals write
  to the obligations ledger (§10).

## 8. Media kit generator

`mediakit.py` pulls real metrics from performance-monitoring (views,
followers, engagement, growth — never hand-entered) and renders the kit
(PDF + one-pager). Regenerated monthly or on demand. **External
publication needs your approval** — the generator produces a draft, you
release it.

## 9. Rate-card framework (estimates, not guarantees)

`ratecard.py`: inputs = audience size, engagement rate, niche benchmark
ranges (industry estimates, sourced and dated); outputs = rate ranges
per integration type (dedicated video, integrated mention, link-only).
Every figure carries its basis and date. The card is a starting point
for negotiation, not a price list — actuals replace estimates as your
deal data accumulates.

## 10. Sponsor/deal obligations ledger (schema)

Written by this pipeline on close; enforced by housekeeping (their
techspec §5). Entry per video ref: sponsor/brand, contract + campaign
ID, minimum-live-until date, required links/text, pinned-comment
requirements, on-screen/audio integration, usage rights, exclusivity,
approval/contact record. The human-readable ledger lives at
`files/ledgers/sponsor-obligations.md`; the machine mirror at
housekeeping's `state/obligations.json` — this pipeline writes both on
close, in one transaction.

## 11. Cost-per-video tracking + pricing-change alerts

`cost-per-video.py` logs generation cost per video (model calls, TTS,
render compute — from create-and-publish's records). `price-watch.py`
monitors the dependency price list (media/voice/model providers);
changes trigger a P3 alert (P2 if the change exceeds 20% — cost drift
that big changes unit economics). Pricing sources are official pages/
announcements, checked weekly.

## 12. Seasonal ad-market monitoring

`seasonal.py` maintains the demand calendar (e.g. Q4 strength, January
dip — from industry reporting, dated and sourced) and flags windows
where sponsorship pushes or publishing pushes should lean in. Notes feed
R3 via performance-monitoring. No automated spend decisions — this is
intelligence, not trading.

## 13. Observability / self-healing / alerts

Own `failures.jsonl` + `failure-patterns.json`; predefined self-healing:
bounded retry budgets on dashboard pulls and tracking calls, fallback to
manual CSV import where APIs are unavailable, quarantine of corrupt
attribution batches (reported, never silently dropped); escalation on
repeated failure; anomaly detection — revenue drops vs. baseline,
click-through collapse on a hub link, a sponsor going quiet mid-campaign
(no contracted deliverable movement for N days); severity-tiered alerts
via the shared framework (a mid-campaign sponsor silence is P2).

## 14. Orchestration

| Job | When (ET) | What |
|---|---|---|
| `tracker` pull | 06:30 daily | Click/conversion ingestion → `clicks.jsonl` |
| `attribute` | 07:30 daily | Revenue events → `revenue.jsonl` with confidence labels |
| `cta-rotate` | Sun 08:00 weekly | Rotation weight update from performance data |
| `price-watch` | Mon 07:00 weekly | Dependency pricing check → alerts on change |
| `seasonal` | 1st of month | Ad-market notes → R3 feed |
| `prospect-refresh` | 1st of month | Sponsor shortlist refresh |
| `mediakit` | On demand + monthly | Regenerate from real metrics |
| `earnings-report` | Sun 09:30 weekly | Own operational report → chat (folds into R2) |
| `backup-state` | 02:00 daily | Snapshot `state/` (off-VM copy) |

## 15. Security

- Affiliate/sponsor credentials and API keys in the Secure Vault —
  never in files, memory, or logs.
- Identity/tax details are never stored by this pipeline — they live
  with you; the pipeline records only that onboarding is complete.
- Revenue figures in reports are your private data — never published
  externally without your approval.

## 16. Verification checklist (prove before treating as spec)

- [ ] Affiliate dashboard API availability for each shortlisted
      program (else define the manual CSV path precisely).
- [ ] Platform ad-payout reporting granularity (per-video revenue
      available? — else confirm the view-share inference basis).
- [ ] Paid vs organic revenue split availability per platform.
- [ ] Creator marketplace terms, fees, and payout mechanics for each
      marketplace used.
- [ ] Link-hub hosting approach (static page location, custom domain
      needs).
- [ ] Pricing pages / changelogs for each cost dependency (for
      price-watch sources).

## 17. Key references

- Obligations ledger: `files/ledgers/sponsor-obligations.md`
  (schema shared with housekeeping techspec §5).
- Metrics source: performance-monitoring `metrics.jsonl` (copies —
  earnings never owns platform metrics).
- Learning KB: affiliate/CTA/revenue findings written via
  performance-monitoring's `kb-write.py`.
