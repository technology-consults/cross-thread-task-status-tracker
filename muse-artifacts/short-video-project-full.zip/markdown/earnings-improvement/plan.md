# Earnings Improvement Pipeline — Plan

**Owner:** Balram Bandhu · **Built & operated by:** Muse Bandhu
**Date:** 2026-09-24 · **Status:** Draft for review
**Technical spec:** `techspec.md`
**Tasks:** `tasks-balram.md` (decisions & approvals — yours) ·
`tasks-muse.md` (build work — Muse's)

## 1. Vision

Every video earns as much as it honestly can, and every dollar is
traceable to the video, topic, format, and platform that produced it.
Sponsorships arrive through a real pipeline — prospected, pitched,
negotiated, and closed — not wished for. Affiliates are tracked
click-to-conversion. Costs are watched as closely as revenue. The
objective throughout: **min cost, max impact**.

## 2. Objectives

- Attribute revenue by video, topic, format, and platform — know what
  earns, not just what trends.
- Run the affiliate layer: program research, tracked links, CTA
  rotation, click/conversion tracking.
- Run the sponsor pipeline end-to-end: prospecting → outreach →
  negotiation → close, with a rate-card framework and an
  auto-generated media kit built from real metrics.
- Track cost-per-video and flag pricing changes in the tools the
  pipeline depends on.
- Monitor the seasonal ad market so monetization moves with it, not
  after it.
- Keep platform-dependence risk visible — no single platform should be
  able to silently become the whole business.

## 3. Scope

Revenue-side work only. This pipeline does not create videos, does not
buy ads, and does not review content. Boundaries:

- **Promotion** spends money to amplify winners; **earnings** measures
  what comes back. Promotion reports spend; earnings reports revenue;
  performance-monitoring shows both side by side.
- **Housekeeping** enforces the sponsor obligations ledger; **earnings**
  writes new entries into it when deals close.

## 4. Revenue attribution

Every revenue event — platform ad payout, affiliate commission, sponsor
payment — is attributed to video ref, topic, format, and platform where
the data allows. Attribution confidence is recorded (direct / inferred /
unknown); inferred attribution is labeled, never presented as exact.
Outputs: which topics and formats earn per view, which platforms pay,
where the next dollar of effort goes.

## 5. Affiliate program

- **Research & applications:** Muse researches affiliate programs
  fitting the AI-tech-education niche (and later niches), shortlists by
  fit and terms — you approve and submit applications (manual gate,
  §10).
- **Link hub:** one hub page with tracked links per program/product;
  every video description links through the hub, never raw.
- **Tracked links:** click and conversion tracking per link, per video
  that carried it.
- **CTA rotation:** calls-to-action rotate by performance data — winning
  CTAs get more slots; the rotation rules read the learning KB.
- All affiliate content follows the original-media rule and carries
  proper disclosure.

## 6. Sponsor pipeline

Stages: **prospecting → outreach → negotiation → close.**

- **Prospecting:** sponsor prospect shortlist generated from niche fit,
  audience match, and past sponsor behavior in the space.
- **Outreach:** personalized templates + send tracking. Sending is a
  manual gate (§10) — Muse drafts, you send (or explicitly authorize).
- **Negotiation & close:** manual gates. Muse prepares the numbers and
  the terms; you talk and sign.

**Sponsorship routes** (all five stay open):

1. **Inbound discovery** — media kit + contact path public; inbound
   inquiries triaged automatically.
2. **Personalized outbound pitching** — researched, per-brand pitches.
3. **Creator marketplaces** — profiles maintained, briefs answered.
4. **Agencies / MCNs** — engaged only with your approval; commission
   terms reviewed per deal.
5. **UGC / content-production deals** — AI-avatar/AI-generated tier
   only, with disclosure. Real-human UGC is ruled out for now — no real
   person on camera.

## 7. Media kit & rate card

- **Media kit:** auto-generated from **real** channel metrics (pulled
  from performance-monitoring — never hand-written numbers), refreshed
  monthly. Publishing it externally needs your approval.
- **Rate-card framework:** formula-driven starting points from audience
  size, engagement, and niche benchmarks. Industry rate figures are
  estimates, not guarantees — the card presents ranges with the basis
  shown, not promises.

## 8. Link hub & CTA rotation

Covered in §5; technically: the hub is a versioned page, links carry
per-video tracking parameters, rotation weights update from conversion
data on a weekly cadence. Broken hub links are housekeeping's
link-checker's problem — the two pipelines share the link inventory.

## 9. Seasonal ad-market monitoring & cost tracking

- **Seasonal ad market:** tracks advertiser-demand seasonality (e.g.
  Q4 CPM strength) so publishing and sponsorship pushes lean into high-
  demand windows. Notes feed R3 via performance-monitoring.
- **Cost-per-video tracking:** every video's generation cost logged;
  **pricing-change alerts** when a dependency (model, API, tool)
  changes price — cost drift is caught in days, not at month-end.

## 10. Manual gates — yours, always

| Gate | Why it's manual |
|---|---|
| Identity / tax details for affiliate or sponsor onboarding | Your personal information — never handled by automation 🟡 |
| Affiliate program applications | Submitted in your name 🟡 |
| Outreach sending | Sent in your voice, your relationships 🟡 |
| Negotiation | Judgment + relationships 🟡 |
| Closing deals | Signature authority 🟡 |
| Publishing the media kit externally | Your numbers, your approval 🟡 |

Muse drafts everything up to the gate: research, shortlists, templates,
numbers, terms. Nothing crosses a gate without you.

## 11. Learning hooks

This pipeline reads from and writes to the **shared learning knowledge
base**: affiliate click/conversion data, CTA performance, sponsor
response rates by outreach variant, revenue-by-topic/format findings,
cost observations. During the pilot, learning-driven changes (e.g. CTA
rotation rule changes) need your approval.

## 12. Observability & self-healing (summary)

Own bug/failure/performance tracking with failure-pattern history;
predefined self-healing (bounded retry budgets on dashboard pulls and
link checks, fallback to manual CSV import where an API is unavailable,
quarantine of corrupt attribution batches); escalation on repeated
failure; anomaly detection (revenue drops, click-through collapse, a
sponsor going quiet mid-campaign); severity-tiered alerts via the shared
framework. Details in techspec §13.

## 13. Reports

This pipeline's **own operational reports**: revenue attribution (by
video/topic/format/platform), affiliate performance (clicks,
conversions, per-link, per-video), sponsor pipeline status (stage per
prospect/deal), cost-per-video trends, pricing-change alerts. Delivered
in chat on a weekly cadence (folded into R2) with monthly depth (R3).
Cross-pipeline rollups remain performance-monitoring's job.

## 14. What needs your hands vs what runs itself

- **You, decisions:** the six manual gates (§10); rate-card ranges;
  which affiliate programs to join; which sponsors to pursue; pricing
  and terms calls.
- **Muse, everything else:** research, tracking, attribution, rotation,
  monitoring, reports, self-healing.
- **Honest limits:** affiliate dashboard APIs vary wildly — where no
  API exists, ingestion is a documented manual CSV step, not a silent
  gap. Sponsor rates and timelines are industry estimates until *your*
  data replaces them. No revenue figure is ever projected as a promise.

## 15. Costs

**Upfront: $0 out-of-pocket** (your time only).
**Recurring:** draws on your Muse plan (tracking, attribution, report
generation — light compute; API calls $0 within quotas). Affiliate
programs cost $0 to join. Creator marketplaces are free to join.
**If** you engage an agency/MCN, expect commission (typically 10–20% of
deal value — industry estimate, verify per agreement); that spend needs
your per-deal approval and is reported against the revenue it produced.

## 16. Timeline

- **Build:** attribution model + tracked links first, then affiliate
  layer, then sponsor pipeline tooling, then media kit/rate card, then
  monitoring.
- **Affiliate applications:** once pilot videos exist and the media kit
  has real numbers (no earlier than week 5 of create-and-publish).
- **Sponsor outreach:** when audience metrics support a pitch — your
  call, informed by R3, not by a calendar date.

## 17. Open decisions (yours)

1. Affiliate programs: which categories are in-bounds for AI tech
   education (tools, courses, hardware)?
2. Sponsor categories to exclude, if any.
3. Rate-card basis: views, subscribers, or engagement-weighted?
4. Agency/MCN route: open to introductions, or direct-only for now?
