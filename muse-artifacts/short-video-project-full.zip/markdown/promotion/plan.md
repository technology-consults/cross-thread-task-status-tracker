# Short-Video Promotion & Advertising — Plan

**Owner:** Balram Bandhu · **Built & operated by:** Muse Bandhu
**Date:** 2026-09-23 · **Updated:** 2026-09-24 — locked decisions incorporated
**Status:** Draft for review (awaits pilot winners)
**Technical spec:** `techspec.md`
**Tasks:** `tasks-balram.md` (decisions & approvals — yours) ·
`tasks-muse.md` (build work — Muse's)
**Parent pipeline:** `../create-and-publish/plan.md` (builds the content)
**Locked decisions:** `../reference/decisions-log.md` ·
**Monetization research:** `../reference/monetization-research.md`

> This document covers the **promotion pipeline** only — one of five
> independent pipelines, each with its own codebase, its own docs, and its
> own observability: **create-and-publish**, **promotion** (this),
> **housekeeping**, **performance-monitoring**, and **earnings-improvement**.
> They share a learning knowledge base (see §9).

## 1. Objective

**Min cost, max impact.** Every dollar of paid spend must beat its organic
benchmark or it gets cut. Paid never substitutes for organic — it amplifies
proven winners only.

## 2. Principles

1. **Fund winners only.** No cold creative ever gets budget. A video earns
   paid support by performing organically first (top-decile velocity /
   retention in its first 48h).
2. **Test → validate → scale → harvest.** Budgets move up a fixed ladder
   on measured efficiency, never on hunches.
3. **Kill fast.** Losers are paused by rule, not debated.
4. **One metric per campaign type:** cost per view (reach campaigns), cost
   per follower/subscriber (growth campaigns).
5. **Bounded by default.** Every campaign has a default duration and
   budget; anything bigger is an explicit, approved override.
6. **Reports separate organic results, paid results, and measured
   relationships** — never blended into one number.

## 3. Organic engine (always-on, $0)

The pipeline enforces these by template; promotion owns the tuning:

- **Reels/Shorts craft:** hook <3s, burned-in captions, 9:16 full-bleed,
  original audio, niche + broad hashtags.
- **Stories flywheel:** every Reel reshared to Stories.
- **Native cross-posting:** each video ships as a separate native upload
  to IG *and* the FB Page (never cross-links — platforms demote them).
- **First-hour engagement (defined workflow):** at publish +15/+30/+45
  min, Muse pings you with new comments; you reply within the hour (or
  approve Muse-drafted replies where the API allows). A question-comment
  is seeded at publish to start discussion. Full runbook: pipeline tech
  task T2.5.
- **Trending-audio swap (your 2-minute job):** the pipeline ships with
  original audio — commercial trending sounds can't be attached via API.
  For proven winners, you open the video natively in TikTok/IG, swap in
  the trending sound, and repost. Muse flags which winners deserve it and
  suggests the sound. Manual, but only ever for winners.
- **YouTube-native:** keyword-first titles, `#Shorts`, pinned question
  comment, theme playlists, title A/B variants logged for review.
- **Monthly collab:** one collab Reel with a same-niche creator (Muse
  shortlists, you approve outreach).
- **Winner recycling:** monthly cutdowns, "best of" compilations, and
  30-day reposts of proven videos with fresh hooks — winners keep working
  (pipeline builds it; promotion picks the winners from R2).
- **Remix/response videos:** weekly shortlist of breakout videos from
  larger in-niche creators; approved targets become original response
  takes with credit — borrowed audience, your spin.
- **TikTok distribution:** every video ships natively to TikTok alongside
  YT/IG/FB — strong organic reach per post in short-form (benchmarked at
  build; pipeline tech spec §1.4).

*Optional levers (not committed — revisit when the core is humming):*
episodic series (Part 1/2/3), a hard retention-gate rule (kill formats
under ~30% 3-second retention), external seeding (niche subreddits, X
clips), community features at thresholds (YT Community tab, IG broadcast
channel).

Exact automation support per tactic is verified at build (tech spec §6) —
anything the APIs can't do becomes a manual step, never a silent skip.

## 4. Paid engine — Meta (Instagram + Facebook)

**Two campaign types:** reach (video views on a winning Reel) and growth
(follows). One campaign per hero video; Reels + Stories placements; 9:16
creative as-is.

**Scale up / scale down ladder** (thresholds finalized in P0.1):

| Stage | Budget | Duration | Advance if |
|---|---|---|---|
| Probe | $5/day | 3 days | Cost per view/follower under threshold |
| Validate | $15/day | 7 days | Efficiency holds within 20% of probe |
| Scale | $30–50/day | rolling | Cost stays under threshold |

**Automatic scale-down / kill triggers:**
- Cost ≥ 1.5× threshold for 48h → budget halved, you're notified.
- Cost ≥ 2× threshold for 48h → paused, you're notified.
- Two consecutive scale-downs → killed, learnings logged.
- Creative fatigue (frequency >3.5 with falling engagement) → retired, a
  variant cut from the winner.

Scale-downs and pauses inside these rules are automatic with notification;
**scale-ups past 2× always need your approval.**

## 5. Paid engine — Google (YouTube)

- **Campaign:** Video Views objective on an already-published Short,
  Shorts placement, vertical <60s creative, sound-on.
- **Timing:** launch soon after publish to catch the early window. (Paid
  views don't count toward monetization thresholds; the organic views they
  trigger do.)
- **Targeting:** broad affinity/in-market around the niche first, then
  competitor-keyword segments; mobile only; frequency caps.
- **Warm layer:** separate retargeting campaign for viewers of previous
  videos — the cheapest conversions.
- **Same ladder and auto-brakes as Meta** (§4).

## 6. Min-cost, max-impact tactics

1. **Winners-only funding** — the single biggest saver; most videos never
   see a dollar.
2. **Dayparting:** spend concentrated in the channel's proven hours, not
   24/7.
3. **Geo layering:** 1–2 best geos first; expand only on efficiency.
4. **Warm before cold:** retarget engagers before prospecting strangers.
5. **Lookalikes** built from video engagers, not broad interest buckets.
6. **Creative recycling:** one hero → cheap cutdowns for probe tests.
7. **Free cross-promo:** each channel's community tab and Stories push the
   others — $0 reach.
8. **Frequency discipline:** caps stop you paying to annoy people.

## 7. Campaign defaults & per-campaign overrides

- **Defaults:** 7-day duration, $10/day, thresholds per §4, monthly cap
  set in P0.1.
- **Overrides:** any campaign may override duration, budget, or geo —
  every override is logged with who changed what, when.
- **Single-prompt controls:** "pause all ads", "double the fitness
  channel's budget", "extend *finance-ep12* by 7 days", "kill anything
  over $0.05 CPV", "how much did we spend this month?".

## 8. Reporting — this pipeline's own reports + shared rollups

This pipeline defines its **own operational reports** (built in tech task
P1.4): a weekly **ad response report** (per campaign: spend, impressions,
views, follows/subs, cost per view/follower, frequency, dates vs
defaults), a **spend-vs-cap report** (pacing against the monthly cap,
projected month-end), and a **kill-trigger log** (every auto scale-down,
pause, and kill with the rule that fired and the learnings logged).
Affiliate reports (clicks, conversions, revenue per link/video) are added
once affiliate programs are live.

These feed the **shared R1/R2/R3 cross-pipeline rollups** owned by the
performance-monitoring pipeline's reporting framework — one framework,
many contributors:

- **R1 — Organic impact & popularity.** Per-video velocity, retention,
  engagement rate, follower/subscriber attribution, format leaderboard,
  breakout flags. Weekly. (Organic data comes from the create-and-publish
  pipeline's metrics feed.)
- **R2 — Ad response.** Per campaign: spend, impressions, views,
  follows/subs, cost per view/follower, frequency, dates vs defaults.
  Weekly. (This pipeline's data.)
- **R3 — Organic × paid relation.** Incremental lift vs a matched organic
  baseline; growth in the 7 days *after* spend stopped; blended cost per
  1k views; a keep/cut verdict per boost. Weekly. (Joint
  create-and-publish + promotion data.)

Delivery: chat digest in the project side chat; full tables under `reports/`.
Videos cited by ref (`<channel>.yyyy.MM.dd.N`) everywhere. Organic
results, paid results, and measured relationships are always reported
separately — never blended.

## 9. Approvals, guardrails & self-governance

- Muse **proposes** every campaign (creative, budget, duration, targeting);
  you **approve** each launch and any scale-up past 2×.
- Scale-downs/pauses inside the rules are automatic with notification.
- **Anomaly brake:** spend pacing >150% of expected → auto-pause +
  instant alert.
- **Hard monthly cap** — campaigns cannot exceed it, individually or
  combined.
- Execution is semi-manual through the Ads Manager / Google Ads web UIs
  (Muse drives, you can watch) — proposals automatic, launches approved.
- **Sponsor/affiliate manual gates:** affiliate program applications,
  sponsor outreach, negotiation, and closing are yours; identity/tax
  details are never handled by Muse. Muse prepares shortlists, drafts,
  tracking, and revenue attribution.

### This pipeline's own observability

Independent of the other four pipelines; shared patterns are written back
to the learning knowledge base.

- **Own tracking:** every campaign event, rule evaluation, brake trigger,
  spend anomaly, and reporting failure is logged against this pipeline.
- **Failure-pattern history:** recurring patterns captured and used —
  e.g. which creative types fatigue fastest, which geos burn budget, what
  UI changes broke the browser automation last time.
- **Self-healing (bounded):** predefined mechanisms with automated
  execution plans — auto scale-down/pause/kill per the ladder rules,
  retry budgets on report pulls, quarantine of suspect metrics. Repeated
  healing failures escalate instead of looping.
- **Anomaly detection:** watches for unfavorable conditions and exception
  scenarios — spend pacing anomalies, a campaign's efficiency collapsing,
  API/UI breakage in the browser automation, reporting gaps.
- **Severity-tiered alerts:** P1 = anomaly brake fired (spend >150% of
  expected — auto-paused, you alerted instantly); P2 = kill triggers and
  repeated brake events needing your call; P3 = informational (creative
  fatigue retirements, ladder advancements). Tiers are set by importance,
  occurrence rate, urgency, and the need for human review, approval, or
  intervention — thresholds locked with you in P0.1.

## 10. Costs

Tooling $0. Spend = your caps. Probe $5/day, validate $15/day, scale
$30–50/day. Suggested pilot month: **$150–300 total** across Meta +
Google.

## 11. Monetization targets — views & subscribers → CAD income

How short-form actually pays, ranked by realism. (Full research — creator
revenue mix, sponsor-rate benchmarks, affiliate economics, and caveats —
lives in `../reference/monetization-research.md`.)

1. **Brand sponsorships** — the real engine. Micro-influencer rates run
   roughly **$25–$50 CAD per 1,000 followers per sponsored post**
   (finance/tech niches pay the top end). One sponsored post a month at
   50k followers ≈ $1,250–$2,500.
2. **YouTube Shorts ad revenue** — real but thin. Shorts pay from a pooled
   fund, roughly $0.05–$0.15 USD per 1,000 views (≈ $0.07–$0.21 CAD;
   working figure **$0.14 CAD**). Requires **1,000 subs + 10M Shorts views
   in 90 days** before a single dollar flows.
3. **Affiliate** — niche-dependent; finance/tech links can out-earn ad
   revenue per view by 10× or more.
4. **Platform bonuses/gifts** — small and shrinking; treat as a bonus,
   never the plan.

### What it takes (working model)

| Monthly income target | Via Shorts ads alone | Via audience (the realistic path) |
|---|---|---|
| CAD 100 | ~0.7M Shorts views/mo | Monetization unlocked: 1k subs + 10M views/90d |
| CAD 500 | ~3.6M views/mo | ~15–25k followers + 1 sponsor/mo |
| CAD 1,500 | ~11M views/mo | ~50k followers + 2 sponsors/mo |
| CAD 5,000 | ~36M views/mo | ~100–150k followers + 2–3 sponsors + affiliate |
| CAD 10,000 | ~71M views/mo | 250k+ followers + sponsors + affiliate + own funnel |

Takeaway: Shorts ad revenue alone is a weak engine — the audience column
is how this actually pays. Paid promotion doesn't buy income directly; it
buys **audience faster**, and the audience buys the income.

### Milestones with associated promo cost

Income below is **gross revenue** — net is gross minus the promo spend
shown alongside it. (Media generation isn't counted here: it draws on
your existing Muse plan, no incremental cash outlay.)

| Milestone | Gross income/mo | Audience target | Promo spend/mo | **Net income/mo** |
|---|---|---|---|---|
| M1 — Monetized | CAD ~100 | 1k subs, 10M Shorts views/90d | $150–300 | ≈ **−$125** (investment phase) |
| M2 — First sponsors | CAD ~500 | 15–25k followers | $300–500 | ≈ **+$100** |
| M3 — Steady | CAD ~1,500 | ~50k followers | $500–900 | ≈ **+$800** |
| M4 — Full-time-ish | CAD ~5,000 | 100–150k followers | $900–1,500 | ≈ **+$3,800** |
| M5 — Scale | CAD ~10,000 | 250k+ followers | $1,500–3,000 | ≈ **+$7,750** |

Net uses mid-range promo spend. M1 being net-negative is expected and
normal — you're buying the audience asset (subscribers/followers), which
is what all later milestones monetize. Break-even lands around M2; from
M3 on, promo is roughly 30–60% of gross and falling as organic compounds.

Why the promo math works: at a $0.02 cost per view, $300/mo buys only
~15k paid views — nowhere near the millions in the table. It works because
paid **amplifies proven organic winners** (the entire strategy), and
followers compound: each winner's audience makes the next video cheaper to
push. Organic does the heavy lifting; paid shortens the road. How much
organic lift each paid dollar actually produces is measured, not assumed —
that's what the R3 report exists to verify. When paid doesn't lift
organic, the ladder kills the spend within days.

### Can ad spend buy these views? (honest math)

Yes — both platforms let you pay directly for views. **Meta:** boost a
Reel or run a Video Views / Engagement campaign (Reels + Stories
placements). **Google:** a Video Views campaign on your published Short,
served in the Shorts feed. That's exactly what the paid engine (§4–§5)
does.

But can the budgets above *buy* the view counts in the table? No — not
even close:

| Milestone | Views needed/mo | What the promo budget buys (@ $0.02/view) | Share of target |
|---|---|---|---|
| M1 | 0.7M | ~11k views | ~2% |
| M2 | 3.6M | ~20k views | ~0.6% |
| M3 | 11M | ~35k views | ~0.3% |
| M4 | 36M | ~60k views | ~0.2% |
| M5 | 71M | ~112k views | ~0.16% |

**~98%+ of the views must come from organic distribution.** Paid is a
catalyst, not the fuel: a $5–15/day push behind a proven winner buys
initial velocity and follower conversions; *if* the content earns it,
organic distribution follows — the R3 report measures exactly how much
lift each paid dollar produced, so we keep what works and cut what
doesn't. That's the winners-only rule doing its job.

Same story for followers: at ~$1 per follower, $400/mo buys ~400
followers — M2's 15–25k followers must overwhelmingly come from organic
breakouts, with paid accelerating the winners. The **R3 report exists
precisely to verify this**: it measures incremental lift per paid dollar,
so we always know whether the catalyst is working or we're just buying
expensive views. If R3 ever shows paid isn't lifting organic, budgets get
cut — the strategy enforces this automatically.

### Honest caveats

- Ranges, not promises. Niche matters enormously — finance pays 2–3×
  entertainment for both ad rates and sponsors.
- Organic breakout is the gating factor: no budget fixes a channel with
  no winners. That's exactly why funding is winners-only (P2.1).
- Timelines depend on hit rate. With ~90 videos/month, even a 5% breakout
  rate compounds fast — or doesn't, and the weekly review says so early
  enough to pivot before real money is spent.
- Sponsor-rate and revenue-mix figures are industry estimates and creator
  reports, not official payout data — see the caveats in
  `../reference/monetization-research.md`. Recalibrate every figure
  against actuals once revenue starts flowing (tech spec §7).

## 12. Open decisions (yours)

1. Monthly ad cap — total and per channel.
2. Default campaign duration — 7 days OK, or different?
3. Cost-per-view / cost-per-follower thresholds per platform (defaults OK?).
4. Priority: views-first, followers-first, or mixed?
5. Alert severity thresholds — what fires a P1 vs P2 vs P3 (proposed in
   tech task P1.5; you lock them).
6. Affiliate program applications — which programs to apply to (your
   approval; identity/tax details are yours).
