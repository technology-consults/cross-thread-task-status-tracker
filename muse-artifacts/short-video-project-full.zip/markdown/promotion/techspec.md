# Short-Video Promotion — Technical Specification

Companion to `plan.md` (the what/why). This file is
the how: execution route, campaign model, rules engine, and reporting
mechanics.
**Build tasks:** `tasks-muse.md`
**Locked decisions:** `../reference/decisions-log.md` ·
**Architecture:** `../reference/architecture.md`

> This spec covers the **promotion pipeline** only. Like each of the five
> pipelines, it owns its observability (own tracking, failure patterns,
> self-healing, anomaly detection, severity-tiered alerts) and its own
> operational reports; it contributes to the shared R1/R2/R3 rollups owned
> by the performance-monitoring pipeline's reporting framework.

## 1. Execution route

No full ads API exists in Muse's toolkit → campaigns are built through the
**Meta Ads Manager and Google Ads web UIs via browser automation**:
semi-manual and fragile to UI changes, so every launch needs your approval
regardless. Proposals, math, monitoring, and reporting are fully
automated; only the clicking is supervised (you can watch).

## 2. Campaign object model

**`promo/defaults.yml`:**
`default_duration_days: 7`, `default_daily_budget: 10`,
`meta_objective: engagement`, `google_objective: video_views`,
`probe_cpv_threshold`, `probe_cpf_threshold`,
`scale_down_trigger` (cost ≥ 1.5× threshold for 48h),
`kill_trigger` (2 consecutive scale-downs),
`monthly_cap` (set in P0.1).

**`promo/campaigns/<id>.yml`** — per-campaign overrides:
`duration_days`, `daily_budget`, `geo`, `objective`. Overrides win over
defaults; the ledger records who changed what, when.

**`promo/state/ledger.json`** — campaigns, budgets, overrides, spend vs
cap, change log, anomaly-brake events.

**`promo/state/affiliate.json`** — affiliate programs, tracked links per
program/video, clicks, conversions, revenue per link and per video (by
ref); feeds revenue attribution in the earnings-improvement pipeline.

**`promo/state/failures.jsonl`** — this pipeline's own bug/failure/
performance event log (rule misfires, brake triggers, report-pull
failures, UI automation breakage).

## 3. Rules engine

- **Ladder evaluation:** probe → validate → scale only when CPV/CPF beats
  the P0.1 thresholds (validate requires efficiency within 20% of probe).
- **Auto brakes:** 1.5× threshold for 48h → halve budget + notify; 2× for
  48h → pause + notify; two consecutive scale-downs → kill + log
  learnings; frequency >3.5 with declining CTR → retire creative, cut a
  variant from the winner.
- **Anomaly brake:** spend pacing >150% of expected → auto-pause +
  instant alert.
- **Monthly hard cap** enforced in the ledger — blocks new or overriding
  spend that would exceed it.
- **Scale-ups past 2× are never automatic** — they wait for approval.

## 4. Single-prompt controls (P2.4)

Natural-language commands wired to the ledger + browser execution:
"pause all ads" · "double the <channel> budget" · "extend *<campaign>*
by 7 days" · "kill anything over $0.05 CPV" · "how much did we spend
this month?".

## 5. Attribution & reporting

- **R1** (organic impact) comes from the create-and-publish pipeline's
  metrics feed (tech tasks T2.3).
- **R2** (ad response) from ad-platform reports (browser-pulled) into the
  promo ledger: spend, impressions, views, follows/subs, CPV/CPF,
  frequency, dates vs defaults.
- **R3** (organic × paid): incremental lift vs a matched organic baseline
  (same-format, same-age videos without spend); paid→organic tail (growth
  in the 7 days *after* spend stopped); blended cost per 1k views;
  keep/cut verdict per boost.
- Weekly crons + on-demand; chat digest + full tables under `reports/`.
  Videos cited by ref (`<channel>.yyyy.MM.dd.N`) everywhere.
- **Own operational reports** (this pipeline, tech task P1.4): weekly ad
  response, spend-vs-cap pacing, kill-trigger log — produced automatically
  and contributed to the shared R2/R3 rollups under the
  performance-monitoring pipeline's reporting framework. Organic results,
  paid results, and measured relationships are always reported separately.
- **Affiliate attribution:** clicks/conversions/revenue per tracked link
  and per video feed the earnings-improvement pipeline's revenue
  attribution.

## 6. Verification notes

- "Launch within ~2h of publish" is a **hypothesis**, not a platform
  fact — treat as a test, measure, keep or drop.
- Never claim paid views directly cause organic distribution; report only
  measured lift (R3).
- Story poll/question stickers, automated comment replies/pins, Trial
  Reels via API: assume **unsupported** until a working integration is
  proven — the organic plan promises nothing that isn't verified.

## 7. This pipeline's observability (self-governance)

Independent of the other four pipelines; shared patterns are written back
to the learning knowledge base.

- **Own event tracking:** `promo/state/failures.jsonl` logs every campaign
  event, rule evaluation, brake trigger, spend anomaly, and reporting
  failure for this pipeline.
- **Failure-pattern history:** recurring patterns captured and used —
  which creative types fatigue fastest, which geos burn budget, which UI
  changes broke the browser automation and how it was fixed.
- **Self-healing (bounded):** predefined mechanisms with automated
  execution plans — the ladder's auto scale-down/pause/kill, retry budgets
  on report pulls, quarantine of suspect metrics. Repeated healing
  failures escalate instead of looping.
- **Anomaly detection:** watches for unfavorable conditions and exception
  scenarios — spend pacing anomalies, a campaign's efficiency collapsing,
  breakage in the browser automation, reporting gaps.
- **Severity-tiered alerts:** P1 = anomaly brake fired (spend >150% of
  expected — auto-paused, instant alert); P2 = kill triggers and repeated
  brake events needing a decision; P3 = informational (creative fatigue
  retirements, ladder advancements, weekly report ready). Tiers are set by
  importance, occurrence rate, urgency, and the need for human review,
  approval, or intervention — thresholds locked with BalRam in P0.1.

## 8. Monetization tracking

Once revenue starts flowing, the R2/R3 reports grow two fields: revenue
per campaign and revenue per video (by ref). Assumptions behind the
targets (Shorts RPM ≈ $0.14 CAD/1k views, sponsor rates $25–$50/1k
followers/post) live in plan §11 and get recalibrated against actuals —
the first month of real data replaces every estimate above. Affiliate
click/conversion/revenue data flows from `promo/state/affiliate.json` to
the earnings-improvement pipeline.
