# Short-Video Promotion — Task List (Technical Build)

Companion to `techspec.md`. **Every task here is
owned by Muse Bandhu** — the build work. (Balram Bandhu's decisions,
billing setup, and campaign approvals live in `tasks-balram.md`.)

Work top-to-bottom: each task has a **review gate** — output is presented,
Balram Bandhu says **"adjust"** or **"done"**. Nothing downstream starts
until its dependencies are done. Deps on the other lists marked
`you:Px` / `pipe:Tx` / `pipetech:Tx`. One task at a time, in dependency
order.

**Indicator:** 🟢 fully automatable · 🟠 technically challenging —
partly manual/fragile (ad-platform UIs driven by browser automation).
**Cost:** `$0` · `ads` = ad spend, always within cap and pre-approved.

---

## P1 — Setup

- [ ] **P1.3 — Campaign templates + promo ledger** 🟢 `$0`
  Owner: Muse Bandhu · Dep: you:P0.1 · Output: `promo/defaults.yml`,
  `promo/campaigns/` dir, `promo/state/ledger.json` (campaigns, budgets,
  overrides, spend vs cap, change log), `promo/state/affiliate.json`
  (programs, tracked links, clicks/conversions/revenue per link and per
  video).
  Gate: template shown; defaults match P0.1.

- [ ] **P1.4 — Report generators (this pipeline's operational reports + R2/R3 contribution)** 🟢 `$0`
  Owner: Muse Bandhu · Dep: pipetech:T2.3, P1.3 · Output: scripts
  producing this pipeline's own operational reports — weekly ad response
  (spend, impressions, views, follows/subs, CPV/CPF, frequency, dates vs
  defaults), spend-vs-cap pacing, kill-trigger log — plus the data feeds
  for the shared R2 (ad response) and R3 (organic × paid relation)
  cross-pipeline rollups owned by the performance-monitoring pipeline's
  reporting framework. Organic results, paid results, and measured
  relationships stay separate.
  Gate: sample R3 on dummy data reads correctly.

- [ ] **P1.5 — Pipeline observability (own tracking, self-healing, alerts)** 🟢 `$0`
  Owner: Muse Bandhu · Dep: P1.3 · Output: this pipeline's independent
  observability — `promo/state/failures.jsonl` event tracking (campaign
  events, rule evaluations, brake triggers, spend anomalies, reporting
  failures), failure-pattern history (creative fatigue curves, geo burn,
  UI breakage fixes) feeding the shared learning KB, **bounded
  self-healing** (ladder auto scale-down/pause/kill, retry budgets on
  report pulls, quarantine of suspect metrics; repeated failures
  escalate), **anomaly detection** (spend pacing anomalies, efficiency
  collapse, browser-automation breakage, reporting gaps), and
  **severity-tiered alerts** (P1/P2/P3 per tech spec §7 — thresholds
  proposed here, locked by BalRam in you:P0.1).
  Gate: fault-injection drill — a spend spike fires the anomaly brake,
  pauses the campaign, and pages at P1.

## P2 — Pilot promotion

- [ ] **P2.1 — Build probe campaigns (browser automation)** 🟠 `ads`
  Owner: Muse Bandhu · Dep: pipe:T2.2, you:P1.1, you:P1.2, P1.3 ·
  Output: $5/day × 3-day probes on the top 2–3 organic winners, Meta +
  Google, built through the Ads Manager / Google Ads UIs.
  (Balram Bandhu approves each launch — you:P2.1.)
  Gate: campaigns built and awaiting approval.
  *Why challenging: browser-driven UI work — workable but fragile when
  UIs change.*

- [ ] **P2.2 — Validate + first scale (execution)** 🟠 `ads`
  Owner: Muse Bandhu · Dep: P2.1 · Output: qualifiers advanced to $15/day
  × 7 days; losers auto scale-down / pause / kill per the ladder rules,
  with notification. (Scale-ups past 2× wait for BalRam Bandhu's approval
  — you:P2.2.)
  Gate: validate-stage efficiency reviewed.

- [ ] **P2.3 — Weekly promo sweep cron** 🟢/🟠 `$0`
  Owner: Muse Bandhu · Dep: P2.1 · Output: every Monday — auto-proposes
  boosts for the week's organic winners; Balram Bandhu approves
  (you:P2.3), Muse Bandhu launches.
  Gate: first proposal batch approved/adjusted.

- [ ] **P2.4 — Single-prompt campaign controls** 🟢 `$0`
  Owner: Muse Bandhu · Dep: P1.3 · Output: "pause all ads", "double the
  <channel> budget", "extend *<campaign>* by 7 days", "kill anything over
  $0.05 CPV", "how much did we spend this month?" — all wired to the
  ledger + browser execution.
  Gate: Balram Bandhu tests two commands live.

## P3 — Ongoing & expansion

- [ ] **P3.1 — Combined report cron (R3 weekly)** 🟢 `$0`
  Owner: Muse Bandhu · Dep: P2.1 · Output: weekly organic×paid relation
  digest — incremental lift, paid→organic tail, blended cost/1k views,
  keep/cut verdicts. (Contributes to the shared R3 rollup; the
  performance-monitoring pipeline owns the framework.)
  Gate: first R3 reviewed together.

- [ ] **P3.2 — Per-channel promo rollout (execution)** 🟠 `ads`
  Owner: Muse Bandhu · Dep: pipe:T4.2 · Output: repeat P1–P2 per new
  themed channel (targeting + budgets differ). (Sign-off per channel —
  you:P3.2.)
  Gate: same review as P2.2, per channel.

---

## Dependency map (this list)

```
(you:P0.1) → P1.3 → P1.4 ─┐
                   └→ P1.5 (observability) ─┐
(pipe:T2.2) ───────────────┴→ P2.1 → P2.2 → P3.2
(pipetech:T2.3) ──→ P1.4, P3.1    ↘ P2.3, P2.4
(you:P0.2) → affiliate tracking live in affiliate.json
```

## Cost summary

| | Upfront | Recurring |
|---|---|---|
| P1 setup | **$0** | — |
| Probes | — | $5/day × 3 days per hero |
| Validate / Scale | — | $15/day, then $30–50/day on winners only |

**How we review:** output presented per task; Balram Bandhu says "adjust"
or "done". Checkboxes tick as we go; this file stays current.
