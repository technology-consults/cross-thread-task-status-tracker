# Short-Video Promotion — Task List (Decisions & Approvals)

Companion to `plan.md`. **Every task here is owned by
Balram Bandhu** — your decisions, manual actions, and approval gates.
Depends on the create-and-publish pipeline; pipeline task deps marked
`pipe:Tx` / `pipetech:Tx`. (Muse Bandhu's build work lives in
`tasks-muse.md`. Locked decisions: `../reference/decisions-log.md`.)

Work top-to-bottom: each task has a **review gate** — Muse Bandhu presents
the output, you say **"adjust"** or **"done"**. Nothing downstream starts
until its dependencies are done. One task at a time, in dependency order.

**Indicator:** 🟡 needs your decision/approval · 🔴 manual action required
(Muse *cannot* do this — billing setup is yours).
**Cost:** `$0` · `ads` = ad spend, always within your cap and pre-approved.

---

## P0 — Parameters

- [ ] **P0.1 — Lock promo parameters** 🟡 `$0`
  Owner: Balram Bandhu · Dep: pipe:T2.2 (real metrics make thresholds
  sane; draft earlier OK) · Output: monthly ad cap (total + per channel),
  default campaign duration, cost-per-view / cost-per-follower scale
  thresholds, views-first vs followers-first priority, **alert severity
  thresholds** (what fires a P1 vs P2 vs P3 for this pipeline — proposed
  by Muse Bandhu in P1.5), operational report format. (Muse Bandhu drafts
  the numbers from pilot data.)
  Gate: you approve the numbers → written to `promo/defaults.yml`.

- [ ] **P0.2 — Affiliate & sponsor setup decisions** 🟡 `$0`
  Owner: Balram Bandhu · Dep: pipe:T0.4 · Output: which affiliate programs
  to apply to; which sponsor prospects get outreach. **Manual gates stay
  yours:** identity/tax details, application submissions, outreach sends,
  negotiation, closing. (Muse Bandhu prepares the program research,
  prospect shortlist, application drafts, and outreach templates with
  tracking — pipetech:T1.19.)
  Gate: program list + first outreach batch approved.

## P1 — Your setup actions

- [ ] **P1.1 — Meta Ads Manager ready (ad account + billing)** 🔴 `$0`
  Owner: Balram Bandhu · Dep: P0.1 · Output: ad account exists, payment
  method added. (Muse Bandhu verifies browser access afterwards.)
  Gate: Muse Bandhu opens Ads Manager and reads the account successfully.
  *Why manual: billing setup is yours; verification is Muse's.*

- [ ] **P1.2 — Google Ads account ready (account + billing)** 🔴 `$0`
  Owner: Balram Bandhu · Dep: P0.1 · Output: account + billing live.
  (Muse Bandhu verifies access afterwards.)
  Gate: same as P1.1, on Google Ads.

## P2 — Pilot promotion (your approvals)

- [ ] **P2.1 — Approve probe campaign launches** 🟡 `ads`
  Owner: Balram Bandhu · Dep: pipetech:P2.1 (campaigns built, awaiting
  approval), you:P1.1, you:P1.2 · Output: $5/day × 3-day
  probes on the top 2–3 organic winners, Meta + Google — each launch
  approved by you before it goes live.
  Gate: cost per view/follower vs thresholds reviewed together.

- [ ] **P2.2 — Approve validate + first scale** 🟡 `ads`
  Owner: Balram Bandhu · Dep: P2.1 · Output: qualifiers advance to $15/day
  × 7 days; losers scale down / pause / die per the ladder rules
  (automatic, with notification). Scale-ups past 2× need your explicit
  approval each time.
  Gate: validate-stage efficiency reviewed.

- [ ] **P2.3 — Approve the weekly boost proposals** 🟡 `$0`
  Owner: Balram Bandhu · Dep: pipetech:P2.3 · Output: every Monday,
  Muse Bandhu proposes boosts for the week's organic winners; you approve
  (or adjust) the batch, Muse Bandhu launches.
  Gate: first proposal batch approved/adjusted.

## P3 — Ongoing & expansion

- [ ] **P3.2 — Per-channel promo rollout sign-off** 🟡 `ads`
  Owner: Balram Bandhu · Dep: pipe:T4.2 · Output: promo repeated per new
  themed channel (accounts/billing already exist; only targeting +
  budgets differ).
  Gate: same sign-off as P2.2, per channel.

---

## Dependency map (this list)

```
P0.1 → P1.1, P1.2
P0.2 → (affiliate applications, outreach — manual gates)
(pipetech:P2.1 ready) → P2.1 → P2.2 → P3.2
(pipetech:P2.3 live) → P2.3
```

## Cost summary

| | Upfront | Recurring |
|---|---|---|
| P0–P1 setup | **$0** (your time for billing setup) | — |
| Probes | — | $5/day × 3 days per hero |
| Validate / Scale | — | $15/day, then $30–50/day on winners only |
| Suggested pilot month | — | $150–300 total across Meta + Google |
| Milestone promo budgets (M1→M5) | — | $150–300 → $1,500–3,000/mo (see plan §11) |

**How we review:** same as the pipeline lists — output presented, you say
"adjust" or "done". Promotion runs on its own track once kicked off
(pipeline T2.4); the pipeline keeps publishing regardless.
