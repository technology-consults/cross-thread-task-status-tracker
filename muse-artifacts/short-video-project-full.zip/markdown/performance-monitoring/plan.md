# Performance Monitoring & Reporting Pipeline — Plan

**Owner:** Balram Bandhu · **Built & operated by:** Muse Bandhu
**Date:** 2026-09-24 · **Status:** Draft for review
**Technical spec:** `techspec.md`
**Tasks:** `tasks-balram.md` (decisions & approvals — yours) ·
`tasks-muse.md` (build work — Muse's)

## 1. Vision

The central nervous system of the five pipelines. It watches everything,
reports what matters, and raises the alarm when something needs a human —
but it **does not own any other pipeline's data**. Each pipeline keeps
its own state; this one collects, aggregates, and presents. One place to
look every morning, one weekly rollup that tells the whole story, one
monthly review that sets direction.

## 2. Objectives

- Collect per-video metrics (views, retention, engagement, follows)
  nightly from all four platforms.
- Deliver the R1/R2/R3 reporting ladder (§5) on schedule, in chat, in a
  stable format you can skim in minutes.
- Own the **shared reporting framework**: report formats, cadence
  conventions, and delivery mechanics used by all pipelines.
- Own the **shared severity-tiering framework** for alerts (§7): one
  consistent language for "how urgent is this" across all five pipelines.
- Maintain the infrastructure of the **shared learning knowledge base**
  (§9): every pipeline reads and writes; this pipeline keeps the store
  healthy.
- Detect anomalies early — weak growth, bottlenecks, platform-behavior
  changes — before they cost weeks.

## 3. What this pipeline owns — and what it doesn't

**Owns:** the reporting framework, the severity-tiering framework, the
R1/R2/R3 rollups, the learning-KB infrastructure, the alert bus/delivery
mechanics, trend radar inputs, the experiment registry.

**Does NOT own:** any pipeline's operational data. Production counts
belong to create-and-publish, spend belongs to promotion, review
outcomes belong to housekeeping, revenue belongs to earnings. This
pipeline **collects copies** — the source of truth stays with the
pipeline that produced it. If a number looks wrong, the owning pipeline
is where it's fixed.

## 4. The reporting framework (shared conventions)

Every report from every pipeline follows the same conventions, defined
here:

- **Format:** chat-native summary + optional detail attachment. Numbers
  first, interpretation second, recommended actions last.
- **Cadence conventions:** daily (R1), weekly (R2), monthly (R3) —
  pipeline operational reports slot into the same rhythm.
- **Delivery:** in chat, batched (one session per report, not a drip of
  pings). Alerts are the exception — P1/P2 interrupt.
- **Paid vs organic separation:** every report that touches both states
  them separately and shows the measured relationship — never blended
  into one number (TO-VERIFY per-platform attribution support).

## 5. R1 / R2 / R3 — PROPOSED definitions

> **These definitions are proposed.** Confirm or adjust — nothing is
> final until you say "done" (PM0.1).

- **R1 — Daily ops pulse** (every morning in chat): yesterday's
  production (videos made/published per pipeline), publish failures,
  promotion spend, P1/P2 alerts overnight, today's schedule. Skim time:
  ~2 minutes.
- **R2 — Weekly cross-pipeline rollup** (Sundays): growth per platform
  (views, followers, retention), revenue snapshot, experiment results,
  learning-KB highlights (what's working, what's failing), and concrete
  calls — **scale / kill / test** — carried over from the pipeline
  plan's weekly review, which folds into R2 rather than running
  separately. Skim time: ~10 minutes.
- **R3 — Monthly strategic review** (1st week of month): trend analysis,
  learning-layer insights, cost-per-video and revenue-per-video trends,
  seasonal/market notes, recommendations for next month, and inputs to
  the week-4/week-8 **go / pivot / pause** channel verdicts. This is the
  deep read: ~20 minutes.

## 6. Boundary: each pipeline's own operational reports

Mirroring the alerting pattern — distributed detail, centralized
framework:

- **Create-and-publish** reports production: videos made, QC pass rate,
  cost per video, buffer health.
- **Promotion** reports spend: budget used, CPV/CPF, kill-trigger events,
  organic-vs-paid readouts.
- **Housekeeping** reports review outcomes: videos reviewed per rung,
  link-rot summary, obligation compliance.
- **Earnings** reports revenue attribution: revenue by video/topic/format/
  platform, affiliate performance, sponsor pipeline status.
- **This pipeline** defines the framework (§4) and produces the
  cross-pipeline R1/R2/R3 that stitch those five reports together. It
  does not duplicate their detail.

## 7. Severity-tiering framework — PROPOSED tiers

> **Proposed.** Confirm or adjust (PM0.2). Every pipeline assigns these
> tiers to its own detectors; this pipeline delivers them.

| Tier | Meaning | Response | Examples |
|---|---|---|---|
| **P1** 🔴 | Human needed now | Interrupts chat immediately | Sponsor obligation breach risk; publishing fully halted; credential/token failure |
| **P2** 🟠 | Human needed today | Batched same-day alert | Repeated self-healing failure; spend anomaly; broken-link spike |
| **P3** 🟡 | Review this week | Folded into R1/R2 | QC reject rate drifting up; backlog growing; weak growth trend |
| **P4** 🟢 | Informational | Logged only | Single transient retry success; routine completions |

Tiers are assigned by **importance, occurrence rate, urgency, and need
for human review/approval/intervention** — not by which pipeline raised
them.

## 8. Alert bus & delivery

Detectors live in each pipeline (they know their own failure modes); the
bus lives here. Mechanics: severity assignment at the source, dedup
(same detector + same video = one alert), escalation (P3 → P2 if
unresolved across runs), and delivery to chat. During the pilot, alert
thresholds are conservative — more signal, less noise; tuned from data
after.

## 9. Shared learning knowledge base

This pipeline maintains the KB **infrastructure** (schema, storage, write
API); all five pipelines read and write their outcomes. Contents:
winning hooks, formats, and topics; failure patterns; QC-rejection
categories; cost and revenue observations; comment/feedback themes;
trend-radar hits. **Boundary:** during the pilot, learning-driven
pipeline changes need your approval. Bounded automatic adjustments are
considered only after full automation is authorized ("go auto" / "lock
the vision").

## 10. Trend radar & experiment registry

- **Trend radar:** platform trend inputs (search suggestions, breakout
  topics in-niche) collected for the topic engine — radar reports, it
  doesn't decide; the create-and-publish pipeline decides.
- **Experiment registry:** controlled experiments (hook variants, format
  tests, CTA rotations) are registered here with hypothesis, scope, and
  success criteria — a proposed small portion of output is reserved for
  tests. Results write back to the KB.

## 11. Approvals & guardrails

| Action | Mode |
|---|---|
| R1/R2/R3 generation and delivery | Automatic 🟢 |
| P1/P2 alert delivery | Automatic 🟢 |
| Report format/cadence changes | Your approval 🟡 |
| R-definition or tier changes | Your approval 🟡 |
| Learning-driven pipeline changes (pilot) | Your approval 🟡 |
| Publishing any metric externally (media kit, sponsors) | Your approval 🟡 |

Muse never: invents metrics, blends paid and organic numbers, publishes
metrics outside the project without approval, or changes what "P1" means
unprompted.

## 12. Observability of this pipeline itself

This pipeline is also a pipeline: it has its own bug/failure/
performance tracking, failure-pattern history, predefined self-healing
(bounded retries on metric pulls, fallback to proxy metrics where a
platform API is down, quarantine of corrupt metric batches), escalation
on repeated failure, and its own anomaly detection (metric gaps,
ingestion lag). A monitoring pipeline that can't monitor itself is a
liability.

## 13. What needs your hands vs what runs itself

- **You, decisions:** approve the R1/R2/R3 definitions and severity
  tiers; approve format/cadence changes; approve learning-driven changes
  in the pilot; the week-4/week-8 go/pivot/pause verdicts (informed by
  R3, decided by you).
- **Muse, everything else:** ingestion, reports, alerts, KB maintenance,
  radar, experiments, self-healing.
- **Honest limits:** per-platform analytics availability is TO-VERIFY —
  where true retention or attribution is unavailable, the pipeline uses
  defined proxy metrics (techspec §4/§5) and says so in the report,
  rather than presenting guesses as measurements.

## 14. Costs

**Upfront: $0 out-of-pocket** (your time only).
**Recurring:** draws on your Muse plan for nightly ingestion + report
generation (light compute; API calls $0 within quotas). No
subscriptions, no per-report fees.

## 15. Timeline

- **Build:** ingestion + metric store first, then R1, then the alert bus
  + severity framework, then R2/R3, then KB infrastructure + radar.
- **First R1:** once create-and-publish has published videos (no earlier
  than its week 3).
- **Steady state:** R1 daily, R2 Sundays, R3 monthly — automatic.

## 16. Open decisions (yours)

1. R1/R2/R3 definitions as proposed in §5 — adjust or done?
2. Severity tiers as proposed in §7 — adjust or done?
3. R1 delivery time — with the morning, or another slot?
4. Experiment reservation — what small portion of output may be used for
   controlled tests?
