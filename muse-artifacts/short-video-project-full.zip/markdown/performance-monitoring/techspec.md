# Performance Monitoring & Reporting — Technical Specification

Companion to `plan.md` (the what/why). This file is the how: ingestion,
schemas, the alert bus, R1/R2/R3 generators, and the learning-KB
infrastructure.
**Build tasks:** `tasks-muse.md`

## 1. Workspace layout (independent codebase)

```
~/workspace/video-perfmon/
├── ingest/
│   ├── youtube-pull.py          # YouTube Analytics API (read-only)
│   ├── meta-pull.py             # IG/FB insights (TO-VERIFY availability)
│   ├── tiktok-pull.py           # TikTok analytics (TO-VERIFY availability)
│   └── normalize.py             # → canonical metric records
├── alertbus/
│   ├── detectors.py             # shared detector interface (all pipelines use)
│   ├── severity.py              # tier assignment (plan §7)
│   ├── dedup.py                 # dedup + escalation logic
│   └── deliver.py               # chat delivery
├── reports/
│   ├── r1-daily.py
│   ├── r2-weekly.py
│   └── r3-monthly.py
├── learning/
│   ├── kb-store.py              # schema + storage for the shared KB
│   ├── kb-write.py              # write API used by all pipelines
│   ├── experiments.py           # experiment registry
│   └── radar.py                 # trend radar inputs
├── state/
│   ├── metrics.jsonl            # canonical per-video metric records
│   ├── alerts.jsonl             # alert history
│   ├── failures.jsonl           # own bug/failure/performance tracking
│   ├── failure-patterns.json
│   └── healing-log.jsonl
└── feedback/
    └── comment-analysis.py      # comment/feedback theme extraction
```

## 2. Metrics ingestion

Nightly pull (23:30 ET, after the last publish slot): per-video views,
likes, comments, shares, follows/subs, and retention/watch-time where
available. Each platform pull is an independent module with its own
bounded retries (3, exponential backoff); a failed platform pull doesn't
block the others — the gap is logged as an anomaly (ingestion lag), and
the report notes the missing source explicitly.

## 3. Metric schemas

Canonical record in `metrics.jsonl`, keyed by video ref + platform +
date:

```json
{
  "ref": "<channel>.yyyy.MM.dd.N",
  "platform": "youtube|instagram|facebook|tiktok",
  "date": "YYYY-MM-DD",
  "views": 0, "likes": 0, "comments": 0, "shares": 0, "follows": 0,
  "watch_time_s": 0, "avg_view_duration_s": 0.0,
  "retention_proxy": "<metric used>",
  "traffic_source": "organic|paid|unknown"
}
```

`retention_proxy` records *which* metric stood in for retention when the
platform doesn't expose it (see §4) — provenance is stored, not assumed.

## 4. Retention / watch-time / attribution (proxies where unavailable)

- **YouTube:** Analytics API exposes audience retention and watch time —
  use directly (TO-VERIFY exact dimensions at build).
- **Instagram / Facebook / TikTok:** retention availability is
  TO-VERIFY. Where unavailable, defined proxies apply (e.g.
  avg-view-duration ÷ video-duration, completion-rate estimates from
  available fields) — each proxy is documented in the KB with its
  limitations, and reports label proxied numbers as such.
- **Attribution:** per-video traffic source where the platform reports
  it; otherwise `unknown` — never inferred silently.

## 5. Paid vs organic separation (TO-VERIFY per platform)

The promotion pipeline tags paid traffic; ingestion keeps
`traffic_source` separate through normalization, aggregation, and
reporting. Reports that touch both show three lines — organic, paid,
and the measured relationship — per the locked rule. If a platform
doesn't expose the split, the report says "paid/organic split
unavailable on <platform>" rather than blending.

## 6. Anomaly detection framework (shared interface)

All five pipelines implement detectors against one interface:

```python
detect(context) -> list[Anomaly]   # Anomaly {detector_id, ref?, metric,
                                   #  observed, baseline, suggested_tier}
```

Framework-provided detectors: metric gaps (expected data missing),
ingestion lag, velocity collapse (views falling 3× below trailing
baseline), weak growth (follower velocity below gate thresholds),
bottleneck detection (buffer draining, backlog growing). Pipelines add
their own (promotion: spend anomalies; housekeeping: link-rot spikes;
earnings: revenue drops). Tier suggestion comes from the detector; final
assignment via `severity.py` (plan §7).

## 7. Alert bus: severity, dedup, delivery, escalation

- **Severity assignment:** importance × occurrence rate × urgency × need
  for human review/approval/intervention (plan §7 tiers).
- **Dedup:** same detector + same video ref + same run window = one
  alert; repeats increment a counter, not a new alert.
- **Delivery:** P1 interrupts chat immediately; P2 batched same-day;
  P3 folds into the next R1/R2; P4 logged to `alerts.jsonl` only.
- **Escalation:** an unacknowledged P3 recurring across 3 runs becomes
  P2; a P2 recurring across 3 runs becomes P1. Escalations carry the
  history.
- **Quiet hours:** none by default — P1s are rare by design. (Your call
  in PM0.3 if you want any.)

## 8. R1/R2/R3 generators

- **r1-daily.py:** yesterday's production counts (queried from each
  pipeline's state — copies, never owned), publish failures, promotion
  spend, overnight P1/P2 alerts, today's schedule. Rendered chat-native.
- **r2-weekly.py:** per-platform growth (views, followers, retention),
  revenue snapshot (from earnings), experiment results (from the
  registry), learning-KB highlights, scale/kill/test calls.
- **r3-monthly.py:** trend analysis, cost-per-video and revenue-per-
  video trends, seasonal/market notes, recommendations, go/pivot/pause
  inputs for the week-4/week-8 verdicts.
- All three are idempotent per period (one R1 per day, etc.) and carry
  the data-as-of timestamp. Missing sources are labeled, never silently
  omitted.

## 9. Learning KB schema + write API

```json
{
  "type": "hook|format|topic|failure_pattern|qc_rejection|cost_note|revenue_note|feedback_theme|trend_hit",
  "channel": "<channel>",
  "summary": "<one line>",
  "evidence": {"refs": ["<video refs>"], "metrics": {}},
  "confidence": "low|medium|high",
  "created": "YYYY-MM-DD",
  "source_pipeline": "<which pipeline wrote it>"
}
```

`kb-write.py` is the single write path — every pipeline calls it; direct
writes to the store are not a thing. Reads are open to all pipelines
(topic engine, CTA rotation, experiment design).

## 10. Comment/feedback analysis hooks

`comment-analysis.py` pulls comments (where platform APIs allow —
TO-VERIFY) and extracts themes: objections, corrections, topic
requests, sentiment shifts. Findings write to the KB as `feedback_theme`
entries and can trigger re-review flags into housekeeping. Nothing is
auto-acted on — themes are reported, humans (or the owning pipeline's
approved logic) decide.

## 11. Trend radar inputs

`radar.py` collects: platform search-suggestion keywords, breakout
topics in-niche, seasonal calendar markers, ad-market notes (from
earnings). Output is a ranked input feed for the create-and-publish
topic engine — radar reports, it doesn't decide. Guardrails apply: the
universal content rules (no sensitive/objectionable content, nothing
involving children, no current politics, nothing controversial) filter
radar hits before they reach ideation.

## 12. Observability/self-healing of perfmon itself

Own `failures.jsonl` + `failure-patterns.json`; predefined self-healing:
bounded retries on pulls, proxy-metric fallback when a platform API is
down, quarantine of corrupt metric batches (quarantined batches are
reported, never silently dropped); escalation when the same ingestion
fails 3 nights running (P2 — a blind monitoring pipeline is a P1
waiting to happen). Its own anomaly detection watches for metric gaps
and ingestion lag.

## 13. Orchestration

| Job | When (ET) | What |
|---|---|---|
| `ingest/*` | 23:30 daily | Nightly metric pulls → `metrics.jsonl` |
| `r1-daily` | 07:00 daily | R1 ops pulse → chat |
| `r2-weekly` | Sun 09:00 | R2 cross-pipeline rollup → chat |
| `r3-monthly` | 3rd of month 08:00 | R3 strategic review → chat |
| `radar` | 05:00 daily | Trend radar feed for the topic engine |
| `comment-analysis` | Wed/Sun 08:00 | Feedback themes → KB |
| `backup-state` | 02:00 daily | Snapshot `state/` (off-VM copy) |

## 14. Security

- Analytics API credentials are read-only tokens in the Secure Vault —
  never in files, memory, or logs.
- Metric stores contain no secrets, no PII beyond public comment text
  (handled per platform ToS; raw comment text is not retained longer
  than analysis needs).

## 15. Verification checklist (prove before treating as spec)

- [ ] YouTube Analytics API: available retention/watch-time dimensions,
      quota cost per call.
- [ ] Instagram/Facebook: which video insights are API-accessible
      (views, reach, avg watch time, traffic source).
- [ ] TikTok: analytics API availability, approval requirements,
      accessible dimensions.
- [ ] Paid vs organic traffic-source labeling per platform.
- [ ] Comment read/reply/pin API support per platform.
- [ ] Search-suggestion/trend data sources per platform (official vs
      third-party).

## 16. Key references

- YouTube Analytics API:
  https://developers.google.com/youtube/analytics
- Meta Graph API — Insights:
  https://developers.facebook.com/docs/graph-api/reference/insights
- TikTok API docs (verify analytics availability at build).
- Learning KB consumers: create-and-publish (topic engine),
  earnings-improvement (CTA rotation, attribution), housekeeping
  (review findings).
