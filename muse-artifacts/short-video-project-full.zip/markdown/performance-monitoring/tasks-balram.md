# Performance Monitoring — Your Tasks (Balram)

Decisions and approvals only. Muse does all build work (`tasks-muse.md`).
One task at a time, in dependency order. Nothing is checked off until you
say **"done"** — reply **"adjust"** to change direction.

| ID | Task | What you decide/approve | Cost | Auto | Depends on | Status |
|---|---|---|---|---|---|---|
| PM0.1 | Approve R1/R2/R3 definitions | Confirm the proposed R1 (daily ops pulse), R2 (weekly rollup), R3 (monthly strategic review) in `plan.md` §5, or adjust | Your time (~20 min review) | 🟡 | — | Open |
| PM0.2 | Approve severity tiers | Confirm the proposed P1–P4 tiers and their response rules in `plan.md` §7, or adjust | Your time (~15 min review) | 🟡 | — | Open |
| PM0.3 | R1 delivery time + quiet hours | Morning R1 slot; whether you want any quiet hours for P1 delivery | Your time (5 min) | 🟡 | PM0.1 | Open |
| PM0.4 | Experiment reservation | What small portion of output may be reserved for controlled tests (proposed: to be set from pilot data) | Your time (5 min) | 🟡 | — | Open |
| PM0.5 | Report format/cadence changes (standing) | Any change to what R1/R2/R3 contain or when they arrive needs your approval | As needed | 🟡 | PM0.1 | Open |
| PM0.6 | Learning-driven changes (pilot) | Approve any pipeline change proposed from learning-KB findings during the pilot | As needed | 🟡 | — | Open |
| PM0.7 | External metric sharing | Any publication of metrics outside the project (media kit, sponsors) needs your approval | As needed | 🟡 | — | Open |
| PM0.8 | Go / pivot / pause verdicts | Week-4 and week-8 channel verdicts — R3 informs, you decide | At week 4 and week 8 | 🟡 | PM0.1 | Open |

**How this works:** once R1 is live you get one short pulse every
morning, R2 every Sunday, R3 monthly. P1 alerts interrupt; everything
else arrives batched. You read, and only step in on decisions and
approvals.
