# Performance Monitoring — Build Tasks (Muse)

Technical work, in dependency order. Each result is presented for your
**adjust**/**done** before the next task starts. No implementation has
begun — these are build plans.

| ID | Task | Cost | Auto | Depends on | Status |
|---|---|---|---|---|---|
| PMT1.1 | Metrics ingestion — nightly per-platform pulls (YouTube Analytics, Meta, TikTok — each TO-VERIFY-gated), normalization to the canonical schema, `metrics.jsonl` | $0 out-of-pocket; Muse plan compute; API calls within quotas | 🟢 | — | Open |
| PMT1.2 | R1 daily ops pulse — generator + chat delivery (production counts, failures, spend, overnight P1/P2, today's schedule) | $0 out-of-pocket; Muse plan compute | 🟢 | PMT1.1, PM0.1 | Open |
| PMT1.3 | Alert bus + severity framework — shared detector interface, tier assignment (P1–P4), dedup, escalation, chat delivery mechanics | $0 out-of-pocket; Muse plan compute | 🟢 | PM0.2 | Open |
| PMT1.4 | R2 weekly rollup — generator folding in the pipeline plan's weekly review (scale/kill/test calls) rather than duplicating it | $0 out-of-pocket; Muse plan compute | 🟢 | PMT1.1, PM0.1 | Open |
| PMT1.5 | R3 monthly strategic review — trends, cost/revenue-per-video, seasonal notes, recommendations, go/pivot/pause inputs | $0 out-of-pocket; Muse plan compute | 🟢 | PMT1.4, PM0.1 | Open |
| PMT1.6 | Learning KB infrastructure — schema, store, single write API for all pipelines, read access for topic engine/CTA rotation/experiments | $0 out-of-pocket; Muse plan compute | 🟢 | — | Open |
| PMT1.7 | Trend radar + experiment registry — daily radar feed for the topic engine (guardrail-filtered), registered experiments with hypothesis/scope/success criteria | $0 out-of-pocket; Muse plan compute | 🟢 | PMT1.6 | Open |
| PMT1.8 | Comment/feedback analysis — theme extraction (objections, corrections, topic requests), KB writes, re-review flags to housekeeping | $0 out-of-pocket; Muse plan compute | 🟡 | PMT1.6 | Open |
| PMT1.9 | Observability of perfmon itself — own failure tracking, failure-pattern history, self-healing (bounded retries, proxy fallbacks, quarantine), escalation, ingestion-lag anomaly detection | $0 out-of-pocket; Muse plan compute | 🟢 | PMT1.1–PMT1.3 | Open |
| PMT1.10 | Platform verification pass — prove every capability in techspec §15 against current official docs/APIs; define proxy metrics where true retention/attribution is unavailable | $0 out-of-pocket; Muse plan compute | 🟢 | — | Open |

**Dependency notes:** PMT1.10 (verification) informs PMT1.1's proxy
definitions — ingestion builds against verified capabilities only.
PMT1.2/PMT1.4/PMT1.5 are gated on your R-definition approval (PM0.1);
PMT1.3 on tier approval (PM0.2).
