# Short-Video Project — Start Here

Last updated: 2026-09-25

## Goal

Build and operate an automated short-video feed across multiple themed channels (YouTube Shorts, Instagram Reels, Facebook Reels, TikTok), starting with **Channel #1: AI Technology Education**. All generated media is original — never pulled from the internet without disclosure and approval.

## The five pipelines

Each is an independent codebase with its own bug/failure/performance tracking, self-healing, and alerting. They share one learning knowledge base.

| # | Pipeline | Owns |
|---|---|---|
| 1 | create-and-publish | Idea → generation → QC → publish, behind per-video approval during the pilot |
| 2 | promotion | Organic amplification + paid ladder (probe → validate → scale). Objective: **min cost and max impact** |
| 3 | housekeeping | Monthly stale-content review, ledger hygiene, link checks |
| 4 | performance-monitoring | Per-pipeline stats collection, shared reporting framework, R1/R2/R3 cross-pipeline rollups, anomaly detection |
| 5 | earnings-improvement | Revenue attribution, affiliate optimization, sponsor pipeline |

See `reference/architecture.md` for the full architecture.

## Doc map (approved target structure)

```
short-video-project/
├── 00-START-HERE.md                  ← this file
├── create-and-publish/
│   ├── plan.md / techspec.md / tasks-balram.md / tasks-muse.md
├── promotion/
│   ├── plan.md / techspec.md / tasks-balram.md / tasks-muse.md
├── housekeeping/
│   ├── plan.md / techspec.md / tasks-balram.md / tasks-muse.md
├── performance-monitoring/
│   ├── plan.md / techspec.md / tasks-balram.md / tasks-muse.md
├── earnings-improvement/
│   ├── plan.md / techspec.md / tasks-balram.md / tasks-muse.md
├── reference/
│   ├── architecture.md               ← five-pipeline design, learning layer, pilot vs full-auto
│   ├── decisions-log.md              ← every locked decision, dated
│   ├── brand-kit.md                  ← name, handles, voice, caption style, hashtags
│   ├── content-guardrails.md         ← universal guardrails + enforcement
│   ├── topic-engine-scope.md         ← editorial scope, sources, dedup rules
│   ├── platform-policies.md          ← per-platform rules (all items TO-VERIFY officially)
│   └── monetization-research.md      ← sponsorship/affiliate economics, distilled
├── ledgers/
│   ├── sponsor-obligations.md        ← per-video sponsor contract ledger
│   └── content-ledger.md             ← every published video + performance
├── brand/                            ← voice samples, logos
└── research/                         ← raw research reports
```

**Rule of thumb:** a fact we'd look up → `reference/`. A decision about the build → pipeline `plan.md`/`techspec.md`. Work to do → `tasks-*.md`. A living operational record → `ledgers/`.

Reorganization completed 2026-09-25: the eight original pipeline documents were superseded by the updated versions in `create-and-publish/` and `promotion/` and moved to recoverable trash.

## Reading order

1. This file.
2. `reference/architecture.md` — how the system fits together.
3. `reference/decisions-log.md` — what's already decided (don't re-litigate).
4. Pipeline `plan.md` files — what each pipeline does.
5. `reference/` as needed — guardrails, scope, policies, economics.

## Current status

- **T0.1 DONE (2026-09-24):** Channel #1 = AI Technology Education. Backups: #1 History & mythology explainers, #2 Real-world crime news.
- **T0.2 IN PROGRESS:** Brand kit — name, voice, style. Name screening done 2026-09-25 (see `reference/brand-kit.md`); awaiting BalRam's pick. Nothing final until he says **"done."**
- **NO implementation begun.** No social accounts, API projects, credentials, publishing jobs, posts, campaigns, billing methods, or connected-account capabilities have been created or inspected.

## Standing operating rules (full list in `reference/decisions-log.md`)

- One task at a time, in dependency order. BalRam replies **"adjust"** or **"done"**; nothing is checked off or advanced without **"done."**
- Pilot publishing stays behind per-video approval. Full automation begins only after **"go auto"** / **"lock the vision"**.
- **"Turn review back on"** restores review. **"Pause all publishing now"** halts everything until resume.
- State upfront and recurring costs on every proposal.
